package Logic.Utilty;

import Logic.Coordinate.Coordinate;
import Logic.Coordinate.CoordinateFactory;
import Logic.Exceptions.InvalidExcelFormatException;

import java.util.ArrayList;
import java.util.List;

public interface Utilty {
    public static Coordinate fromExcelFormat(String excelFormat) throws InvalidExcelFormatException {
        // Define a regular expression for strict validation (e.g., "A1", "Z99", "AA100") with case insensitivity
        String regex = "^[A-Za-z]+[0-9]+$";

        // Validate the input format
        if (excelFormat == null) {
            throw new InvalidExcelFormatException(excelFormat);
        }
        if (!excelFormat.matches(regex)) {
            throw new InvalidExcelFormatException(excelFormat);
        }

        try {
            // Extract column letters and row numbers
            String columnLetters = excelFormat.replaceAll("[^A-Za-z]", "");
            String rowNumbers = excelFormat.replaceAll("[^0-9]", "");

            // Convert column letters to a number
            int column = 0;
            for (int i = 0; i < columnLetters.length(); i++) {
                column = column * 26 + (Character.toUpperCase(columnLetters.charAt(i)) - 'A' + 1);
            }

            // Convert row numbers to an integer
            int row = Integer.parseInt(rowNumbers);

            // Return the coordinate in "row:column" format
            return CoordinateFactory.createCoordinate(row, column);
        } catch (NumberFormatException e) {
            throw new InvalidExcelFormatException(excelFormat);
        }
    }

    public static String toExcelFormat(Coordinate coordinate) {
        int row = coordinate.getRow();
        int column = coordinate.getColumn();

        StringBuilder columnLetters = new StringBuilder();
        while (column > 0) {
            int remainder = (column - 1) % 26;
            columnLetters.insert(0, (char) (remainder + 'A'));
            column = (column - 1) / 26;
        }

        return columnLetters.toString() + row;
    }

    public static int columnLettersToNumber(String columnLetters) {
        try {
            int column = 0;
            for (int i = 0; i < columnLetters.length(); i++) {
                column = column * 26 + (columnLetters.charAt(i) - 'A' + 1);
            }
            return column;
        } catch (Exception e) {
            return -1; // Return -1 to indicate an error
        }
    }
    public static String columnNumberToLetters(int columnNumber) {
        try {
            StringBuilder columnLetters = new StringBuilder();
            while (columnNumber > 0) {
                int remainder = (columnNumber - 1) % 26;
                columnLetters.insert(0, (char) (remainder + 'A'));
                columnNumber = (columnNumber - 1) / 26;
            }
            return columnLetters.toString();
        } catch (Exception e) {
            return ""; // Return an empty string to indicate an error
        }
    }
    public static List<String> getAllColumnLettersInRange(int startColumn, int endColumn) {
        try {
            List<String> columnLetters = new ArrayList<>();
            for (int i = startColumn; i <= endColumn; i++) {
                columnLetters.add(columnNumberToLetters(i));
            }
            return columnLetters;
        } catch (Exception e) {
            return null; // Return null to indicate an error
        }
    }
}

package Logic.Cell.api;

import Logic.sheet.api.ReadonlySheet;

public interface Cell extends ReadonlyCell {
    void setCellOriginalValue(String value);
    void incrementVersion();
    void setVersion(int version);
    void setEffectiveValueForFilterAndSort(EffectiveValue effectiveValue);
    void setSheet(ReadonlySheet sheet);
    void setLastUpdater(String updater);
}

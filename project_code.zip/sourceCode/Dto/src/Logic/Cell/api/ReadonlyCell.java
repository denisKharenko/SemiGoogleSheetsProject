package Logic.Cell.api;

import java.io.Serializable;
import java.util.Set;

import Logic.Coordinate.Coordinate;
import Logic.Exceptions.CoordinateOutOfRangeException;
import Logic.Exceptions.*;

public interface ReadonlyCell extends Serializable {

    Coordinate getCoordinate();
    String getOriginalValue();
    EffectiveValue getEffectiveValue();
    boolean calculateEffectiveValue() throws CoordinateOutOfRangeException, FunctionDoesNotExistException;
    int getVersion();
    Set<ReadonlyCell> getDependsOn();
    Set<ReadonlyCell> getInfluencingOn();
    String getDependsOnRange();
    Set<String> getInfluencingOnRanges();
    String getLastUpdater();


}

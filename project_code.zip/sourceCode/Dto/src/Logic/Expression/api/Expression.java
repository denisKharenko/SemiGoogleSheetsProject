package Logic.Expression.api;

import Logic.Cell.api.CellType;
import Logic.Exceptions.CoordinateOutOfRangeException;
import Logic.sheet.api.ReadonlySheet;
import Logic.Cell.api.EffectiveValue;

import java.io.Serializable;

public interface Expression extends Serializable {
    EffectiveValue eval(ReadonlySheet sheet) throws CoordinateOutOfRangeException;
    CellType getFunctionResultType();

}

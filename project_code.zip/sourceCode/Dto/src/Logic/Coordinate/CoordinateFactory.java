package Logic.Coordinate;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

public class CoordinateFactory implements Serializable {
    private static Map<String, Coordinate> cachedCoordinates = new HashMap<>();

    public static Coordinate createCoordinate(int row, int column) {

        String key = row + ":" + column;
        if (cachedCoordinates.containsKey(key)) {
            return cachedCoordinates.get(key);
        }

        Coordinate coordinate = new Coordinate(row, column);
        cachedCoordinates.put(key, coordinate);

        return coordinate;
    }
    /*
    ///figure out why he made the from method this way if he made a mistake then make the below method the new from method
    public static Coordinate fromExcelFormat(String excelFormat) {
        try {
            // Extract column letters and row numbers
            String columnLetters = excelFormat.replaceAll("[^A-Z]", "");
            String rowNumbers = excelFormat.replaceAll("[^0-9]", "");

            // Convert column letters to a number
            int column = 0;
            for (int i = 0; i < columnLetters.length(); i++) {
                column = column * 26 + (columnLetters.charAt(i) - 'A' + 1);
            }

            // Convert row numbers to an integer
            int row = Integer.parseInt(rowNumbers);

            // Return the coordinate in "row:column" format
            return createCoordinate(row, column);
        } catch (NumberFormatException e) {
            return null;
        }
    }
    public static String toExcelFormat(Coordinate coordinate) {
        int row = coordinate.getRow();
        int column = coordinate.getColumn();

        StringBuilder columnLetters = new StringBuilder();
        while (column > 0) {
            int remainder = (column - 1) % 26;
            columnLetters.insert(0, (char) (remainder + 'A'));
            column = (column - 1) / 26;
        }

        return columnLetters.toString() + row;
    }

    public static Coordinate from(String trim) {
        try {
            String[] parts = trim.split(":");

            return createCoordinate(Integer.parseInt(parts[0]), Integer.parseInt(parts[1]));
        } catch (NumberFormatException e) {
            return null;
        }
    }
    */


}

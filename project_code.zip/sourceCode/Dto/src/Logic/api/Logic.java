package Logic.api;

import Logic.Cell.api.ReadonlyCell;
import Logic.Coordinate.Coordinate;
import Logic.Exceptions.*;
import Logic.permission.Permission;
import Logic.permission.PermissionRequest;
import Logic.sheet.api.ReadonlySheet;
import Logic.sheet.api.Sheet;

import java.io.File;
import java.io.InputStream;
import java.io.Serializable;
import java.util.List;
import java.util.Map;

public interface Logic extends Serializable {
    int getRows();
    int getColumns();
    int getWidth();
    int getHeight();
    Map<String, Permission> getPermissions();
    List<PermissionRequest> getPermissionRequestsForSheets();
    String getUserPermission(String userName);
    String getSheetName();
    ReadonlySheet getCurrentSheet();
    ReadonlySheet getSheetByVersion(int version);
    Sheet getEditableSheetByVersion(int version);
    public Logic loadSheet(String filePath,String uploaderName) throws Exception;
    public Logic loadSheet(String filePath, File choosenFile, String uploaderName) throws Exception;
    public Logic loadSheetFromXmlContent(InputStream inputStream, String uploaderName) throws Exception;
    public ReadonlyCell getCellForDisplay(int version, String rowAndColumn) throws CoordinateOutOfRangeException, FunctionDoesNotExistException;
    public void updateCell(int version, String rowAndColumn , String value, String updaterName) throws CoordinateOutOfRangeException, FunctionDoesNotExistException;
    public List<ReadonlySheet> getDifferentSheetVersionsForDisplay();
    public Coordinate checkFormat(String rowAndColumn) throws CoordinateOutOfRangeException;
    public void createNewRange(String rangeName, int rowStart, int columnStart, int rowEnd, int columnEnd) throws RangeAlreadyExistsException, RangeCoordinateOutOfRangeException, RangeStartIndexLowerThenEndException;
    public void removeRange(String rangeName) throws RangeInUseException;
    public List<String> getUniqueValuesInColumnArea(int column, Coordinate topLeft, Coordinate bottomRight, ReadonlySheet sheetToUse) throws CoordinateOutOfRangeException;
    public ReadonlySheet filterSheet(List<String> selectedUniqueValues,int columnNumber,Coordinate topLeft,Coordinate bottomRight,ReadonlySheet sheetToFilter) throws CoordinateOutOfRangeException;
    public ReadonlySheet sortSheet(List<String> selectedColumns, Coordinate topLeft, Coordinate bottomRight, ReadonlySheet sheetToSort) throws CoordinateOutOfRangeException;
    public List<Sheet> getSheets();
    public String getOwnerName();
}

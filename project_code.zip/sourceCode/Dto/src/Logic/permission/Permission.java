package Logic.permission;

public enum Permission {
    OWNER,
    READER,
    WRITER,
    NONE
}

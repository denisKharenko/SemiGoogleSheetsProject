package Logic.permission;

public enum ApprovalOption {
    ACCEPT,
    DENY
}

package Logic.permission;

public enum PermissionRequestStatus {
    PENDING,
    APPROVED,
    REJECTED
}

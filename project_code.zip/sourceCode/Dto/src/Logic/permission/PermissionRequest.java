package Logic.permission;

public interface PermissionRequest {
    Permission getPermission();
    String getSubmitterName();
    String getSheetName();
    String getSheetOwnerName();
    PermissionRequestStatus getStatus();
}

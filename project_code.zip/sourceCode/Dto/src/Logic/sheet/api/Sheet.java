package Logic.sheet.api;

import Logic.Exceptions.CoordinateOutOfRangeException;
import Logic.Exceptions.FunctionDoesNotExistException;
import Logic.api.Logic;

public interface Sheet extends ReadonlySheet {
    public Sheet updateCellValueAndCalculate(int row, int column, String value,String updater) throws CoordinateOutOfRangeException, FunctionDoesNotExistException;
    void incrementVersion();
    Logic getLogic();
    void setVersion(int version);
    void setLogic(Logic logic);
    void setUpdater(String updater);
}

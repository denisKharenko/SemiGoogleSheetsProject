package Logic.sheet.api;

import Logic.Cell.api.ReadonlyCell;
import Logic.Coordinate.Coordinate;
import Logic.Exceptions.*;


import java.io.Serializable;
import java.util.List;
import java.util.Map;
import java.util.Set;

public interface ReadonlySheet extends Serializable {
    //int version = 0;
    //Map<Coordinate, ReadonlyCell> activeCells = null;
    int getChangedCellsCount();

    int getVersion();

    ReadonlyCell getCell(int row, int column) throws CoordinateOutOfRangeException;

    Map<Coordinate, ReadonlyCell> getActiveCells();
    Map<String, Set<Coordinate>> getExisitingRanges();
    Set<Coordinate> getRange(String rangeName);
    void addNewRange(String range, int rowStart, int columnStart, int rowEnd, int columnEnd)throws RangeAlreadyExistsException, RangeCoordinateOutOfRangeException, RangeStartIndexLowerThenEndException;
    void removeRange(String range) throws RangeInUseException;
    Set<ReadonlyCell> getCellsThatAreUsingThisRange(String range);
    public ReadonlySheet publicCopySheet();
    public String getUpdater();
    public List<String> getNumericCells();
}
    

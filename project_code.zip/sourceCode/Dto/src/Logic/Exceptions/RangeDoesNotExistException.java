package Logic.Exceptions;

public class RangeDoesNotExistException extends RuntimeException {
    private String rangeName;
    public RangeDoesNotExistException(String rangeName) {
        this.rangeName = rangeName;
    }

    public String getRangeName() {
        return rangeName;
    }
}

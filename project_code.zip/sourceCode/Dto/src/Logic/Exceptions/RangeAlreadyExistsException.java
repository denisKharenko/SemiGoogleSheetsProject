package Logic.Exceptions;

public class RangeAlreadyExistsException extends Exception{
    private String rangeName;
    public RangeAlreadyExistsException(String rangeName) {
        this.rangeName = rangeName;
    }

    public String getRangeName() {
        return rangeName;
    }
}

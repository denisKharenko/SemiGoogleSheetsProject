package Logic.Exceptions;

public class InvalidAmountOfArgumentsException extends IllegalArgumentException {
    private String functionName;
    private int expectedAmount;
    private int actualAmount;

    public InvalidAmountOfArgumentsException(String functionName, int expectedAmount, int actualAmount) {
        super("Invalid amount of arguments for function " + functionName + ". Expected: " + expectedAmount + ", actual: " + actualAmount);
        this.functionName = functionName;
        this.expectedAmount = expectedAmount;
        this.actualAmount = actualAmount;
    }

    public int getActualAmount() {
        return actualAmount;
    }

    public int getExpectedAmount() {
        return expectedAmount;
    }

    public String getFunctionName() {
        return functionName;
    }
}

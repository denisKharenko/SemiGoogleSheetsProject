package Logic.Exceptions;

import java.util.List;

public class InvalidFunctionArgumentException extends IllegalArgumentException {
    private String functionName;
    private List<String> expectedTypes;
    private List<String> actualTypes;
    private int amountOfArguments;
    public InvalidFunctionArgumentException(String functionName, List<String> expectedTypes, List<String> actualTypes, int amountOfArguments) {
        super("Invalid argument types for function " + functionName + ". Expected: " + expectedTypes + ", actual: " + actualTypes);
        this.functionName = functionName;
        this.expectedTypes = expectedTypes;
        this.actualTypes = actualTypes;
        this.amountOfArguments = amountOfArguments;
    }

    public int getAmountOfArguments() {
        return amountOfArguments;
    }

    public List<String> getActualTypes() {
        return actualTypes;
    }

    public List<String> getExpectedTypes() {
        return expectedTypes;
    }

    public String getFunctionName() {
        return functionName;
    }
}

package Logic.Exceptions;

public class FunctionCouldntCalculateException extends Exception {
    private Class type;
    public FunctionCouldntCalculateException(Class type) {
        this.type = type;
    }
    public Class getType() {
        return type;
    }
}

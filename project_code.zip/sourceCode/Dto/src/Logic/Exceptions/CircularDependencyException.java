package Logic.Exceptions;


import Logic.Cell.api.ReadonlyCell;

import java.util.ArrayList;
import java.util.List;

public class CircularDependencyException extends RuntimeException {
    private int row;
    private int column;
    private List<ReadonlyCell> dependencyPath;
    List<String> pathCoordinates;

    public CircularDependencyException(int row, int column, List<ReadonlyCell> dependencyPath) {
        this.row = row;
        this.column = column;
        this.dependencyPath = dependencyPath;
        this.pathCoordinates = getDependencyPathCoordinates();
    }
    public List<String> getDependencyPathCoordinates() {
        List<String> coordinates = new ArrayList<>();
        coordinates.add("Row,Column: ");
        for (ReadonlyCell cell : dependencyPath) {
            coordinates.add("("+cell.getCoordinate().getRow() + "," + cell.getCoordinate().getColumn()+") ");
        }
        return coordinates;
    }

    public int getRow() {
        return row;
    }

    public int getColumn() {
        return column;
    }

    public List<ReadonlyCell> getDependencyPath() {
        return dependencyPath;
    }
}

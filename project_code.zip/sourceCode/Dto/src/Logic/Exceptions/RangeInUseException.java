package Logic.Exceptions;

public class RangeInUseException extends Exception {
    private String rangeName;
    private int row;
    private int column;

    public RangeInUseException(String rangeName, int row, int column) {
        this.rangeName = rangeName;
        this.row = row;
        this.column = column;
    }

    public String getRangeName() {
        return rangeName;
    }
    public int getRow() {
        return row;
    }
    public int getColumn() {
        return column;
    }
}

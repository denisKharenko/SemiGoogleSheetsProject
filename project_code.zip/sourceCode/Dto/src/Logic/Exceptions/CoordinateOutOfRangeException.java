package Logic.Exceptions;

public class CoordinateOutOfRangeException extends Exception {
    private int index;
    private int maximumRange;
    boolean isRow;
    public CoordinateOutOfRangeException(int index, int maximumRange, boolean isRow) {
        this.index = index;
        this.maximumRange = maximumRange;
        this.isRow = isRow;
    }
    public int getIndex() {
        return index;
    }
    public int getMaximumRange() {
        return maximumRange;
    }
    public boolean isRow() {
        return isRow;
    }
}

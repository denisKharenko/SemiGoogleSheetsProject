package Logic.Exceptions;

public class FileTypeIsntSupportedException extends Exception {

}

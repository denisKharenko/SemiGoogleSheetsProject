package Logic.Exceptions;

public class CoordinateParamOutOfRangeException extends Exception{
    private int param;
    private int maximumRange;
    boolean isRow;
    public CoordinateParamOutOfRangeException(int index, int maximumRange, boolean isRow) {
        this.param = index;
        this.maximumRange = maximumRange;
        this.isRow = isRow;
    }
    public int getParam() {
        return param;
    }
    public int getMaximumRange() {
        return maximumRange;
    }
    public boolean isRow() {
        return isRow;
    }
}

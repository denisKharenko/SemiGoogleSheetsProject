package Logic.Exceptions;

public class RangeStartIndexLowerThenEndException extends Exception {
    private String rangeName;
    private int startIndex;
    private int endIndex;
    boolean isRow;

    public RangeStartIndexLowerThenEndException(String rangeName, int startIndex, int endIndex, boolean isRow) {
        this.rangeName = rangeName;
        this.startIndex = startIndex;
        this.endIndex = endIndex;
        this.isRow = isRow;
    }
    public String getRangeName() {
        return rangeName;
    }
    public int getStartIndex() {
        return startIndex;
    }
    public int getEndIndex() {
        return endIndex;
    }
    public boolean isRow() {
        return isRow;
    }
}

package Logic.Exceptions;

public class RangeContainsNoAppropriateCellsException extends RuntimeException {
    private String rangeName;
    private String missingType;
    public RangeContainsNoAppropriateCellsException(String rangeName, String missingType) {
        this.rangeName = rangeName;
        this.missingType = missingType;
    }

    public String getRangeName() {
        return rangeName;
    }
    public String getMissingType() {
        return missingType;
    }
}

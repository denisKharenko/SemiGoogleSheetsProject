package Logic.Exceptions;

public class RangeCoordinateOutOfRangeException extends Exception{
    private int index;
    private int maximumRange;
    boolean isRow;
    private String rangeName;
    public RangeCoordinateOutOfRangeException(int index, int maximumRange, boolean isRow, String rangeName) {
        this.index = index;
        this.maximumRange = maximumRange;
        this.isRow = isRow;
        this.rangeName = rangeName;
    }
    public int getIndex() {
        return index;
    }
    public int getMaximumRange() {
        return maximumRange;
    }
    public boolean isRow() {
        return isRow;
    }
    public String getRangeName() {
        return rangeName;
    }
}

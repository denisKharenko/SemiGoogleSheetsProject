package Logic.Exceptions;

public class FunctionDoesNotExistException extends Exception {
   private String FunctionName;
    public FunctionDoesNotExistException(String functionName) {
        this.FunctionName = functionName;
    }
    public String getFunctionName() {
        return FunctionName;
    }
}

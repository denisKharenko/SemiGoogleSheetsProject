package Logic.Exceptions;

public class StartIndexLowerThenEndException extends RuntimeException {
    private String functionName;
    private int startIndex;
    private int endIndex;

    public StartIndexLowerThenEndException(String functionName, int startIndex, int endIndex) {
        this.functionName = functionName;
        this.startIndex = startIndex;
        this.endIndex = endIndex;
    }
    public String getFunctionName() {
        return functionName;
    }
    public int getStartIndex() {
        return startIndex;
    }
    public int getEndIndex() {
        return endIndex;
    }
}

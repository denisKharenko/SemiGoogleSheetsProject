package Logic.Exceptions;

public class InvalidExcelFormatException extends RuntimeException {
    private String input;

    public InvalidExcelFormatException(String input) {
        this.input = input;
    }
    public String getInput() {
        return input;
    }
}

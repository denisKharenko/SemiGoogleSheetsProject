package serializerForShticell.deserializers;

import Logic.Cell.api.Cell;
import Logic.Cell.api.ReadonlyCell;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonParseException;
import engine.Cell.impl.CellImpl;

import java.lang.reflect.Type;

public class CellDeserializer implements JsonDeserializer<Cell> {
    @Override
    public Cell deserialize(JsonElement json, Type typeOfT, JsonDeserializationContext context) throws JsonParseException {
        CellImpl cell = context.deserialize(json.getAsJsonObject().get("cell"), ReadonlyCell.class);
        return cell;
    }
}

package serializerForShticell.deserializers;

import Logic.Coordinate.Coordinate;
import Logic.Coordinate.CoordinateFactory;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonParseException;

import java.lang.reflect.Type;

public class CoordinateDeserializer implements JsonDeserializer<Coordinate>{
    @Override
    public Coordinate deserialize(JsonElement json, Type typeOfT, JsonDeserializationContext context) throws JsonParseException {
        int row = json.getAsJsonObject().get("row").getAsInt();
        int column = json.getAsJsonObject().get("column").getAsInt();
        return CoordinateFactory.createCoordinate(row, column);
    }
}

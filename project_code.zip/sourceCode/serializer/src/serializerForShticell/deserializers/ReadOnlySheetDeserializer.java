package serializerForShticell.deserializers;

import Logic.sheet.api.ReadonlySheet;
import Logic.sheet.api.Sheet;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonParseException;
import engine.sheet.impl.SheetImpl;
import serializerForShticell.serializers.ReadOnlySheetSerializer;

import java.lang.reflect.Type;

public class ReadOnlySheetDeserializer implements JsonDeserializer<ReadonlySheet> {
    SheetDeserializer sheetDeserializer = new SheetDeserializer();
    @Override
    public ReadonlySheet deserialize(JsonElement json, Type typeOfT, JsonDeserializationContext context) throws JsonParseException {
        SheetImpl sheet = (SheetImpl)sheetDeserializer.deserialize(json, typeOfT, context);
        return sheet;
    }
}

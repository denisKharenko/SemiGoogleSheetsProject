package serializerForShticell.deserializers;

import Logic.Cell.api.CellType;
import Logic.Cell.api.EffectiveValue;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonParseException;
import engine.Cell.impl.EffectiveValueImpl;

import java.lang.reflect.Type;

public class EffectiveValueDeserializer implements JsonDeserializer<EffectiveValue> {
    @Override
    public EffectiveValue deserialize(JsonElement json, Type typeOfT, JsonDeserializationContext context) throws JsonParseException {
        CellType cellType = context.deserialize(json.getAsJsonObject().get("cellType"), CellType.class);
        Object value;
        if(cellType == CellType.BOOLEAN) {
            value = json.getAsJsonObject().get("value").getAsBoolean();
        }
        else if(cellType == CellType.NUMERIC) {
            value = json.getAsJsonObject().get("value").getAsDouble();
        }
        else {
            value = json.getAsJsonObject().get("value").getAsString();
        }
        return new EffectiveValueImpl(cellType, value);
    }
}

package serializerForShticell.deserializers;

import Logic.api.Logic;
import Logic.permission.Permission;
import Logic.permission.PermissionRequest;
import Logic.sheet.api.Sheet;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonParseException;
import com.google.gson.reflect.TypeToken;
import engine.impl.LogicImpl;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class LogicDeserializer implements JsonDeserializer<Logic> {
    /*
    public LogicImpl(int rows, int columns, String SheetName, int width, int height) {
        this.SheetName = SheetName;
        this.rows = rows;
        this.columns = columns;
        this.width = width;
        this.height = height;
        sheets = new ArrayList<Sheet>();
        private Map<String, Permission> permissionsForSheets;
    }

     */
    @Override
    public Logic deserialize(JsonElement json, Type typeOfT, JsonDeserializationContext context) throws JsonParseException {

        // extract raw data
        String sheetName = json.getAsJsonObject().get("SheetName").getAsString();
        int rows = json.getAsJsonObject().get("rows").getAsInt();
        int columns =  json.getAsJsonObject().get("columns").getAsInt();
        int width = json.getAsJsonObject().get("width").getAsInt();
        int height = json.getAsJsonObject().get("height").getAsInt();
        String ownerName = json.getAsJsonObject().get("ownerName").getAsString();
        Type mapOfPermissionsType = new TypeToken<Map<String, Permission>>() { }.getType();
        Map<String, Permission> permissionsForSheets = json.getAsJsonObject().get("permissionsForSheets").getAsJsonObject().size() == 0 ? null : context.deserialize(json.getAsJsonObject().get("permissionsForSheets"), mapOfPermissionsType);
        Type listOfSheetsType = new TypeToken<List<Sheet>>() { }.getType();
        List<Sheet> sheets = json.getAsJsonObject().get("sheets").getAsJsonArray().size() == 0 ? new ArrayList<Sheet>() : context.deserialize(json.getAsJsonObject().get("sheets"), listOfSheetsType);
        Type listOfPermissionRequestsType = new TypeToken<List<PermissionRequest>>() { }.getType();
        List<PermissionRequest> permissionRequestsForSheets = json.getAsJsonObject().get("permissionRequestsForSheets").getAsJsonArray().size() == 0 ? new ArrayList<PermissionRequest>() : context.deserialize(json.getAsJsonObject().get("permissionRequestsForSheets"), listOfPermissionRequestsType);
        LogicImpl result = new LogicImpl(rows, columns, sheetName, width, height, permissionsForSheets, permissionRequestsForSheets, ownerName);
        result.getSheets().addAll(sheets);
        for(Sheet sheet: result.getSheets())
        {
            sheet.setLogic(result);
        }

        return result;
    }
}



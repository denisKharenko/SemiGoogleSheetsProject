package serializerForShticell.deserializers;

import Logic.Cell.api.EffectiveValue;
import Logic.Cell.api.ReadonlyCell;
import Logic.Coordinate.Coordinate;
import Logic.sheet.api.ReadonlySheet;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonParseException;
import com.google.gson.reflect.TypeToken;
import engine.Cell.impl.CellImpl;

import java.lang.reflect.Type;
import java.util.HashSet;
import java.util.Set;

public class ReadOnlyCellDeserializer implements JsonDeserializer<ReadonlyCell> {
    /*
    private final Coordinate coordinate;
    private String originalValue;
    private EffectiveValue effectiveValue;
    private int version;
    private final Set<ReadonlyCell> dependsOn;
    private final Set<ReadonlyCell> influencingOn;
    private final ReadonlySheet sheet;
     */
    @Override
    public ReadonlyCell deserialize(JsonElement json, Type typeOfT, JsonDeserializationContext context) throws JsonParseException {
        // extract raw data
        Coordinate coordinate = context.deserialize(json.getAsJsonObject().get("coordinate"), Coordinate.class);
        String originalValue = json.getAsJsonObject().get("originalValue").getAsString();
        int version = json.getAsJsonObject().get("version").getAsInt();
        String lastUpdater = json.getAsJsonObject().get("lastUpdater").getAsString();
        ReadonlySheet sheet = context.deserialize(json.getAsJsonObject().get("sheet"), ReadonlySheet.class);
        EffectiveValue effectiveValue = context.deserialize(json.getAsJsonObject().get("effectiveValue"), EffectiveValue.class);
        // Deserialize Set<ReadonlyCell> for dependsOn and influencingOn
        Type readonlyCellCoordinateSetType = new TypeToken<Set<Coordinate>>() {}.getType();
        Set<Coordinate> dependsOn = context.deserialize(json.getAsJsonObject().get("dependsOn"), readonlyCellCoordinateSetType);
        Set<Coordinate> influencingOn = context.deserialize(json.getAsJsonObject().get("influencingOn"), readonlyCellCoordinateSetType);
        CellImpl result = new CellImpl(coordinate.getRow(),coordinate.getColumn() , originalValue, version, sheet);
        result.setEffectiveValueForFilterAndSort(effectiveValue);
        Set<ReadonlyCell> dependsOnCells = new HashSet<>();
        Set<ReadonlyCell> influencingOnCells = new HashSet<>();
        for(Coordinate cor: dependsOn)
        {
            dependsOnCells.add(new CellImpl(cor.getRow(), cor.getColumn(), "", 0, sheet));
        }
        for(Coordinate cor: influencingOn)
        {
            influencingOnCells.add(new CellImpl(cor.getRow(), cor.getColumn(), "", 0, sheet));
        }
        result.getDependsOn().addAll(dependsOnCells);
        result.getInfluencingOn().addAll(influencingOnCells);
        result.setLastUpdater(lastUpdater);
        return result;
    }
}

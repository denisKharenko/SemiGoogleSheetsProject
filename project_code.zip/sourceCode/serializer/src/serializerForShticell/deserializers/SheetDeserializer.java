package serializerForShticell.deserializers;

import Logic.Cell.api.Cell;
import Logic.Cell.api.ReadonlyCell;
import Logic.Coordinate.Coordinate;
import Logic.sheet.api.Sheet;
import Logic.api.Logic;
import com.google.gson.*;
import com.google.gson.reflect.TypeToken;
import engine.impl.LogicImpl;
import engine.sheet.impl.SheetImpl;
import org.glassfish.jaxb.core.v2.TODO;

import java.lang.reflect.Type;
import java.util.*;

public class SheetDeserializer implements JsonDeserializer<Sheet> {
    /*
    private int version;
    private Map<Coordinate, ReadonlyCell> activeCells;
    Logic logic;
    private Map<String, Set<Coordinate>> ranges;
     */
    @Override
    public Sheet deserialize(JsonElement json, Type typeOfT, JsonDeserializationContext context) throws JsonParseException {
        int version = json.getAsJsonObject().get("version").getAsInt();
        String lastUpdater = json.getAsJsonObject().get("updater").getAsString();
        //Logic logic = context.deserialize(json.getAsJsonObject().get("logic"), Logic.class); property wasnt serialized to avoid circular dependency
        Logic logic = new LogicImpl(-1, -1, "", -1, -1, " ");
        Type mapStringToSetCoordinateType = new TypeToken<Map<String, Set<Coordinate>>>() { }.getType();
        JsonElement rangesElement = json.getAsJsonObject().get("ranges");

        Map<String, Set<Coordinate>> ranges;

        if (rangesElement.isJsonObject()) {
            // Deserialize directly as a map if it's a JSON object
            ranges = context.deserialize(rangesElement, mapStringToSetCoordinateType);
        } else if (rangesElement.isJsonArray()) {
            // Handle the array format as in your current code
            ranges = new HashMap<>();
            for (JsonElement rangeElement : rangesElement.getAsJsonArray()) {
                JsonObject rangeObject = rangeElement.getAsJsonObject();
                String rangeName = rangeObject.get("rangeName").getAsString();
                Set<Coordinate> coordinates = context.deserialize(rangeObject.get("coordinates"), new TypeToken<Set<Coordinate>>() {}.getType());
                ranges.put(rangeName, coordinates);
            }
        } else {
            throw new JsonParseException("Expected an array or object for 'ranges' but found: " + rangesElement);
        }
        SheetImpl sheet = new SheetImpl(logic,version, ranges, lastUpdater);
        Type mapCoordinateToReadonlyCellType = new TypeToken<Map<Coordinate, ReadonlyCell>>() { }.getType();
        // Deserialize 'activeCells' from an array format and construct the map manually
        Map<Coordinate, ReadonlyCell> activeCells = new HashMap<>();
        JsonArray activeCellsArray = json.getAsJsonObject().getAsJsonArray("activeCells");

        for (JsonElement activeCellElement : activeCellsArray) {
            JsonObject activeCellObject = activeCellElement.getAsJsonObject();
            Coordinate coordinate = context.deserialize(activeCellObject.get("coordinate"), Coordinate.class);
            ReadonlyCell cell = context.deserialize(activeCellObject.get("cell"), ReadonlyCell.class);

            activeCells.put(coordinate, cell);
        }

        sheet.getActiveCells().putAll(activeCells);/// i think i should add after here to go threw the cells and add the refference to this sheet and something simmilar in the logic deserializer
        for(ReadonlyCell cell : activeCells.values()){
            if (cell instanceof Cell) {
                ((Cell) cell).setSheet(sheet);
            }
        }
        for (ReadonlyCell cell : activeCells.values()) {
            // Restore dependsOn
            Set<ReadonlyCell> updatedDependsOn = new HashSet<>();
            for (ReadonlyCell dep : cell.getDependsOn()) {
                if (dep instanceof Cell) {
                    ReadonlyCell updatedDep = activeCells.get(dep.getCoordinate());
                    if (updatedDep != null) {
                        updatedDependsOn.add(updatedDep);
                    }
                }
            }
            cell.getDependsOn().clear();
            cell.getDependsOn().addAll(updatedDependsOn);

            // Restore influencingOn
            Set<ReadonlyCell> updatedInfluencingOn = new HashSet<>();
            for (ReadonlyCell infl : cell.getInfluencingOn()) {
                if (infl instanceof Cell) {
                    ReadonlyCell updatedInfl = activeCells.get(infl.getCoordinate());
                    if (updatedInfl != null) {
                        updatedInfluencingOn.add(updatedInfl);
                    }
                }
            }
            cell.getInfluencingOn().clear();
            cell.getInfluencingOn().addAll(updatedInfluencingOn);
        }
        return sheet;
    }
}

package serializerForShticell.deserializers;

import Logic.permission.Permission;
import Logic.permission.PermissionRequest;
import Logic.permission.PermissionRequestStatus;
import com.google.gson.*;
import engine.PermissionImpl.PermissionRequestImpl;

import java.lang.reflect.Type;

public class PermissionRequestDeserializer implements JsonDeserializer<PermissionRequest> {
    @Override
    public PermissionRequest deserialize(JsonElement json, Type typeOfT, JsonDeserializationContext context) throws JsonParseException {
        JsonObject jsonObject = json.getAsJsonObject();
        Permission permission = Permission.valueOf(jsonObject.get("permission").getAsString());
        String submitterName = jsonObject.get("submitterName").getAsString();
        String sheetName = jsonObject.get("sheetName").getAsString();
        String sheetOwnerName = jsonObject.get("sheetOwnerName").getAsString();
        PermissionRequestStatus status = PermissionRequestStatus.valueOf(jsonObject.get("status").getAsString());
        PermissionRequest result = new PermissionRequestImpl(permission, submitterName, sheetName, sheetOwnerName);
        ((PermissionRequestImpl) result).setStatus(status);
        return result;
    }
}

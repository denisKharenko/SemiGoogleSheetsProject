package serializerForShticell.Util;

import Logic.Cell.api.Cell;
import Logic.Cell.api.EffectiveValue;
import Logic.Cell.api.ReadonlyCell;
import Logic.Coordinate.Coordinate;
import Logic.api.Logic;
import Logic.permission.PermissionRequest;
import Logic.sheet.api.ReadonlySheet;
import Logic.sheet.api.Sheet;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import serializerForShticell.deserializers.*;
import serializerForShticell.serializers.*;

public class Constants {

    public final static Gson GSON_INSTANCE = new GsonBuilder()
            .serializeNulls() // Include null values in serialization
            .registerTypeAdapter(Cell.class, new CellDeserializer())
            .registerTypeAdapter(ReadonlyCell.class, new ReadOnlyCellDeserializer())
            .registerTypeAdapter(Cell.class, new CellSerializer())
            .registerTypeAdapter(ReadonlyCell.class, new ReadOnlyCellSerializer())
            .registerTypeAdapter(Logic.class, new LogicDeserializer())
            .registerTypeAdapter(Logic.class, new LogicSerializer())
            .registerTypeAdapter(Sheet.class, new SheetDeserializer())
            .registerTypeAdapter(Sheet.class, new SheetSerializer())
            .registerTypeAdapter(ReadonlySheet.class, new ReadOnlySheetSerializer())
            .registerTypeAdapter(ReadonlySheet.class, new ReadOnlySheetDeserializer())
            .registerTypeAdapter(Coordinate.class, new CoordinateDeserializer())
            .registerTypeAdapter(Coordinate.class, new CoordinateSerializer())
            .registerTypeAdapter(EffectiveValue.class, new EffectiveValueDeserializer())
            .registerTypeAdapter(EffectiveValue.class, new EffectiveValueSerializer())
            .registerTypeAdapter(PermissionRequest.class, new PermissionRequestDeserializer())
            .registerTypeAdapter(PermissionRequest.class, new PermissionRequestSerializer())
            .setPrettyPrinting()
            .create();
}

package serializerForShticell.serializers;

import Logic.api.Logic;
import Logic.permission.Permission;
import Logic.permission.PermissionRequest;
import Logic.sheet.api.Sheet;
import com.google.gson.*;
import engine.impl.LogicImpl;

import java.lang.reflect.Type;
import java.util.Map;

public class LogicSerializer implements JsonSerializer<Logic> {
    /*
    public LogicImpl(int rows, int columns, String SheetName, int width, int height) {
        this.SheetName = SheetName;
        this.rows = rows;
        this.columns = columns;
        this.width = width;
        this.height = height;
        sheets = new ArrayList<Sheet>();
        private Map<String, Permission> permissionsForSheets;
        private List<PermissionRequest> permissionRequestsForSheets;
    }

     */
    @Override
    public JsonElement serialize(Logic src, Type typeOfSrc, JsonSerializationContext context) {
        JsonObject logicObject = new JsonObject();
        logicObject.addProperty("SheetName", src.getSheetName());
        logicObject.addProperty("rows", src.getRows());
        logicObject.addProperty("columns", src.getColumns());
        logicObject.addProperty("width", src.getWidth());
        logicObject.addProperty("height", src.getHeight());
        logicObject.addProperty("ownerName", src.getOwnerName());
        LogicImpl logicImpl = (LogicImpl) src;
        // Create a JsonArray for sheets
        JsonArray sheetsArray = new JsonArray();
        // Serialize each sheet and add it to the sheetsArray
        for (Sheet sheet : logicImpl.getSheets()) {
            JsonObject sheetJson = context.serialize(sheet, Sheet.class).getAsJsonObject();

            // Add a reference to the Logic (or any other property you need)
            //sheetJson.add("logic", logicObject);//to avoid circular reference

            // Add the sheet JSON object to the sheetsArray
            sheetsArray.add(sheetJson);
        }
        // Add the sheetsArray to the logicObject
        logicObject.add("sheets", sheetsArray);
        // serialize permissionRequestsForSheets as a JsonArray
        JsonArray permissionRequestArray = new JsonArray();
        for(PermissionRequest permissionRequest : src.getPermissionRequestsForSheets())
        {
            JsonObject permissionRequestJson = context.serialize(permissionRequest, PermissionRequest.class).getAsJsonObject();
            permissionRequestArray.add(permissionRequestJson);
        }
        logicObject.add("permissionRequestsForSheets", permissionRequestArray);
        // Serialize permissionsForSheets as a JsonObject
        JsonObject permissionsObject = new JsonObject();

        for (Map.Entry<String, Permission> entry : logicImpl.getPermissions().entrySet()) {
            permissionsObject.add(entry.getKey(), context.serialize(entry.getValue()));
        }
        logicObject.add("permissionsForSheets", permissionsObject);

        return logicObject;
    }

}

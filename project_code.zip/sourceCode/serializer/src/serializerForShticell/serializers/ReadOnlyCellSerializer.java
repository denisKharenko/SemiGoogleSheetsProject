package serializerForShticell.serializers;

import Logic.Cell.api.Cell;
import Logic.Cell.api.ReadonlyCell;
import com.google.gson.*;

import java.lang.reflect.Type;

public class ReadOnlyCellSerializer implements JsonSerializer<ReadonlyCell> {
    /*
    private final Coordinate coordinate;
    private String originalValue;
    private EffectiveValue effectiveValue;
    private int version;
    private final Set<ReadonlyCell> dependsOn;
    private final Set<ReadonlyCell> influencingOn;
    private final ReadonlySheet sheet;
     */
    @Override//check if somehow i need to add the sheet property to each of the depends on cells
    public JsonElement serialize(ReadonlyCell src, Type typeOfSrc, JsonSerializationContext context) {
        JsonObject cellObject = new JsonObject();
        cellObject.add("coordinate", context.serialize(src.getCoordinate()));
        cellObject.addProperty("originalValue", src.getOriginalValue());
        cellObject.addProperty("version", src.getVersion());
        cellObject.add("effectiveValue", context.serialize(src.getEffectiveValue()));
        // Serialize Set<ReadonlyCell> for dependsOn and influencingOn
        // Serialize coordinates of cells in dependsOn
        JsonArray dependsOnArray = new JsonArray();
        for (ReadonlyCell dep : src.getDependsOn()) {
            dependsOnArray.add(context.serialize(dep.getCoordinate()));
        }
        cellObject.add("dependsOn", dependsOnArray);

        // Serialize coordinates of cells in influencingOn
        JsonArray influencingOnArray = new JsonArray();
        for (ReadonlyCell infl : src.getInfluencingOn()) {
            influencingOnArray.add(context.serialize(infl.getCoordinate()));
        }
        cellObject.add("influencingOn", influencingOnArray);
        cellObject.addProperty("lastUpdater", src.getLastUpdater());
        return cellObject;
    }
}

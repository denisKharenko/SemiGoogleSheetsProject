package serializerForShticell.serializers;

import Logic.Cell.api.EffectiveValue;
import com.google.gson.*;

import java.lang.reflect.Type;

public class EffectiveValueSerializer implements JsonSerializer<EffectiveValue> {
    /*
    private CellType cellType;
    private Object value;
     */
    @Override
    public JsonElement serialize(EffectiveValue src, Type typeOfSrc, JsonSerializationContext context) {
        JsonObject effectiveValueObject = new JsonObject();

        // Serialize the cellType
        effectiveValueObject.add("cellType", context.serialize(src.getCellType()));

        // Serialize the value based on its actual type
        if (src.getValue() != null) {
            // Using context.serialize to allow for correct type handling
            effectiveValueObject.add("value", context.serialize(src.getValue()));
        } else {
            // Handle the case where value is null (optional)
            effectiveValueObject.add("value", JsonNull.INSTANCE);
        }
        return effectiveValueObject;
    }
}

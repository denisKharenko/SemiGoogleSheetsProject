package serializerForShticell.serializers;

import Logic.Cell.api.Cell;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonSerializationContext;
import com.google.gson.JsonSerializer;

import java.lang.reflect.Type;

public class CellSerializer implements JsonSerializer<Cell> {
    ReadOnlyCellSerializer readOnlyCellSerializer = new ReadOnlyCellSerializer();
    @Override
    public JsonElement serialize(Cell src, Type typeOfSrc, JsonSerializationContext context) {
        JsonObject cellObject = readOnlyCellSerializer.serialize(src, typeOfSrc, context).getAsJsonObject();
        return cellObject;
    }
}

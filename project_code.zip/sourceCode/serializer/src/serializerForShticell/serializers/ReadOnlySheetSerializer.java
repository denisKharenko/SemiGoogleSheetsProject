package serializerForShticell.serializers;

import Logic.Cell.api.ReadonlyCell;
import Logic.Coordinate.Coordinate;
import Logic.sheet.api.ReadonlySheet;
import com.google.gson.*;

import java.lang.reflect.Type;
import java.util.Map;
import java.util.Set;

public class ReadOnlySheetSerializer implements JsonSerializer<ReadonlySheet> {
    /*
   private int version;
   private Map<Coordinate, ReadonlyCell> activeCells;
   Logic logic;
   private Map<String, Set<Coordinate>> ranges;
    */
    @Override
    public JsonElement serialize(ReadonlySheet src, Type typeOfSrc, JsonSerializationContext context) {
        JsonObject sheetObject = new JsonObject();
        sheetObject.addProperty("version", src.getVersion());
        sheetObject.addProperty("updater", src.getUpdater());
        // Create a JsonArray for ranges
        JsonArray rangesArray = new JsonArray();

        // Serialize each range and add it to the rangesArray
        for (Map.Entry<String, Set<Coordinate>> range : src.getExisitingRanges().entrySet()) {
            JsonObject rangeJson = new JsonObject();
            rangeJson.addProperty("rangeName", range.getKey());
            // Create a JsonArray for coordinates
            JsonArray coordinatesArray = new JsonArray();
            // Serialize each coordinate and add it to the coordinatesArray
            for (Coordinate coordinate : range.getValue()) {
                JsonObject coordinateJson = new JsonObject();
                coordinateJson.addProperty("row", coordinate.getRow());
                coordinateJson.addProperty("column", coordinate.getColumn());
                coordinatesArray.add(coordinateJson);
            }
            // Add the coordinatesArray to the rangeJson
            rangeJson.add("coordinates", coordinatesArray);
            // Add the range JSON object to the rangesArray
            rangesArray.add(rangeJson);
        }
        // Add the rangesArray to the sheetObject
        sheetObject.add("ranges", rangesArray);
        // Create a JsonArray for activeCells
        JsonArray activeCellsArray = new JsonArray();
        // Serialize each activeCell and add it to the activeCellsArray
        for (Map.Entry<Coordinate, ReadonlyCell> activeCell : src.getActiveCells().entrySet()) {
            JsonObject activeCellJson = new JsonObject();
            activeCellJson.add("coordinate", context.serialize(activeCell.getKey(), Coordinate.class));
            activeCellJson.add("cell", context.serialize(activeCell.getValue(), ReadonlyCell.class));
            //activeCellJson.add("sheet", sheetObject);//add the sheetObject to the activeCellJson
            activeCellsArray.add(activeCellJson);
        }
        // Add the activeCellsArray to the sheetObject
        sheetObject.add("activeCells", activeCellsArray);
        return sheetObject;
    }
}

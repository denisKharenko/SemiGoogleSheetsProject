package serializerForShticell.serializers;


import Logic.permission.PermissionRequest;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonSerializationContext;
import com.google.gson.JsonSerializer;

import java.lang.reflect.Type;

public class PermissionRequestSerializer implements JsonSerializer<PermissionRequest> {
    @Override
    public JsonElement serialize(PermissionRequest src, Type typeOfSrc, JsonSerializationContext context) {
        JsonObject permissionRequestObject = new JsonObject();

        // Serialize the permission
        permissionRequestObject.add("permission", context.serialize(src.getPermission()));

        // Serialize the submitterName
        permissionRequestObject.addProperty("submitterName", src.getSubmitterName());

        // Serialize the sheetName
        permissionRequestObject.addProperty("sheetName", src.getSheetName());

        // Serialize the sheetOwnerName
        permissionRequestObject.addProperty("sheetOwnerName", src.getSheetOwnerName());

        // Serialize the status
        permissionRequestObject.add("status", context.serialize(src.getStatus()));

        return permissionRequestObject;
    }
}

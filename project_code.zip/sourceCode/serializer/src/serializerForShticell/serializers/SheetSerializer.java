package serializerForShticell.serializers;

import Logic.sheet.api.Sheet;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonSerializationContext;
import com.google.gson.JsonSerializer;

import java.lang.reflect.Type;

public class SheetSerializer implements JsonSerializer<Sheet> {
    ReadOnlySheetSerializer readOnlySheetSerializer = new ReadOnlySheetSerializer();
    @Override
    public JsonElement serialize(Sheet src, Type typeOfSrc, JsonSerializationContext context) {
        JsonObject sheetObject = readOnlySheetSerializer.serialize(src, typeOfSrc, context).getAsJsonObject();
        return sheetObject;
    }
}

package engine.PermissionImpl;

import Logic.permission.Permission;
import Logic.permission.PermissionRequest;
import Logic.permission.PermissionRequestStatus;
import engine.Cell.impl.CellImpl;

import java.util.Objects;

public class PermissionRequestImpl implements PermissionRequest {
    private final Permission permission;
    private final String submitterName;
    private final String sheetName;
    private PermissionRequestStatus status;
    private final String sheetOwnerName;

    public PermissionRequestImpl(Permission permission, String submitterName, String sheetName, String sheetOwnerName) {
        this.permission = permission;
        this.submitterName = submitterName;
        this.sheetName = sheetName;
        this.status = PermissionRequestStatus.PENDING;
        this.sheetOwnerName = sheetOwnerName;
    }

    @Override
    public Permission getPermission() {
        return permission;
    }

    @Override
    public String getSubmitterName() {
        return submitterName;
    }

    @Override
    public String getSheetName() {
        return sheetName;
    }

    @Override
    public String getSheetOwnerName() {
        return sheetOwnerName;
    }
    @Override
    public PermissionRequestStatus getStatus()
    {
        return status;
    }
    public void setStatus(PermissionRequestStatus status)
    {
        this.status = status;
    }
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        PermissionRequestImpl that = (PermissionRequestImpl) obj;
        return permission == that.permission && submitterName.equals(that.submitterName) && sheetName.equals(that.sheetName) && status == that.status && sheetOwnerName.equals(that.sheetOwnerName);
    }

    @Override
    public int hashCode() {
        return Objects.hash(permission, submitterName, sheetName, status, sheetOwnerName);
    }
}

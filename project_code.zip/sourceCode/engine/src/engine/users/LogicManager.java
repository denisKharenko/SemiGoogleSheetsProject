package engine.users;

import Logic.api.Logic;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class LogicManager {
    private final Map<String, Map<String,Logic>> usersLogicMap;
    public LogicManager()
    {
        usersLogicMap = new ConcurrentHashMap<>();
    }
    public synchronized void createUsersLogicList(String username) {
        usersLogicMap.put(username, new HashMap<>());
    }
    public void addLogicToUser(String username, Logic logic) throws IllegalArgumentException {
        Map<String,Logic> userLogics = usersLogicMap.get(username);
        /*
        for (Logic existingLogic : userLogics) {
            if (existingLogic.getSheetName().equals(logic.getSheetName())) {
                throw new IllegalArgumentException("Duplicate logic entry for user: " + username + " with sheet name: " + logic.getSheetName());
            }
        }
         */
        if(userLogics.containsKey(logic.getSheetName()))
        {
            throw new IllegalArgumentException("Duplicate logic entry for user: " + username + " with sheet name: " + logic.getSheetName());
        }
        userLogics.put(logic.getSheetName(), logic);
    }

    public synchronized void removeUser(String username) {
        usersLogicMap.remove(username);
    }

    public synchronized Map<String, Map<String,Logic>> getUsersLogicMap() {
        return Collections.unmodifiableMap(usersLogicMap);
    }

}

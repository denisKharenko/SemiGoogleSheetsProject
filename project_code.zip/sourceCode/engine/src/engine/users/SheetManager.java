package engine.users;

import Logic.api.Logic;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class SheetManager {
    private final Set<String> existingSheetNames;
    public SheetManager()
    {
        existingSheetNames = new HashSet<>();
    }

    public void addNameToSheetManager(String SheetName) throws IllegalArgumentException {
        synchronized(existingSheetNames) {
            if (existingSheetNames.contains(SheetName)) {
                throw new IllegalArgumentException("sheet name: " + SheetName + " already exists");
            }
            existingSheetNames.add(SheetName);
        }
    }

    public synchronized Set<String> getSheetManager() {
        return existingSheetNames;
    }
}

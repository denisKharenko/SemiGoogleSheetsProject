package engine.Parser;

import Logic.Cell.api.CellType;
import Logic.Exceptions.InvalidAmountOfArgumentsException;
import Logic.Exceptions.InvalidExcelFormatException;
import Logic.Exceptions.InvalidFunctionArgumentException;
import Logic.Expression.api.Expression;
import Logic.Coordinate.Coordinate;
import Logic.Exceptions.FunctionDoesNotExistException;
import engine.Expression.impl.*;
import engine.Utilty.Utilty;


import java.util.*;

public enum FunctionParser {
    IDENTITY {
        @Override
        public Expression parse(List<String> arguments,Set<Coordinate> tempDependentCooardinates) {
            // validations of the function. it should have exactly one argument
            if (arguments.size() != 1) {
                //throw new IllegalArgumentException("Invalid number of arguments for IDENTITY function. Expected 1, but got " + arguments.size());
                throw new InvalidAmountOfArgumentsException("IDENTITY", 1, arguments.size());
            }

            // all is good. create the relevant function instance
            String actualValue = arguments.get(0).trim();
            if (isBoolean(actualValue)) {
                return new IdentityExpression(Boolean.parseBoolean(actualValue), CellType.BOOLEAN);
            } else if (isNumeric(actualValue)) {
                return new IdentityExpression(Double.parseDouble(actualValue), CellType.NUMERIC);
            } else if(actualValue.isEmpty()) {
                return new IdentityExpression("", CellType.UNKNOWN);
            } else {
                return new IdentityExpression(actualValue, CellType.STRING);
            }
        }

        private boolean isBoolean(String value) {
            return "true".equalsIgnoreCase(value) || "false".equalsIgnoreCase(value);
        }

        private boolean isNumeric(String value) {
            try {
                Double.parseDouble(value);
                return true;
            } catch (NumberFormatException e) {
                return false;
            }
        }
    },
    PLUS {
        @Override
        public Expression parse(List<String> arguments,Set<Coordinate> tempDependentCooardinates)throws FunctionDoesNotExistException {
            // validations of the function (e.g. number of arguments)
            if (arguments.size() != 2) {
                //throw new IllegalArgumentException("Invalid number of arguments for PLUS function. Expected 2, but got " + arguments.size());
                throw new InvalidAmountOfArgumentsException("PLUS", 2, arguments.size());
            }

            // structure is good. parse arguments
            Expression left = parseExpression(arguments.get(0).trim(), tempDependentCooardinates);
            Expression right = parseExpression(arguments.get(1).trim(), tempDependentCooardinates);

            // more validations on the expected argument types
            CellType leftCellType = left.getFunctionResultType();
            CellType rightCellType = right.getFunctionResultType();
            // support UNKNOWN type as its value will be determined at runtime
            if ( (!leftCellType.equals(CellType.NUMERIC) && !leftCellType.equals(CellType.UNKNOWN)) ||
                    (!rightCellType.equals(CellType.NUMERIC) && !rightCellType.equals(CellType.UNKNOWN)) ) {
                //throw new IllegalArgumentException("Invalid argument types for PLUS function. Expected NUMERIC, but got " + leftCellType + " and " + rightCellType);
                throw new InvalidFunctionArgumentException("PLUS", List.of("NUMERIC"), List.of(leftCellType.toString(), rightCellType.toString()), 2);
            }

            // all is good. create the relevant function instance
            return new PlusExpression(left, right);
        }
    },
    MINUS {
        @Override
        public Expression parse(List<String> arguments, Set<Coordinate> tempDependentCooardinates) throws FunctionDoesNotExistException {
            // validations of the function. it should have exactly two arguments
            if (arguments.size() != 2) {
                //throw new IllegalArgumentException("Invalid number of arguments for MINUS function. Expected 2, but got " + arguments.size());
                throw new InvalidAmountOfArgumentsException("MINUS", 2, arguments.size());
            }

            // structure is good. parse arguments
            Expression left = parseExpression(arguments.get(0).trim(),tempDependentCooardinates);
            Expression right = parseExpression(arguments.get(1).trim(),tempDependentCooardinates);

            // more validations on the expected argument types
            CellType leftCellType = left.getFunctionResultType();
            CellType rightCellType = right.getFunctionResultType();

            // more validations on the expected argument types
            if  ((!leftCellType.equals(CellType.NUMERIC) && !leftCellType.equals(CellType.UNKNOWN)) ||
                    (!rightCellType.equals(CellType.NUMERIC) && !rightCellType.equals(CellType.UNKNOWN)))  {
                //throw new IllegalArgumentException("Invalid argument types for MINUS function. Expected NUMERIC, but got " + left.getFunctionResultType() + " and " + right.getFunctionResultType());
                throw new InvalidFunctionArgumentException("MINUS", List.of("NUMERIC"), List.of(left.getFunctionResultType().toString(), right.getFunctionResultType().toString()), 2);
            }

            // all is good. create the relevant function instance
            return new MinusExpression(left, right);
        }
    },
    UPPER_CASE {
        @Override
        public Expression parse(List<String> arguments, Set<Coordinate> tempDependentCooardinates) throws FunctionDoesNotExistException {
            // validations of the function. it should have exactly one argument
            if (arguments.size() != 1) {
                //throw new IllegalArgumentException("Invalid number of arguments for UPPER_CASE function. Expected 1, but got " + arguments.size());
                throw new InvalidAmountOfArgumentsException("UPPER_CASE", 1, arguments.size());
            }

            // structure is good. parse arguments
            Expression arg = parseExpression(arguments.get(0).trim(),tempDependentCooardinates);

            // more validations on the expected argument types
            if (!arg.getFunctionResultType().equals(CellType.STRING)) {
                //throw new IllegalArgumentException("Invalid argument types for UPPER_CASE function. Expected STRING, but got " + arg.getFunctionResultType());
                throw new InvalidFunctionArgumentException("UPPER_CASE", List.of("STRING"), List.of(arg.getFunctionResultType().toString()), 1);
            }

            // all is good. create the relevant function instance
            return new UpperCaseExpression(arg);
        }
    },
    REF {
        @Override
        public Expression parse(List<String> arguments, Set<Coordinate> tempDependentCooardinates) {
            // validations of the function. it should have exactly one argument
            Coordinate target;
            if (arguments.size() != 1) {
                //throw new IllegalArgumentException("Invalid number of arguments for REF function. Expected 1, but got " + arguments.size());
                throw new InvalidAmountOfArgumentsException("REF", 1, arguments.size());
            }

            // verify indeed argument represents a reference to a cell and create a Coordinate instance. if not ok returns a null. need to verify it
            try {
                target = Utilty.fromExcelFormat(arguments.get(0).trim());
            }
            catch(InvalidExcelFormatException e)
            {
                target = null;
            }
            if (target == null) {
                //throw new IllegalArgumentException("Invalid argument for REF function. Expected a valid cell reference, but got " + arguments.get(0));
                throw new InvalidFunctionArgumentException("REF", List.of("Coordinate"), List.of(arguments.get(0).toString()), 1);
            }

            // should verify if the coordinate is within boundaries of the sheet ?
            // ...
            tempDependentCooardinates.add(target);
            return new RefExpression(target);
        }
    },
    TIMES{
        @Override
        public Expression parse(List<String> arguments, Set<Coordinate> tempDependentCooardinates) throws FunctionDoesNotExistException {
            // validations of the function. it should have exactly two arguments
            if (arguments.size() != 2) {
                //throw new IllegalArgumentException("Invalid number of arguments for TIMES function. Expected 2, but got " + arguments.size());
                throw new InvalidAmountOfArgumentsException("TIMES", 2, arguments.size());
            }

            // structure is good. parse arguments
            Expression left = parseExpression(arguments.get(0).trim(),tempDependentCooardinates);
            Expression right = parseExpression(arguments.get(1).trim(),tempDependentCooardinates);

            // more validations on the expected argument types
            CellType leftCellType = left.getFunctionResultType();
            CellType rightCellType = right.getFunctionResultType();

            // more validations on the expected argument types
            if  ((!leftCellType.equals(CellType.NUMERIC) && !leftCellType.equals(CellType.UNKNOWN)) ||
                    (!rightCellType.equals(CellType.NUMERIC) && !rightCellType.equals(CellType.UNKNOWN))) {
                //throw new IllegalArgumentException("Invalid argument types for TIMES function. Expected NUMERIC, but got " + left.getFunctionResultType() + " and " + right.getFunctionResultType());
                throw new InvalidFunctionArgumentException("TIMES", List.of("NUMERIC"), List.of(left.getFunctionResultType().toString(), right.getFunctionResultType().toString()), 2);
            }

            // all is good. create the relevant function instance
            return new TimesExpression(left, right);
        }
    },
    DIVIDE{
        @Override
        public Expression parse(List<String> arguments, Set<Coordinate> tempDependentCooardinates) throws FunctionDoesNotExistException {
            // validations of the function. it should have exactly two arguments
            if (arguments.size() != 2) {
                //throw new IllegalArgumentException("Invalid number of arguments for DIVIDE function. Expected 2, but got " + arguments.size());
                throw new InvalidAmountOfArgumentsException("DIVIDE", 2, arguments.size());
            }

            // structure is good. parse arguments
            Expression left = parseExpression(arguments.get(0).trim(),tempDependentCooardinates);
            Expression right = parseExpression(arguments.get(1).trim(),tempDependentCooardinates);

            // more validations on the expected argument types
            CellType leftCellType = left.getFunctionResultType();
            CellType rightCellType = right.getFunctionResultType();

            // more validations on the expected argument types
            if  ((!leftCellType.equals(CellType.NUMERIC) && !leftCellType.equals(CellType.UNKNOWN)) ||
                    (!rightCellType.equals(CellType.NUMERIC) && !rightCellType.equals(CellType.UNKNOWN))) {
                //throw new IllegalArgumentException("Invalid argument types for DIVIDE function. Expected NUMERIC, but got " + left.getFunctionResultType() + " and " + right.getFunctionResultType());
                throw new InvalidFunctionArgumentException("DIVIDE", List.of("NUMERIC"), List.of(left.getFunctionResultType().toString(), right.getFunctionResultType().toString()), 2);
            }

            // all is good. create the relevant function instance
            return new DivideExpression(left, right);
        }
    },
    MOD{
        @Override
        public Expression parse(List<String> arguments, Set<Coordinate> tempDependentCooardinates) throws FunctionDoesNotExistException {
            // validations of the function. it should have exactly two arguments
            if (arguments.size() != 2) {
                //throw new IllegalArgumentException("Invalid number of arguments for MOD function. Expected 2, but got " + arguments.size());
                throw new InvalidAmountOfArgumentsException("MOD", 2, arguments.size());
            }

            // structure is good. parse arguments
            Expression left = parseExpression(arguments.get(0).trim(),tempDependentCooardinates);
            Expression right = parseExpression(arguments.get(1).trim(),tempDependentCooardinates);

            // more validations on the expected argument types
            CellType leftCellType = left.getFunctionResultType();
            CellType rightCellType = right.getFunctionResultType();

            // more validations on the expected argument types
            if  ((!leftCellType.equals(CellType.NUMERIC) && !leftCellType.equals(CellType.UNKNOWN)) ||
                    (!rightCellType.equals(CellType.NUMERIC) && !rightCellType.equals(CellType.UNKNOWN))) {
                //throw new IllegalArgumentException("Invalid argument types for MOD function. Expected NUMERIC, but got " + left.getFunctionResultType() + " and " + right.getFunctionResultType());
                throw new InvalidFunctionArgumentException("MOD", List.of("NUMERIC"), List.of(left.getFunctionResultType().toString(), right.getFunctionResultType().toString()), 2);
            }

            // all is good. create the relevant function instance
            return new ModExpression(left, right);
        }
    },
    POW {
        @Override
        public Expression parse(List<String> arguments, Set<Coordinate> tempDependentCooardinates) throws FunctionDoesNotExistException {
            // validations of the function. it should have exactly two arguments
            if (arguments.size() != 2) {
                //throw new IllegalArgumentException("Invalid number of arguments for POW function. Expected 2, but got " + arguments.size());
                throw new InvalidAmountOfArgumentsException("POW", 2, arguments.size());
            }

            // structure is good. parse arguments
            Expression left = parseExpression(arguments.get(0).trim(),tempDependentCooardinates);
            Expression right = parseExpression(arguments.get(1).trim(),tempDependentCooardinates);

            // more validations on the expected argument types
            CellType leftCellType = left.getFunctionResultType();
            CellType rightCellType = right.getFunctionResultType();

            // more validations on the expected argument types
            if  ((!leftCellType.equals(CellType.NUMERIC) && !leftCellType.equals(CellType.UNKNOWN)) ||
                    (!rightCellType.equals(CellType.NUMERIC) && !rightCellType.equals(CellType.UNKNOWN))) {
                //throw new IllegalArgumentException("Invalid argument types for POW function. Expected NUMERIC, but got " + left.getFunctionResultType() + " and " + right.getFunctionResultType());
                throw new InvalidFunctionArgumentException("POW", List.of("NUMERIC"), List.of(left.getFunctionResultType().toString(), right.getFunctionResultType().toString()), 2);
            }

            // all is good. create the relevant function instance
            return new PowExpression(left, right);
        }
    },
    ABS{
        @Override
        public Expression parse(List<String> arguments, Set<Coordinate> tempDependentCooardinates) throws FunctionDoesNotExistException {
            // validations of the function. it should have exactly one argument
            if (arguments.size() != 1) {
                throw new InvalidAmountOfArgumentsException("ABS",1,arguments.size());
            }

            // structure is good. parse arguments
            Expression arg = parseExpression(arguments.get(0).trim(),tempDependentCooardinates);

            CellType argCellType = arg.getFunctionResultType();

            // more validations on the expected argument types
            if (!arg.getFunctionResultType().equals(CellType.NUMERIC) && !arg.getFunctionResultType().equals(CellType.UNKNOWN)) {
                //throw new IllegalArgumentException("Invalid argument types for ABS function. Expected NUMERIC, but got " + arg.getFunctionResultType());
                throw new InvalidFunctionArgumentException("ABS", List.of("NUMERIC"), List.of(arg.getFunctionResultType().toString()), 1);
            }

            // all is good. create the relevant function instance
            return new AbsExpression(arg);
        }
    },
    CONCAT{
        @Override
        public Expression parse(List<String> arguments, Set<Coordinate> tempDependentCooardinates) throws FunctionDoesNotExistException {
            // validations of the function. it should have exactly two arguments
            if (arguments.size() != 2) {
                //throw new IllegalArgumentException("Invalid number of arguments for CONCAT function. Expected 2, but got " + arguments.size());
                throw new InvalidAmountOfArgumentsException("CONCAT",2,arguments.size());
            }

            // structure is good. parse arguments
            Expression left = parseExpression(arguments.get(0).trim(),tempDependentCooardinates);
            Expression right = parseExpression(arguments.get(1).trim(),tempDependentCooardinates);

            // more validations on the expected argument types
            CellType leftCellType = left.getFunctionResultType();
            CellType rightCellType = right.getFunctionResultType();

            // more validations on the expected argument types
            if  ((!leftCellType.equals(CellType.STRING) && !leftCellType.equals(CellType.UNKNOWN)) ||
                    (!rightCellType.equals(CellType.STRING) && !rightCellType.equals(CellType.UNKNOWN))) {
                //throw new IllegalArgumentException("Invalid argument types for CONCAT function. Expected STRING, but got " + left.getFunctionResultType() + " and " + right.getFunctionResultType());
                throw new InvalidFunctionArgumentException("CONCAT", List.of("STRING"), List.of(left.getFunctionResultType().toString(), right.getFunctionResultType().toString()), 2);
            }

            // all is good. create the relevant function instance
            return new ConcatExpression(left, right);
        }
    },
    SUB{
        @Override
        public Expression parse(List<String> arguments, Set<Coordinate> tempDependentCooardinates) throws FunctionDoesNotExistException {
            // validations of the function. it should have exactly two arguments
            if (arguments.size() != 3) {
                //throw new IllegalArgumentException("Invalid number of arguments for SUB function. Expected 3, but got " + arguments.size());
                throw new InvalidAmountOfArgumentsException("SUB",3,arguments.size());
            }

            // structure is good. parse arguments
            Expression source = parseExpression(arguments.get(0).trim(),tempDependentCooardinates);
            Expression startIndex = parseExpression(arguments.get(1).trim(),tempDependentCooardinates);
            Expression endIndex = parseExpression(arguments.get(2).trim(),tempDependentCooardinates);

            // more validations on the expected argument types
            CellType sourceCellType = source.getFunctionResultType();
            CellType startIndexCellType = startIndex.getFunctionResultType();
            CellType endIndexCellType = endIndex.getFunctionResultType();

            // more validations on the expected argument types
            if  ((!sourceCellType.equals(CellType.STRING) && !sourceCellType.equals(CellType.UNKNOWN)) ||
                    (!startIndexCellType.equals(CellType.NUMERIC) && !startIndexCellType.equals(CellType.UNKNOWN)) ||
                    (!endIndexCellType.equals(CellType.NUMERIC) && !endIndexCellType.equals(CellType.UNKNOWN))) {
                //throw new IllegalArgumentException("Invalid argument types for SUB function. Expected STRING, NUMERIC, NUMERIC, but got " + source.getFunctionResultType() + " and " + startIndex.getFunctionResultType() + " and " + endIndex.getFunctionResultType());
                throw new InvalidFunctionArgumentException("SUB", List.of("STRING", "NUMERIC", "NUMERIC"), List.of(source.getFunctionResultType().toString(), startIndex.getFunctionResultType().toString(), endIndex.getFunctionResultType().toString()), 3);
            }

            // all is good. create the relevant function instance
            return new SubExpression(source, startIndex, endIndex);
        }
    },
    SUM{
        @Override
        public Expression parse(List<String> arguments, Set<Coordinate> tempDependentCooardinates) throws FunctionDoesNotExistException {
            // validations of the function. it should have exactly one argument
            if (arguments.size() != 1) {
                throw new InvalidAmountOfArgumentsException("SUM",1,arguments.size());
            }

            // structure is good. parse arguments
            Expression arg = parseExpression(arguments.get(0).trim(),tempDependentCooardinates);

            CellType argCellType = arg.getFunctionResultType();

            // more validations on the expected argument types
            if (!arg.getFunctionResultType().equals(CellType.NUMERIC) && !arg.getFunctionResultType().equals(CellType.STRING)) {
                //throw new IllegalArgumentException("Invalid argument types for ABS function. Expected NUMERIC, but got " + arg.getFunctionResultType());
                throw new InvalidFunctionArgumentException("SUM", List.of("STRING or NUMERIC"), List.of(arg.getFunctionResultType().toString()), 1);
            }

            // all is good. create the relevant function instance
            return new SumExpression(arg);
        }
    },
    AVERAGE{
        @Override
        public Expression parse(List<String> arguments, Set<Coordinate> tempDependentCooardinates) throws FunctionDoesNotExistException {
            // validations of the function. it should have exactly one argument
            if (arguments.size() != 1) {
                throw new InvalidAmountOfArgumentsException("AVERAGE",1,arguments.size());
            }

            // structure is good. parse arguments
            Expression arg = parseExpression(arguments.get(0).trim(),tempDependentCooardinates);

            CellType argCellType = arg.getFunctionResultType();

            // more validations on the expected argument types
            if (!arg.getFunctionResultType().equals(CellType.NUMERIC) && !arg.getFunctionResultType().equals(CellType.STRING)) {
                //throw new IllegalArgumentException("Invalid argument types for ABS function. Expected NUMERIC, but got " + arg.getFunctionResultType());
                throw new InvalidFunctionArgumentException("AVERAGE", List.of("STRING or NUMERIC"), List.of(arg.getFunctionResultType().toString()), 1);
            }

            // all is good. create the relevant function instance
            return new AverageExpression(arg);
        }
    },
    PERCENT{
        @Override
        public Expression parse(List<String> arguments, Set<Coordinate> tempDependentCooardinates) throws FunctionDoesNotExistException {
            // validations of the function. it should have exactly two arguments
            if (arguments.size() != 2) {
                throw new InvalidAmountOfArgumentsException("PERCENT",2,arguments.size());
            }

            // structure is good. parse arguments
            Expression arg1 = parseExpression(arguments.get(0).trim(),tempDependentCooardinates);
            Expression arg2 = parseExpression(arguments.get(1).trim(),tempDependentCooardinates);

            // more validations on the expected argument types
            CellType arg1CellType = arg1.getFunctionResultType();
            CellType arg2CellType = arg2.getFunctionResultType();

            // more validations on the expected argument types
            if  ((!arg1CellType.equals(CellType.NUMERIC) && !arg1CellType.equals(CellType.UNKNOWN)) ||
                    (!arg2CellType.equals(CellType.NUMERIC) && !arg2CellType.equals(CellType.UNKNOWN))) {
                throw new InvalidFunctionArgumentException("PERCENT", List.of("NUMERIC"), List.of(arg1.getFunctionResultType().toString(), arg2.getFunctionResultType().toString()), 2);
            }

            // all is good. create the relevant function instance
            return new PercentExpression(arg1, arg2);
        }
    },
    EQUAL{
        @Override
        public Expression parse(List<String> arguments, Set<Coordinate> tempDependentCooardinates) throws FunctionDoesNotExistException {
            // validations of the function. it should have exactly two arguments
            if (arguments.size() != 2) {
                throw new InvalidAmountOfArgumentsException("EQUAL",2,arguments.size());
            }

            // structure is good. parse arguments
            Expression arg1 = parseExpression(arguments.get(0).trim(),tempDependentCooardinates);
            Expression arg2 = parseExpression(arguments.get(1).trim(),tempDependentCooardinates);

            // more validations on the expected argument types
            CellType arg1CellType = arg1.getFunctionResultType();
            CellType arg2CellType = arg2.getFunctionResultType();

            /* can except any type
            // more validations on the expected argument types
            if  ((!arg1CellType.equals(CellType.NUMERIC) && !arg1CellType.equals(CellType.UNKNOWN) && !arg1CellType.equals(CellType.STRING)) ||
                    (!arg2CellType.equals(CellType.NUMERIC) && !arg2CellType.equals(CellType.UNKNOWN) && !arg2CellType.equals(CellType.STRING))) {
                throw new InvalidFunctionArgumentException("EQUAL", List.of("NUMERIC or STRING"), List.of(arg1.getFunctionResultType().toString(), arg2.getFunctionResultType().toString()), 2);
            }
             */

            // all is good. create the relevant function instance
            return new EqualExpression(arg1, arg2);
        }
    },
    NOT {
        @Override
        public Expression parse(List<String> arguments, Set<Coordinate> tempDependentCooardinates) throws FunctionDoesNotExistException {
            // validations of the function. it should have exactly one argument
            if (arguments.size() != 1) {
                throw new InvalidAmountOfArgumentsException("NOT", 1, arguments.size());
            }

            // structure is good. parse arguments
            Expression arg = parseExpression(arguments.get(0).trim(), tempDependentCooardinates);

            // more validations on the expected argument types
            CellType argCellType = arg.getFunctionResultType();

            // more validations on the expected argument types
            if (!arg.getFunctionResultType().equals(CellType.BOOLEAN) && !arg.getFunctionResultType().equals(CellType.UNKNOWN)) {
                throw new InvalidFunctionArgumentException("NOT", List.of("BOOLEAN"), List.of(arg.getFunctionResultType().toString()), 1);
            }

            // all is good. create the relevant function instance
            return new NotExpression(arg);
        }
    },
    BIGGER {
        @Override
        public Expression parse(List<String> arguments, Set<Coordinate> tempDependentCooardinates) throws FunctionDoesNotExistException {
            // validations of the function. it should have exactly two arguments
            if (arguments.size() != 2) {
                throw new InvalidAmountOfArgumentsException("BIGGER", 2, arguments.size());
            }

            // structure is good. parse arguments
            Expression arg1 = parseExpression(arguments.get(0).trim(), tempDependentCooardinates);
            Expression arg2 = parseExpression(arguments.get(1).trim(), tempDependentCooardinates);

            // more validations on the expected argument types
            CellType arg1CellType = arg1.getFunctionResultType();
            CellType arg2CellType = arg2.getFunctionResultType();

            // more validations on the expected argument types
            if ((!arg1CellType.equals(CellType.NUMERIC) && !arg1CellType.equals(CellType.UNKNOWN)) ||
                    (!arg2CellType.equals(CellType.NUMERIC) && !arg2CellType.equals(CellType.UNKNOWN))) {
                throw new InvalidFunctionArgumentException("BIGGER", List.of("NUMERIC"), List.of(arg1.getFunctionResultType().toString(), arg2.getFunctionResultType().toString()), 2);
            }

            // all is good. create the relevant function instance
            return new BiggerExpression(arg1, arg2);
        }
    },
    LESS {
        @Override
        public Expression parse(List<String> arguments, Set<Coordinate> tempDependentCooardinates) throws FunctionDoesNotExistException {
            // validations of the function. it should have exactly two arguments
            if (arguments.size() != 2) {
                throw new InvalidAmountOfArgumentsException("LESS", 2, arguments.size());
            }

            // structure is good. parse arguments
            Expression arg1 = parseExpression(arguments.get(0).trim(), tempDependentCooardinates);
            Expression arg2 = parseExpression(arguments.get(1).trim(), tempDependentCooardinates);

            // more validations on the expected argument types
            CellType arg1CellType = arg1.getFunctionResultType();
            CellType arg2CellType = arg2.getFunctionResultType();

            // more validations on the expected argument types
            if ((!arg1CellType.equals(CellType.NUMERIC) && !arg1CellType.equals(CellType.UNKNOWN)) ||
                    (!arg2CellType.equals(CellType.NUMERIC) && !arg2CellType.equals(CellType.UNKNOWN))) {
                throw new InvalidFunctionArgumentException("LESS", List.of("NUMERIC"), List.of(arg1.getFunctionResultType().toString(), arg2.getFunctionResultType().toString()), 2);
            }

            // all is good. create the relevant function instance
            return new LessExpression(arg1, arg2);
        }
    },
    OR {
        @Override
        public Expression parse(List<String> arguments, Set<Coordinate> tempDependentCooardinates) throws FunctionDoesNotExistException {
            // validations of the function. it should have exactly two arguments
            if (arguments.size() != 2) {
                throw new InvalidAmountOfArgumentsException("OR", 2, arguments.size());
            }

            // structure is good. parse arguments
            Expression arg1 = parseExpression(arguments.get(0).trim(), tempDependentCooardinates);
            Expression arg2 = parseExpression(arguments.get(1).trim(), tempDependentCooardinates);

            // more validations on the expected argument types
            CellType arg1CellType = arg1.getFunctionResultType();
            CellType arg2CellType = arg2.getFunctionResultType();

            // more validations on the expected argument types
            if ((!arg1CellType.equals(CellType.BOOLEAN) && !arg1CellType.equals(CellType.UNKNOWN)) ||
                    (!arg2CellType.equals(CellType.BOOLEAN) && !arg2CellType.equals(CellType.UNKNOWN))) {
                throw new InvalidFunctionArgumentException("OR", List.of("BOOLEAN"), List.of(arg1.getFunctionResultType().toString(), arg2.getFunctionResultType().toString()), 2);
            }

            // all is good. create the relevant function instance
            return new OrExpression(arg1, arg2);
        }
    },
    AND {
        @Override
        public Expression parse(List<String> arguments, Set<Coordinate> tempDependentCooardinates) throws FunctionDoesNotExistException {
            // validations of the function. it should have exactly two arguments
            if (arguments.size() != 2) {
                throw new InvalidAmountOfArgumentsException("AND", 2, arguments.size());
            }

            // structure is good. parse arguments
            Expression arg1 = parseExpression(arguments.get(0).trim(), tempDependentCooardinates);
            Expression arg2 = parseExpression(arguments.get(1).trim(), tempDependentCooardinates);

            // more validations on the expected argument types
            CellType arg1CellType = arg1.getFunctionResultType();
            CellType arg2CellType = arg2.getFunctionResultType();

            // more validations on the expected argument types
            if ((!arg1CellType.equals(CellType.BOOLEAN) && !arg1CellType.equals(CellType.UNKNOWN)) ||
                    (!arg2CellType.equals(CellType.BOOLEAN) && !arg2CellType.equals(CellType.UNKNOWN))) {
                throw new InvalidFunctionArgumentException("AND", List.of("BOOLEAN"), List.of(arg1.getFunctionResultType().toString(), arg2.getFunctionResultType().toString()), 2);
            }

            // all is good. create the relevant function instance
            return new AndExpression(arg1, arg2);
        }
    },
    IF {
        @Override
        public Expression parse(List<String> arguments, Set<Coordinate> tempDependentCooardinates) throws FunctionDoesNotExistException {
            // validations of the function. it should have exactly three arguments
            if (arguments.size() != 3) {
                throw new InvalidAmountOfArgumentsException("IF", 3, arguments.size());
            }

            // structure is good. parse arguments
            Expression condition = parseExpression(arguments.get(0).trim(), tempDependentCooardinates);
            Expression trueExpression = parseExpression(arguments.get(1).trim(), tempDependentCooardinates);
            Expression falseExpression = parseExpression(arguments.get(2).trim(), tempDependentCooardinates);

            // more validations on the expected argument types
            CellType conditionCellType = condition.getFunctionResultType();
            CellType trueExpressionCellType = trueExpression.getFunctionResultType();
            CellType falseExpressionCellType = falseExpression.getFunctionResultType();

            // more validations on the expected argument types
            if ((!conditionCellType.equals(CellType.BOOLEAN) && !conditionCellType.equals(CellType.UNKNOWN))) {
                throw new InvalidFunctionArgumentException("IF", List.of("BOOLEAN", "UNKNOWN"), List.of(condition.getFunctionResultType().toString(), trueExpression.getFunctionResultType().toString(), falseExpression.getFunctionResultType().toString()), 3);
            }

            // all is good. create the relevant function instance
            return new IfExpression(condition, trueExpression, falseExpression);
        }
    };

    abstract public Expression parse(List<String> arguments,Set<Coordinate> tempDependentCooardinates) throws FunctionDoesNotExistException;

    public static Expression parseExpression(String input, Set<Coordinate> tempDependentCooardinates) throws FunctionDoesNotExistException {

        if (input.startsWith("{") && input.endsWith("}")) {

            String functionContent = input.substring(1, input.length() - 1);
            List<String> topLevelParts = parseMainParts(functionContent);


            String functionName = topLevelParts.get(0).trim().toUpperCase();

            //remove the first element from the array
            topLevelParts.remove(0);
            boolean functionExists = false;
            for (FunctionParser function : FunctionParser.values()) {
                if (function.name().equals(functionName)) {
                    functionExists = true;
                    break;
                }
            }
            if(!functionExists){
                throw new FunctionDoesNotExistException(functionName);
            }
            return FunctionParser.valueOf(functionName).parse(topLevelParts,tempDependentCooardinates);
        }

        // handle identity expression
        return FunctionParser.IDENTITY.parse(List.of(input.trim()),tempDependentCooardinates);
    }

    private static List<String> parseMainParts(String input) {
        List<String> parts = new ArrayList<>();
        StringBuilder buffer = new StringBuilder();
        Stack<Character> stack = new Stack<>();

        for (char c : input.toCharArray()) {
            if (c == '{') {
                stack.push(c);
            } else if (c == '}') {
                if (!stack.isEmpty()) {
                    stack.pop();
                } else {
                    throw new IllegalStateException("Unmatched closing brace in input: " + input);
                }
            }

            if (c == ',' && stack.isEmpty()) {
                // If we are at a comma and the stack is empty, it's a separator for top-level parts
                parts.add(buffer.toString().trim());
                buffer.setLength(0); // Clear the buffer for the next part
            } else {
                buffer.append(c);
            }
        }

        // Add the last part
        if (buffer.length() > 0) {
            parts.add(buffer.toString().trim());
        }

        if (!stack.isEmpty()) {
            throw new IllegalStateException("Unmatched opening brace in input: " + input);
        }

        return parts;
    }
    public static List<String> publicParser(String input)
    {
        return parseMainParts(input);
    }
}
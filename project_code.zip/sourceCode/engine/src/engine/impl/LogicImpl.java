package engine.impl;

import Logic.Cell.api.Cell;
import Logic.Cell.api.CellType;
import Logic.Cell.api.ReadonlyCell;
import Logic.permission.PermissionRequest;
import engine.Cell.impl.CellImpl;
import engine.Cell.impl.EffectiveValueImpl;
import Logic.Coordinate.Coordinate;
import Logic.Coordinate.CoordinateFactory;
import Logic.Exceptions.*;
import Logic.Utilty.Utilty;
import Logic.api.Logic;
import engine.jaxbClasses.STLCell;
import engine.jaxbClasses.STLRange;
import engine.jaxbClasses.STLRanges;
import engine.jaxbClasses.STLSheet;
import Logic.sheet.api.ReadonlySheet;
import Logic.sheet.api.Sheet;
import Logic.permission.Permission;
import engine.sheet.impl.SheetImpl;
import engine.sheetRow.SheetRow;
import jakarta.xml.bind.JAXBContext;
import jakarta.xml.bind.JAXBException;
import jakarta.xml.bind.Unmarshaller;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.*;

public class LogicImpl implements Logic {
    private List<Sheet> sheets;
    private final int rows;
    private final int columns;
    private String SheetName;
    private int width;
    private int height;
    private Map<String, Permission> permissionsForSheets;
    private List<PermissionRequest> permissionRequestsForSheets;
    private String ownerName;

    public LogicImpl(int rows, int columns, String SheetName, int width, int height, String ownerName) {
        this.SheetName = SheetName;
        this.rows = rows;
        this.columns = columns;
        this.width = width;
        this.height = height;
        sheets = new ArrayList<Sheet>();
        permissionsForSheets = new HashMap<>();
        permissionRequestsForSheets = new ArrayList<>();
        this.ownerName = ownerName;
    }
    public LogicImpl(int rows, int columns, String SheetName, int width, int height, Map<String, Permission> permissionsForSheets, List<PermissionRequest> permissionRequestsForSheets, String ownerName) {
        this.SheetName = SheetName;
        this.rows = rows;
        this.columns = columns;
        this.width = width;
        this.height = height;
        sheets = new ArrayList<Sheet>();
        this.permissionsForSheets = new HashMap<>();
        this.permissionsForSheets.putAll(permissionsForSheets);
        this.permissionRequestsForSheets = new ArrayList<>();
        this.permissionRequestsForSheets.addAll(permissionRequestsForSheets);
        this.ownerName = ownerName;
    }
    @Override
    public String getOwnerName() {
        return ownerName;
    }

    @Override
    public List<PermissionRequest> getPermissionRequestsForSheets() {
        return permissionRequestsForSheets;
    }
    @Override
    public String getUserPermission(String userName)
    {
        if(permissionsForSheets.containsKey(userName))
        {
            return permissionsForSheets.get(userName).toString();
        }
        else
        {
            return Permission.NONE.toString();
        }
    }
    @Override
    public Map<String, Permission> getPermissions() {
        return permissionsForSheets;
    }

    @Override
    public ReadonlySheet sortSheet(List<String> selectedColumns, Coordinate topLeft, Coordinate bottomRight, ReadonlySheet sheetToSort) throws CoordinateOutOfRangeException {
        // Create a copy of the sheet to sort
        ReadonlySheet sheetCopy = sheetToSort.publicCopySheet();
        List<SheetRow> sheetRows = new ArrayList<>();

        // Extract rows from the selected range (A3..V9 for example)
        for (int row = topLeft.getRow(); row <= bottomRight.getRow(); row++) {
            List<ReadonlyCell> rowCells = new ArrayList<>();
            for (int col = topLeft.getColumn(); col <= bottomRight.getColumn(); col++) {
                ReadonlyCell cell = sheetCopy.getCell(row, col);
                if (cell == null) {
                    // Insert a dummy cell if no value exists (to avoid nulls)
                    cell = new CellImpl(row, col, "", 1, sheetCopy);
                    ((Cell) cell).setLastUpdater(getOwnerName());
                }
                else
                {
                    Cell cellCopy = new CellImpl(row, col, cell.getOriginalValue(), 1, sheetCopy);//dummy Cell to copy Values
                    cellCopy.setEffectiveValueForFilterAndSort(cell.getEffectiveValue());
                    cellCopy.setLastUpdater(cell.getLastUpdater());
                    cell = cellCopy;
                }
                rowCells.add(cell);
            }
            sheetRows.add(new SheetRow(new ArrayList<>(),row,rowCells));  // Add the entire row to the list
        }

        // Comparator to sort rows based on the selected columns
        Comparator<SheetRow> rowComparator = (row1, row2) -> {
            for (String col : selectedColumns) {
                int colIndex = Utilty.columnLettersToNumber(col);
                int adjustedColIndex = colIndex - topLeft.getColumn(); // Adjust for the current range

                ReadonlyCell cell1 = row1.getRegularValues().get(adjustedColIndex);
                ReadonlyCell cell2 = row2.getRegularValues().get(adjustedColIndex);

                String value1 = cell1.getEffectiveValue().getValue().toString();
                String value2 = cell2.getEffectiveValue().getValue().toString();

                // Only compare numeric values
                //boolean isNumeric1 = value1.matches("-?\\d+(\\.\\d+)?");
                //boolean isNumeric2 = value2.matches("-?\\d+(\\.\\d+)?");
                boolean isNumeric1 = cell1.getEffectiveValue().getCellType() == CellType.NUMERIC;
                boolean isNumeric2 = cell2.getEffectiveValue().getCellType() == CellType.NUMERIC;


                if (isNumeric1 && isNumeric2) {
                    double num1 = Double.parseDouble(value1);
                    double num2 = Double.parseDouble(value2);
                    int comparison = Double.compare(num1, num2);
                    if (comparison != 0) {
                        return comparison; // Return the numeric comparison result if there is a difference
                    }
                }
                else if(isNumeric1 && !isNumeric2)
                {
                    return -1;
                }
                else if(!isNumeric1 && isNumeric2)
                {
                    return 1;
                }//so empty cells are at the end
                /*
                else if(value1.equalsIgnoreCase("") && !value2.equalsIgnoreCase(""))
                {
                    return 1;
                }
                else if(!value1.equalsIgnoreCase("") && value2.equalsIgnoreCase(""))
                {
                    return -1;
                }
                */
                // Skip non-numeric columns and move on to the next column
            }
            return 0; // If all comparisons are equal, the rows stay in their original order (stable sort)
        };

        // Sort the rows using the comparator
        sheetRows.sort(rowComparator);

        // Create a new sheet with sorted rows (the content of each row remains unchanged)
        for (int i = 0; i < sheetRows.size(); i++) {
            List<ReadonlyCell> sortedRowCells = sheetRows.get(i).getRegularValues();
            for (int j = 0; j < sortedRowCells.size(); j++) {
                int actualRow = i + topLeft.getRow();
                int actualCol = j + topLeft.getColumn();

                // Get the current cell in the sheet and update it with the sorted row values
                Cell cell = (Cell) sheetCopy.getCell(actualRow, actualCol);
                ReadonlyCell sortedCell = sortedRowCells.get(j);
                if(cell == null)
                {
                    cell = new CellImpl(actualRow,actualCol, "", 1, sheetCopy);
                    cell.setLastUpdater(getOwnerName());
                    sheetCopy.getActiveCells().put(CoordinateFactory.createCoordinate(actualRow, actualCol), cell);
                }
                cell.setCellOriginalValue(sortedCell.getOriginalValue());
                cell.setEffectiveValueForFilterAndSort(sortedCell.getEffectiveValue());
                //cell.setLastUpdater(sortedCell.getLastUpdater());
            }
        }
        ((SheetImpl) sheetCopy).setUpdater(sheetToSort.getUpdater());
        return sheetCopy; // Return the sheet with sorted rows (the original row content is unchanged)
    }

    @Override
    public ReadonlySheet filterSheet(List<String> selectedUniqueValues, int columnNumber, Coordinate topLeft, Coordinate bottomRight, ReadonlySheet sheetToFilter)throws CoordinateOutOfRangeException {
        List<SheetRow> sheetRowsAfterFilter = new ArrayList<>();
        ReadonlySheet sheetCopy = sheetToFilter.publicCopySheet();
        for(String value : selectedUniqueValues)
        {
            for(int i = topLeft.getRow(); i <= bottomRight.getRow(); i++)
            {
                ReadonlyCell cell = sheetCopy.getCell(i, columnNumber);
                if(cell == null || cell.getEffectiveValue().getValue() == null)
                {
                    continue;
                }
                if(cell.getEffectiveValue().getValue().toString().equals(value))
                {
                    List<ReadonlyCell> regularValues = new ArrayList<>();
                    for(int j = topLeft.getColumn(); j <= bottomRight.getColumn(); j++)
                    {
                        ReadonlyCell regularCell = sheetCopy.getCell(i, j);
                        if(regularCell == null)
                        {
                            Cell cellCopy = new CellImpl(0, 0, "", 0, sheetCopy);//dummy cell to hold values
                            cellCopy.setLastUpdater(getOwnerName());
                            regularValues.add(cellCopy);
                        }
                        else
                        {
                            Cell cellCopy = new CellImpl(0, 0, regularCell.getOriginalValue(), 0, sheetCopy);//dummy Cell to copy Values
                            cellCopy.setEffectiveValueForFilterAndSort(regularCell.getEffectiveValue());
                            cellCopy.setLastUpdater(regularCell.getLastUpdater());
                            regularValues.add(cellCopy);
                        }
                    }
                    SheetRow newRow = new SheetRow(new ArrayList<>(Arrays.asList(cell.getEffectiveValue().getValue().toString())), columnNumber, regularValues);
                    sheetRowsAfterFilter.add(newRow);
                }
            }
        }
        for(int i = topLeft.getRow(); i <= bottomRight.getRow(); i++)
        {
            for(int j = topLeft.getColumn(); j <= bottomRight.getColumn(); j++)
            {
                Cell cell = (Cell)sheetCopy.getCell(i, j);
                if(cell == null)
                {
                    Cell cellCopy = new CellImpl(i, j, "", 1, sheetCopy);//dummy Cell to copy Values
                    sheetCopy.getActiveCells().put(CoordinateFactory.createCoordinate(i, j), cellCopy);
                    cellCopy.setCellOriginalValue("");
                    cellCopy.setEffectiveValueForFilterAndSort(new EffectiveValueImpl(CellType.UNKNOWN, ""));
                    cellCopy.setLastUpdater(getOwnerName());
                }
                else {
                    cell.setCellOriginalValue("");
                    cell.setEffectiveValueForFilterAndSort(new EffectiveValueImpl(CellType.UNKNOWN, ""));
                }
            }
        }
        for(int i=0; i<sheetRowsAfterFilter.size(); i++)
        {
            for(int j=0; j<sheetRowsAfterFilter.get(i).getRegularValues().size(); j++)
            {
                Cell cell = (Cell)sheetCopy.getCell(i + topLeft.getRow(), j + topLeft.getColumn());
                cell.setCellOriginalValue(sheetRowsAfterFilter.get(i).getRegularValues().get(j).getOriginalValue());
                cell.setEffectiveValueForFilterAndSort(sheetRowsAfterFilter.get(i).getRegularValues().get(j).getEffectiveValue());
                Cell cellTmp = (Cell) sheetRowsAfterFilter.get(i).getRegularValues().get(j);
                cell.setLastUpdater(cellTmp.getLastUpdater());
            }
        }
        ((SheetImpl) sheetCopy).setUpdater(sheetToFilter.getUpdater());
        return sheetCopy;
    }
    @Override
    public List<String> getUniqueValuesInColumnArea(int column, Coordinate topLeft, Coordinate bottomRight, ReadonlySheet sheetToUse) throws CoordinateOutOfRangeException {
        List<String> uniqueValues = new ArrayList<>();
        for(int i = topLeft.getRow(); i <= bottomRight.getRow(); i++)
        {
            ReadonlyCell cell = sheetToUse.getCell(i, column);
            if(cell!=null)
            {
                if(cell.getEffectiveValue().getValue() != null && !cell.getEffectiveValue().getValue().toString().equals("")) {
                    if (!uniqueValues.contains(cell.getEffectiveValue().getValue().toString())) {
                        uniqueValues.add(cell.getEffectiveValue().getValue().toString());
                    }
                }
            }
        }
        return uniqueValues;
    }

    @Override
    public void createNewRange(String rangeName, int rowStart, int columnStart, int rowEnd, int columnEnd) throws RangeAlreadyExistsException, RangeCoordinateOutOfRangeException, RangeStartIndexLowerThenEndException {
        getCurrentSheet().addNewRange(rangeName, rowStart, columnStart, rowEnd, columnEnd);
    }
    @Override
    public void removeRange(String rangeName) throws RangeInUseException {
        getCurrentSheet().removeRange(rangeName);
    }

    @Override
    public int getRows() {
        return rows;
    }

    @Override
    public int getColumns() {
        return columns;
    }

    @Override
    public String getSheetName() {
        return SheetName;
    }
    @Override
    public List<Sheet> getSheets() {
        return sheets;
    }
    @Override
    public int getWidth() {
        return width;
    }
    @Override
    public int getHeight() {
        return height;
    }
    public void addNewSheetVersion(Sheet sheet) {
        sheets.add(sheet);
    }

    @Override
    public ReadonlySheet getSheetByVersion(int version) {
        return sheets.get(version - 1);//in the set they start from zero and the versions start from 1
    }
    @Override
    public Sheet getEditableSheetByVersion(int version) {
        return sheets.get(version - 1);
    }
    @Override
    public ReadonlySheet getCurrentSheet() {
        if(sheets.size() == 0)
        {
            return null;
        }
        else
        {
            return sheets.get(sheets.size() - 1);
        }
    }

    @Override
    public ReadonlyCell getCellForDisplay(int version, String rowAndColumn) throws CoordinateOutOfRangeException, FunctionDoesNotExistException {
        Coordinate cellCoordinate = checkFormat(rowAndColumn);
        ReadonlyCell cellDisplayed = sheets.get(version - 1).getCell(cellCoordinate.getRow(), cellCoordinate.getColumn());
        return cellDisplayed;
    }
    @Override
    public void updateCell(int version,String rowAndColumn , String value, String updaterName) throws CoordinateOutOfRangeException, FunctionDoesNotExistException {
        Coordinate cellCoordinate = checkFormat(rowAndColumn);
        if(cellCoordinate.getRow() > rows || cellCoordinate.getRow() < 1)
        {
            throw new CoordinateOutOfRangeException(cellCoordinate.getRow(), rows, true);
        }
        if(cellCoordinate.getColumn() > columns || cellCoordinate.getColumn() < 1)
        {
            throw new CoordinateOutOfRangeException(cellCoordinate.getColumn(), columns, false);
        }
        int currentVersion = sheets.get(sheets.size() - 1).getVersion();
        Sheet newSheetVersion = sheets.get(sheets.size() - 1).updateCellValueAndCalculate(cellCoordinate.getRow(), cellCoordinate.getColumn(), value, updaterName);
        if(newSheetVersion.getVersion() > currentVersion)
        {
            sheets.add(newSheetVersion);
        }
        else
        {
            sheets.set(sheets.size() - 1, newSheetVersion);
        }
    }
    @Override
    public List<ReadonlySheet> getDifferentSheetVersionsForDisplay() {
        List<ReadonlySheet> differentSheetVersions = new ArrayList<>();
        differentSheetVersions.addAll(sheets);
        return differentSheetVersions;
    }
    @Override
    public Logic loadSheet(String filePath, String uploaderName) throws Exception {
        if (!filePath.endsWith(".xml")) {
            throw new FileTypeIsntSupportedException();
        }
        InputStream file = new FileInputStream(new File(filePath));
        if(file == null)
        {
            throw new FileNotFoundException();
        }
        STLSheet jaxbiSheet = DeserializeFrom(file);
        int rows,columns,width,height;
        String SheetName;
        if(jaxbiSheet == null)
        {
            throw new JAXBException("Sheet is empty");
        }
        rows = jaxbiSheet.getSTLLayout().getRows();
        columns = jaxbiSheet.getSTLLayout().getColumns();
        width = jaxbiSheet.getSTLLayout().getSTLSize().getColumnWidthUnits();
        height = jaxbiSheet.getSTLLayout().getSTLSize().getRowsHeightUnits();
        SheetName = jaxbiSheet.getName();
        LogicImpl newLogic = new LogicImpl(rows,columns,SheetName,width,height,uploaderName);
        checkLogicParams(newLogic);
        Sheet newSheet = new SheetImpl(newLogic,uploaderName);
        newSheet = checkNewSheet(newSheet, jaxbiSheet, uploaderName);
        newLogic.getSheets().add(newSheet);
        return newLogic;
    }
    @Override
    public Logic loadSheet(String filePath,File choosenFile, String uploaderName) throws Exception {
        if (!filePath.endsWith(".xml")) {
            throw new FileTypeIsntSupportedException();
        }
        InputStream file = new FileInputStream(choosenFile);
        if(file == null)
        {
            throw new FileNotFoundException();
        }
        STLSheet jaxbiSheet = DeserializeFrom(file);
        int rows,columns,width,height;
        String SheetName;
        if(jaxbiSheet == null)
        {
            throw new JAXBException("Sheet is empty");
        }
        rows = jaxbiSheet.getSTLLayout().getRows();
        columns = jaxbiSheet.getSTLLayout().getColumns();
        width = jaxbiSheet.getSTLLayout().getSTLSize().getColumnWidthUnits();
        height = jaxbiSheet.getSTLLayout().getSTLSize().getRowsHeightUnits();
        SheetName = jaxbiSheet.getName();
        LogicImpl newLogic = new LogicImpl(rows,columns,SheetName,width,height,uploaderName);
        checkLogicParams(newLogic);
        Sheet newSheet = new SheetImpl(newLogic,uploaderName);
        newSheet = checkNewSheet(newSheet, jaxbiSheet, uploaderName);
        newLogic.getSheets().add(newSheet);

        return newLogic;
    }
    @Override
    public Logic loadSheetFromXmlContent(InputStream inputStream,String uploaderName) throws Exception {
        STLSheet jaxbiSheet = DeserializeFrom(inputStream);
        int rows, columns, width, height;
        String SheetName;
        if (jaxbiSheet == null) {
            throw new JAXBException("Sheet is empty");
        }
        rows = jaxbiSheet.getSTLLayout().getRows();
        columns = jaxbiSheet.getSTLLayout().getColumns();
        width = jaxbiSheet.getSTLLayout().getSTLSize().getColumnWidthUnits();
        height = jaxbiSheet.getSTLLayout().getSTLSize().getRowsHeightUnits();
        SheetName = jaxbiSheet.getName();
        LogicImpl newLogic = new LogicImpl(rows, columns, SheetName, width, height, uploaderName);
        checkLogicParams(newLogic);
        Sheet newSheet = new SheetImpl(newLogic, uploaderName);
        newSheet = checkNewSheet(newSheet, jaxbiSheet,uploaderName);
        newLogic.getSheets().add(newSheet);
        newLogic.permissionsForSheets.put(uploaderName, Permission.OWNER);
        return newLogic;
    }
    private STLSheet DeserializeFrom(InputStream in) throws JAXBException {
        JAXBContext context = JAXBContext.newInstance("engine.jaxbClasses");
        Unmarshaller u = context.createUnmarshaller();
        return (STLSheet) u.unmarshal(in);
    }
    private void checkLogicParams(Logic logicToCheck) throws CoordinateParamOutOfRangeException
    {
        if(logicToCheck.getRows() > 50 || logicToCheck.getRows() < 1)
        {
            throw new CoordinateParamOutOfRangeException(logicToCheck.getRows(), 50, true);
        }
        if(logicToCheck.getColumns() > 20 || logicToCheck.getColumns() < 1)
        {
            throw new CoordinateParamOutOfRangeException(logicToCheck.getColumns(), 20, false);
        }
    }
    private Sheet checkNewSheet(Sheet sheetToCheck, STLSheet jaxbiSheet, String uploader) throws CoordinateOutOfRangeException, FunctionDoesNotExistException, RangeAlreadyExistsException, RangeCoordinateOutOfRangeException, RangeStartIndexLowerThenEndException {
        List<STLCell> jaxbiCells = jaxbiSheet.getSTLCells().getSTLCell();
        STLRanges jaxbiRanges = jaxbiSheet.getSTLRanges();
        for(STLCell cell : jaxbiCells)
        {
            if(cell.getRow() > sheetToCheck.getLogic().getRows() || cell.getRow() < 1)
            {
                throw new CoordinateOutOfRangeException(cell.getRow(), sheetToCheck.getLogic().getRows(), true);
            }
            if(Utilty.columnLettersToNumber(cell.getColumn()) > sheetToCheck.getLogic().getColumns() || Utilty.columnLettersToNumber(cell.getColumn()) < 1)
            {
                throw new CoordinateOutOfRangeException(Utilty.columnLettersToNumber(cell.getColumn()), sheetToCheck.getLogic().getColumns(), false);
            }
        }//added range check
        for (STLRange range : jaxbiRanges.getSTLRange())
        {
            Coordinate from = Utilty.fromExcelFormat(range.getSTLBoundaries().getFrom());
            Coordinate to = Utilty.fromExcelFormat(range.getSTLBoundaries().getTo());
            sheetToCheck.addNewRange(range.getName(), from.getRow(), from.getColumn(), to.getRow(), to.getColumn());
        }
        for (STLCell cell : jaxbiCells)
        {
            sheetToCheck =sheetToCheck.updateCellValueAndCalculate(cell.getRow(), Utilty.columnLettersToNumber(cell.getColumn()), cell.getSTLOriginalValue(), uploader);
            sheetToCheck.setVersion(0);
        }
        sheetToCheck.setVersion(1);
        return sheetToCheck;
    }
    @Override
    public Coordinate checkFormat(String rowAndColumn) throws CoordinateOutOfRangeException {
        Coordinate cellCoordinate = Utilty.fromExcelFormat(rowAndColumn);
        if(cellCoordinate.getRow() > rows || cellCoordinate.getRow() < 1)
        {
            throw new CoordinateOutOfRangeException(cellCoordinate.getRow(), rows, true);
        }
        if(cellCoordinate.getColumn() > columns || cellCoordinate.getColumn() < 1)
        {
            throw new CoordinateOutOfRangeException(cellCoordinate.getColumn(), columns, false);
        }
        return cellCoordinate;
    }
}

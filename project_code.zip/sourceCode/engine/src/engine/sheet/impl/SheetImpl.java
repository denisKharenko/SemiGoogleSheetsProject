package engine.sheet.impl;

import Logic.Cell.api.Cell;
import Logic.Cell.api.ReadonlyCell;
import Logic.Utilty.Utilty;
import engine.Cell.impl.CellImpl;
import Logic.Expression.api.Expression;
import Logic.sheet.api.ReadonlySheet;
import Logic.sheet.api.Sheet;

import java.util.*;

import Logic.api.Logic;
import Logic.Coordinate.Coordinate;
import Logic.Coordinate.CoordinateFactory;
import Logic.Exceptions.*;

public class SheetImpl implements Sheet {
    private int version;
    private Map<Coordinate, ReadonlyCell> activeCells;
    Logic logic;
    private Map<String, Set<Coordinate>> ranges;
    private String updater;

    public SheetImpl(Logic logic,String updater) {
        this.logic = logic;
        this.activeCells = new HashMap<>();
        this.ranges = new HashMap<>(); // Initialize ranges to avoid null pointer exceptions
        this.updater = updater;
    }
    public SheetImpl(Logic logic, int version, Map<String, Set<Coordinate>> ranges, String updater) {
        this.logic = logic;
        this.activeCells = new HashMap<>();
        this.version = version;
        this.ranges = new HashMap<>();
        if (ranges != null) {
            this.ranges.putAll(ranges);
        }
        this.updater = updater;
    }
    public SheetImpl(Logic logic, int version, Map<String, Set<Coordinate>> ranges) {
        this.logic = logic;
        this.activeCells = new HashMap<>();
        this.version = version;
        this.ranges = new HashMap<>();
        if (ranges != null) {
            this.ranges.putAll(ranges);
        }
    }

    @Override
    public String getUpdater() {
        return updater;
    }
    @Override
    public void setLogic(Logic logic) {
        this.logic = logic;
    }
    @Override
    public Set<ReadonlyCell> getCellsThatAreUsingThisRange(String range) {
        Set<ReadonlyCell> cells = new HashSet<>();
        for(ReadonlyCell cell : activeCells.values())
        {
            if(cell.getDependsOnRange() != null) {
                if (cell.getDependsOnRange().equals(range)) {
                    cells.add(cell);
                }
            }
        }
        return cells;
    }
    @Override
    public Map<String, Set<Coordinate>> getExisitingRanges() {
        return ranges;
    }
    @Override
    public void addNewRange(String rangeName, int rowStart, int columnStart, int rowEnd, int columnEnd) throws RangeAlreadyExistsException, RangeCoordinateOutOfRangeException, RangeStartIndexLowerThenEndException {
        checkForRangeExceptions(rangeName, rowStart, columnStart, rowEnd, columnEnd);
        if(ranges == null)
        {
            ranges = new HashMap<>();
        }
        Set<Coordinate> coordinates = new HashSet<>();
        for(int i = rowStart; i <= rowEnd; i++)
        {
            for(int j = columnStart; j <= columnEnd; j++)
            {
                coordinates.add(CoordinateFactory.createCoordinate(i, j));
            }
        }
        ranges.put(rangeName, coordinates);
    }
    public void checkForRangeExceptions(String rangeName, int rowStart, int columnStart, int rowEnd, int columnEnd) throws RangeAlreadyExistsException, RangeCoordinateOutOfRangeException, RangeStartIndexLowerThenEndException
    {
        if(rangeName == null || Objects.equals(rangeName, ""))
        {
            throw new IllegalArgumentException("Range name cannot be null or empty");
        }
        if(getRange(rangeName) != null)
        {
            throw new RangeAlreadyExistsException(rangeName);
        }
        if(rowStart > logic.getRows() || rowStart < 1)
        {
            throw new RangeCoordinateOutOfRangeException(rowStart, logic.getRows(), true, rangeName);
        }
        if(rowEnd > logic.getRows() || rowEnd < 1)
        {
            throw new RangeCoordinateOutOfRangeException(rowEnd, logic.getRows(), true, rangeName);
        }
        if(columnStart > logic.getColumns() || columnStart < 1)
        {
            throw new RangeCoordinateOutOfRangeException(columnStart, logic.getColumns(), false, rangeName);
        }
        if(columnEnd > logic.getColumns() || columnEnd < 1)
        {
            throw new RangeCoordinateOutOfRangeException(columnEnd, logic.getColumns(), false, rangeName);
        }
        if(rowStart > rowEnd)
        {
            throw new RangeStartIndexLowerThenEndException(rangeName, rowStart, rowEnd, true);
        }
        if(columnStart > columnEnd)
        {
            throw new RangeStartIndexLowerThenEndException(rangeName, columnStart, columnEnd, false);
        }
    }
    @Override
    public void removeRange(String rangeName) throws RangeInUseException
    {
        if(getRange(rangeName) == null)
        {
            throw new RangeDoesNotExistException(rangeName);
        }
        Expression expression;
        String range;
        for(ReadonlyCell cell : activeCells.values())
        {
            range = cell.getDependsOnRange();
            if(range!=null) {
                if (range.equals(rangeName)) {
                    throw new RangeInUseException(rangeName, cell.getCoordinate().getRow(), cell.getCoordinate().getColumn());
                }
            }
        }
        ranges.remove(rangeName);
    }
    @Override
    public Set<Coordinate> getRange(String rangeName)
    {
        return ranges.get(rangeName);
    }
    @Override
    public Map<Coordinate, ReadonlyCell> getActiveCells() {
        return activeCells;
    }
    @Override
    public void setVersion(int version) {
        this.version = version;
    }
    @Override
    public Logic getLogic() {
        return logic;
    }
    @Override
    public int getChangedCellsCount() {
        int cellChanged = 0;
        for(ReadonlyCell cell : activeCells.values())
        {
            if(cell.getVersion() == version)
            {
                cellChanged++;
            }
        }
        return cellChanged;
    }
    @Override
    public int getVersion() {
        return version;
    }
    @Override
    public List<String> getNumericCells()
    {
        List<String> numericCells = new ArrayList<>();
        for(ReadonlyCell cell : activeCells.values())
        {
            if(cell.getOriginalValue() != null && cell.getOriginalValue().matches("-?\\d+(\\.\\d+)?([eE][+-]?\\d+)?"))
            {
                numericCells.add(Utilty.toExcelFormat(cell.getCoordinate()));
            }
        }
        return numericCells;
    }
    @Override
    public ReadonlyCell getCell(int row, int column) throws CoordinateOutOfRangeException {
        if(row > logic.getRows() || row < 1)
        {
            throw new CoordinateOutOfRangeException(row, logic.getRows(), true);
        }
        if(column > logic.getColumns() || column < 1)
        {
            throw new CoordinateOutOfRangeException(column, logic.getColumns(), false);
        }
        return activeCells.get(CoordinateFactory.createCoordinate(row, column));
    }
    @Override
    public void setUpdater(String updater) {
        this.updater = updater;
    }

    @Override
    public Sheet updateCellValueAndCalculate(int row, int column, String value, String currentUpdater) throws CoordinateOutOfRangeException, FunctionDoesNotExistException {

        Coordinate coordinate = CoordinateFactory.createCoordinate(row, column);
        Cell newCell;

        SheetImpl newSheetVersion = copySheet();

        ///add the updater to the new Cell and to each of the cells that have changed
        if(newSheetVersion.getCell(row, column) == null)
        {
            newCell = new CellImpl(row, column, value, newSheetVersion.getVersion(), newSheetVersion);
            newSheetVersion.activeCells.put(coordinate, newCell);
        }
        else
        {
            newCell = (Cell)newSheetVersion.getCell(row, column);
            newCell.setCellOriginalValue(value);
        }
        List<Cell> cellsThatHaveChanged = new ArrayList<>();
        if(newCell.calculateEffectiveValue())
        {
            cellsThatHaveChanged.add(newCell);
        }
        for (Cell cell : newSheetVersion.orderCellsForCalculation()) {
            if (cell.calculateEffectiveValue()) {
                cellsThatHaveChanged.add(cell);
            }
        }
        //successful calculation. update sheet and relevant cells version
        if(!cellsThatHaveChanged.isEmpty())
        {
            newSheetVersion.incrementVersion();
            cellsThatHaveChanged.forEach(cell -> cell.setLastUpdater(currentUpdater));
            newSheetVersion.setUpdater(currentUpdater);
        }
        else
        {
            newSheetVersion.setUpdater(getUpdater());
        }
        //newSheetVersion.incrementVersion();
        cellsThatHaveChanged.forEach(cell -> cell.setVersion(newSheetVersion.getVersion()));
        //cellsThatHaveChanged.forEach(cell -> cell.setLastUpdater(currentUpdater));
        //order cells for calculation One more time to make sure that after all dependencies are calculated there are no circular dependencies
        newSheetVersion.orderCellsForCalculation();
        //newSheetVersion.setUpdater(currentUpdater);

        return newSheetVersion;
    }
    @Override
    public void incrementVersion() {
        version++;
    }
    public List<Cell> orderCellsForCalculation() {
        List<Cell> sortedCells = new ArrayList<>();
        Set<Cell> visited = new HashSet<>();
        Set<Cell> recStack = new HashSet<>();
        Stack<Cell> stack = new Stack<>();

        // First pass: Start with cells that have an empty dependsOn list
        for (ReadonlyCell cell : activeCells.values()) {
            if (cell.getDependsOn().isEmpty() && !visited.contains(cell)) {
                topologicalSortUtil((Cell) cell, visited, recStack, stack, new ArrayList<>());
            }
        }

        // Second pass: Process remaining cells
        for (ReadonlyCell cell : activeCells.values()) {
            if (!visited.contains(cell)) {
                topologicalSortUtil((Cell) cell, visited, recStack, stack, new ArrayList<>());
            }
        }

        // Collect cells from the stack to the sorted list
        while (!stack.isEmpty()) {
            Cell cell = stack.pop();
            sortedCells.add(cell);
        }

        return sortedCells;
    }

    private boolean topologicalSortUtil(Cell cell, Set<Cell> visited, Set<Cell> recStack, Stack<Cell> stack, List<ReadonlyCell> path) {
        visited.add(cell);
        recStack.add(cell);
        path.add(cell);

        // Visit all cells that this cell influences
        for (ReadonlyCell influencedCell : cell.getInfluencingOn()) {
            if (!visited.contains(influencedCell)) {
                if (!topologicalSortUtil((Cell) influencedCell, visited, recStack, stack, path)) {
                    return false;
                }
            } else if (recStack.contains(influencedCell)) {
                // Detect the start of the circular dependency
                List<ReadonlyCell> circularPath = new ArrayList<>();
                boolean startAdding = false;
                for (ReadonlyCell pathCell : path) {
                    if (pathCell.equals(influencedCell)) {
                        startAdding = true;
                    }
                    if (startAdding) {
                        circularPath.add(pathCell);
                    }
                }
                circularPath.add((Cell) influencedCell);
                throw new CircularDependencyException(cell.getCoordinate().getRow(), cell.getCoordinate().getColumn(), circularPath);
            }
        }

        recStack.remove(cell);
        stack.push(cell);
        path.remove(cell);
        return true;
    }
    @Override
    public ReadonlySheet publicCopySheet(){
        return copySheet();
    }
    private SheetImpl copySheet() {
        SheetImpl newSheet = new SheetImpl(logic, version, ranges);

        // First pass: create new cells in newSheet with the same properties
        for (ReadonlyCell cell : activeCells.values()) {
            newSheet.activeCells.put(cell.getCoordinate(), new CellImpl(cell.getCoordinate().getRow(), cell.getCoordinate().getColumn(), cell.getOriginalValue(), cell.getVersion(), newSheet));
            ((CellImpl) newSheet.activeCells.get(cell.getCoordinate())).deepCopyEffectiveValue(((CellImpl) cell).getEffectiveValue());
            ((CellImpl) newSheet.activeCells.get(cell.getCoordinate())).setLastUpdater(cell.getLastUpdater());
        }
        /*
        // NO NEED TO COPY DEPENDENCIES AND INFLUENCES BECAUSE WE RECALCULATE THEM IN THE SECOND PASS
        // Second pass: copy dependencies and influences
        for (ReadonlyCell cell : activeCells.values()) {
            CellImpl newCell = (CellImpl) newSheet.activeCells.get(cell.getCoordinate());

            // Copy dependsOn
            for (ReadonlyCell dependsOnCell : cell.getDependsOn()) {
                newCell.getDependsOn().add(newSheet.activeCells.get(dependsOnCell.getCoordinate()));
            }

            // Copy influencingOn
            for (ReadonlyCell influencingOnCell : cell.getInfluencingOn()) {
                newCell.getInfluencingOn().add(newSheet.activeCells.get(influencingOnCell.getCoordinate()));
            }
        }

         */
        return newSheet;
    }

}

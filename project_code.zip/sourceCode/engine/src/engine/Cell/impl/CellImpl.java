package engine.Cell.impl;

import Logic.Cell.api.CellType;
import Logic.Cell.api.ReadonlyCell;
import Logic.Cell.api.EffectiveValue;
import Logic.Cell.api.Cell;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import Logic.Expression.api.Expression;
import engine.Expression.impl.AverageExpression;
import engine.Expression.impl.SumExpression;
import engine.Parser.FunctionParser;
import Logic.sheet.api.ReadonlySheet;
import Logic.Coordinate.Coordinate;
import Logic.Coordinate.CoordinateFactory;
import Logic.Exceptions.CoordinateOutOfRangeException;
import Logic.Exceptions.FunctionDoesNotExistException;

public class CellImpl implements Cell {
    private final Coordinate coordinate;
    private String originalValue;
    private EffectiveValue effectiveValue;
    private int version;
    private final Set<ReadonlyCell> dependsOn;
    private final Set<ReadonlyCell> influencingOn;
    private ReadonlySheet sheet;
    private String lastUpdater;

    public CellImpl(int row, int column, String originalValue, int version, ReadonlySheet sheet) {
        this.coordinate = CoordinateFactory.createCoordinate(row, column);
        this.originalValue = originalValue;
        this.version = version;
        this.dependsOn = new HashSet<>();
        this.influencingOn = new HashSet<>();
        this.sheet = sheet;
        this.effectiveValue = new EffectiveValueImpl(CellType.UNKNOWN, "");//symbolizes that the cell is empty
        this.lastUpdater = "";
    }

    @Override
    public void setSheet(ReadonlySheet sheet) {
        this.sheet = sheet;
    }
    @Override
    public void setEffectiveValueForFilterAndSort(EffectiveValue effectiveValue) {
        this.effectiveValue = deepCopyEffectiveValue(effectiveValue);
    }
    @Override
    public Set<String> getInfluencingOnRanges() {
        Set<String> influencedOnRanges = new HashSet<>();
        for(String range : sheet.getExisitingRanges().keySet())
        {
            if(sheet.getRange(range).contains(coordinate))
            {
                influencedOnRanges.add(range);
            }
        }
        return influencedOnRanges;
    }
    @Override
    public String getDependsOnRange() {
        Expression expression;
        String range = null;
        try {
            expression = FunctionParser.parseExpression(originalValue, new HashSet<>());
            if (expression instanceof SumExpression || expression instanceof AverageExpression) // add another range function expressions here when implemented///////
            {
                // get the range from the expression
                //range = expression.eval(sheet).extractValueWithExpectation(String.class);
                String functionContent = originalValue.substring(1, originalValue.length() - 1);
                List<String> topLevelParts = FunctionParser.publicParser(functionContent);
                range = topLevelParts.get(1).trim();
            }
        } catch (FunctionDoesNotExistException e) {
            e.printStackTrace();
        }
        return range;
    }
    @Override
    public String getLastUpdater() {
        return lastUpdater;
    }
    @Override
    public void setLastUpdater(String updater) {
        lastUpdater = updater;
    }

    @Override
    public Coordinate getCoordinate() {
        return coordinate;
    }

    @Override
    public String getOriginalValue() {
        return originalValue;
    }

    @Override
    public void setCellOriginalValue(String value) {
        this.originalValue = value;
    }

    @Override
    public EffectiveValue getEffectiveValue() {
        return effectiveValue;
    }

    @Override
    public boolean calculateEffectiveValue() throws CoordinateOutOfRangeException, FunctionDoesNotExistException {
        // build the expression object out of the original value...
        // it can be {PLUS, 4, 5} OR {CONCAT, {ref, A4}, world}
        Set<Coordinate> tempDependentCooardinates = new HashSet<>();
        Expression expression = FunctionParser.parseExpression(originalValue, tempDependentCooardinates);
        String range = getDependsOnRange();
        if(range != null){
            Set<Coordinate> rangeCoordinates = sheet.getRange(range);
            if(rangeCoordinates != null)
            {
                tempDependentCooardinates.addAll(rangeCoordinates);
            }
        }
        EffectiveValue newEffectiveValue = expression.eval(sheet);
        dependsOn.clear();//clear the previous dependencies of this cell because its original value has changed
        for(Coordinate c : tempDependentCooardinates){
            if(sheet.getCell(c.getRow(), c.getColumn()) == null){
                sheet.getActiveCells().put(c, new CellImpl(c.getRow(), c.getColumn(), "", 1, sheet));////changed version from 0 to 1 make to fix a bug need to make sure it doesnt cause any other bugs
            }
            dependsOn.add(sheet.getCell(c.getRow(), c.getColumn()));
            sheet.getCell(c.getRow(), c.getColumn()).getInfluencingOn().add(this);
        }

        if (newEffectiveValue.equals(effectiveValue)) {
            return false;
        } else {
            effectiveValue = newEffectiveValue;
            ///update the dependent cells and influencing cells of this cell
            return true;
        }
    }

    @Override
    public int getVersion() {
        return version;
    }

    @Override
    public Set<ReadonlyCell> getDependsOn() {
        return dependsOn;
    }

    @Override
    public Set<ReadonlyCell> getInfluencingOn() {
        return influencingOn;
    }

    public EffectiveValue deepCopyEffectiveValue(EffectiveValue effectiveValue){
        this.effectiveValue = new EffectiveValueImpl(effectiveValue.getCellType(), effectiveValue.getValue());
        return effectiveValue;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        CellImpl cellImpl = (CellImpl) o;

        return coordinate.equals(cellImpl.coordinate);
    }

    @Override
    public int hashCode() {
        return coordinate.hashCode();
    }
    @Override
    public void incrementVersion() {
        version++;
    }

    @Override
    public void setVersion(int version) {
        this.version = version;
    }
}

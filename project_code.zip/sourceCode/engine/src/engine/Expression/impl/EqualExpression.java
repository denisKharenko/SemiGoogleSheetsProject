package engine.Expression.impl;

import Logic.Expression.api.Expression;
import Logic.Cell.api.CellType;
import Logic.Cell.api.EffectiveValue;
import engine.Cell.impl.EffectiveValueImpl;
import Logic.Exceptions.CoordinateOutOfRangeException;
import Logic.sheet.api.ReadonlySheet;

public class EqualExpression implements Expression {
    private Expression left;
    private Expression right;

    public EqualExpression(Expression left, Expression right) {
        this.left = left;
        this.right = right;
    }

    @Override
    public EffectiveValue eval(ReadonlySheet sheet) throws CoordinateOutOfRangeException {
        EffectiveValue leftValue = left.eval(sheet);
        EffectiveValue rightValue = right.eval(sheet);

        try {
            if (leftValue.getCellType() == rightValue.getCellType()) {
                boolean result;
                switch (leftValue.getCellType()) {
                    case NUMERIC:
                        result = leftValue.extractValueWithExpectation(Double.class).equals(rightValue.extractValueWithExpectation(Double.class));
                        break;
                    case STRING:
                        result = leftValue.extractValueWithExpectation(String.class).equals(rightValue.extractValueWithExpectation(String.class));
                        break;
                    case BOOLEAN:
                        result = leftValue.extractValueWithExpectation(Boolean.class).equals(rightValue.extractValueWithExpectation(Boolean.class));
                        break;
                    default:
                        result = false;
                }
                return new EffectiveValueImpl(CellType.BOOLEAN, result);
            } else {
                return new EffectiveValueImpl(CellType.BOOLEAN, false);
            }
        } catch (ClassCastException e) {
            return new EffectiveValueImpl(CellType.BOOLEAN, false);
        }
        catch (ArithmeticException e) {
            return new EffectiveValueImpl(CellType.BOOLEAN, false);
        }
        catch (Exception e)
        {
            return new EffectiveValueImpl(CellType.BOOLEAN, false);
        }
    }

    @Override
    public CellType getFunctionResultType() {
        return CellType.BOOLEAN;
    }
}
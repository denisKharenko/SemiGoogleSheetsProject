package engine.Expression.impl;

import Logic.Cell.api.CellType;
import Logic.Cell.api.EffectiveValue;
import engine.Cell.impl.EffectiveValueImpl;
import Logic.Exceptions.CoordinateOutOfRangeException;
import Logic.Exceptions.InvalidFunctionArgumentException;
import Logic.Exceptions.StartIndexLowerThenEndException;
import Logic.Expression.api.Expression;
import Logic.sheet.api.ReadonlySheet;

import java.util.List;

public class SubExpression implements Expression {

    private Expression source;
    private Expression startIndex;
    private Expression endIndex;

    public SubExpression(Expression source, Expression startIndex, Expression endIndex) {
        this.source = source;
        this.startIndex = startIndex;
        this.endIndex = endIndex;
    }

    @Override
    public EffectiveValue eval(ReadonlySheet sheet) throws CoordinateOutOfRangeException, InvalidFunctionArgumentException {
        EffectiveValue sourceValue = source.eval(sheet);
        EffectiveValue startIndexValue = startIndex.eval(sheet);
        EffectiveValue endIndexValue = endIndex.eval(sheet);

        if((Double)startIndexValue.getValue() != Math.floor((Double)startIndexValue.getValue()) || (Double)endIndexValue.getValue() != Math.floor((Double)endIndexValue.getValue())) {
            throw new InvalidFunctionArgumentException("SUB", List.of("STRING","Integer", "Integer"), List.of(sourceValue.getCellType().toString(),"Double", "Double"),3);
        }

        try{
            String sourceString = sourceValue.extractValueWithExpectation(String.class);
            double start = startIndexValue.extractValueWithExpectation(Double.class);
            double end = endIndexValue.extractValueWithExpectation(Double.class);

            int startInt = (int) start;
            int endInt = (int) end;
            if(startInt > endInt)
            {
                throw new StartIndexLowerThenEndException("SUB", startInt, endInt);
            }
            if (startInt < 0 || endInt >= sourceString.length()|| startInt >= sourceString.length()|| endInt < 0) {
                return new EffectiveValueImpl(CellType.UNKNOWN, "!UNDEFINED!");
            }

            String result = sourceString.substring(startInt, endInt + 1);
            return new EffectiveValueImpl(CellType.STRING, result);
        }
        catch (ClassCastException e) {
            return new EffectiveValueImpl(CellType.UNKNOWN, "!UNDEFINED!");
        }
    }

    @Override
    public CellType getFunctionResultType() {
        return CellType.STRING;
    }
}


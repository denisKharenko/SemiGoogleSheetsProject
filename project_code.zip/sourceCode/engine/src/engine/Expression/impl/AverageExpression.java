package engine.Expression.impl;

import Logic.Cell.api.CellType;
import Logic.Cell.api.EffectiveValue;
import Logic.Cell.api.ReadonlyCell;
import engine.Cell.impl.EffectiveValueImpl;
import Logic.Coordinate.Coordinate;
import Logic.Exceptions.CoordinateOutOfRangeException;
import Logic.Expression.api.Expression;
import Logic.sheet.api.ReadonlySheet;

import java.util.Set;

public class AverageExpression implements Expression {
    private Expression expression;

    public AverageExpression(Expression expression) {
        this.expression = expression;
    }

    @Override
    public EffectiveValue eval(ReadonlySheet sheet) throws CoordinateOutOfRangeException {
        EffectiveValue value = expression.eval(sheet);
        ReadonlyCell currentCell;
        try {
            double result = 0;
            int count = 0;
            Set<Coordinate> rangeCoordinates = sheet.getRange(value.extractValueWithExpectation(String.class));
            if (rangeCoordinates == null) {
                return new EffectiveValueImpl(CellType.UNKNOWN, "NaN");
            }
            for (Coordinate coordinate : rangeCoordinates) {
                currentCell = sheet.getCell(coordinate.getRow(), coordinate.getColumn());
                if (currentCell != null) {
                    value = currentCell.getEffectiveValue();
                    if (value.getCellType() == CellType.NUMERIC) {
                        result += value.extractValueWithExpectation(Double.class);
                        count++;
                    }
                }
            }
            if (count == 0) {
                return new EffectiveValueImpl(CellType.UNKNOWN, "NaN");
            }
            result = result / count;
            return new EffectiveValueImpl(CellType.NUMERIC, result);
        }
        catch (Exception e) {
            return new EffectiveValueImpl(CellType.UNKNOWN, "NaN");
        }
    }

    @Override
    public CellType getFunctionResultType() {
        return CellType.NUMERIC;
    }
}

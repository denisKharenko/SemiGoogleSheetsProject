package engine.Expression.impl;

import Logic.Expression.api.Expression;
import Logic.Cell.api.CellType;
import Logic.Cell.api.EffectiveValue;
import engine.Cell.impl.EffectiveValueImpl;
import Logic.Exceptions.CoordinateOutOfRangeException;
import Logic.sheet.api.ReadonlySheet;

public class IfExpression implements Expression {
    private Expression condition;
    private Expression trueExpression;
    private Expression falseExpression;

    public IfExpression(Expression condition, Expression trueExpression, Expression falseExpression) {
        this.condition = condition;
        this.trueExpression = trueExpression;
        this.falseExpression = falseExpression;
    }

    @Override
    public EffectiveValue eval(ReadonlySheet sheet) throws CoordinateOutOfRangeException {
        EffectiveValue conditionValue = condition.eval(sheet);
        try{
            // more validations on the expected argument types
            CellType conditionCellType = condition.getFunctionResultType();
            CellType trueExpressionCellType = trueExpression.getFunctionResultType();
            CellType falseExpressionCellType = falseExpression.getFunctionResultType();

            if((!trueExpressionCellType.equals(falseExpressionCellType) && !trueExpressionCellType.equals(CellType.UNKNOWN) && !falseExpressionCellType.equals(CellType.UNKNOWN)))
            {
                return new EffectiveValueImpl(CellType.UNKNOWN, "UNKNOWN");
            }
            if (conditionValue.getCellType() == CellType.BOOLEAN) {
                if (conditionValue.extractValueWithExpectation(Boolean.class)) {
                    return trueExpression.eval(sheet);
                } else {
                    return falseExpression.eval(sheet);
                }
            } else {
                return new EffectiveValueImpl(CellType.UNKNOWN, "UNKNOWN");
            }
        }
        catch (ClassCastException e) {
            return new EffectiveValueImpl(CellType.UNKNOWN, "UNKNOWN");
        }
        catch (ArithmeticException e) {
            return new EffectiveValueImpl(CellType.UNKNOWN, "UNKNOWN");
        }
        catch (Exception e)
        {
            return new EffectiveValueImpl(CellType.UNKNOWN, "UNKNOWN");
        }
    }

    @Override
    public CellType getFunctionResultType() {
        return trueExpression.getFunctionResultType();
    }
}

package engine.Expression.impl;

import Logic.Expression.api.Expression;
import Logic.Cell.api.CellType;
import Logic.Cell.api.EffectiveValue;
import engine.Cell.impl.EffectiveValueImpl;
import Logic.Exceptions.CoordinateOutOfRangeException;
import Logic.sheet.api.ReadonlySheet;

public class LessExpression implements Expression {
    private Expression left;
    private Expression right;

    public LessExpression(Expression left, Expression right) {
        this.left = left;
        this.right = right;
    }

    @Override
    public EffectiveValue eval(ReadonlySheet sheet) throws CoordinateOutOfRangeException {
        EffectiveValue leftValue = left.eval(sheet);
        EffectiveValue rightValue = right.eval(sheet);

        try{
            boolean result = leftValue.extractValueWithExpectation(Double.class) <= rightValue.extractValueWithExpectation(Double.class);
            return new EffectiveValueImpl(CellType.BOOLEAN, result);
        }
        catch (ClassCastException e) {
            return new EffectiveValueImpl(CellType.UNKNOWN, "UNKNOWN");
        }
        catch (ArithmeticException e) {
            return new EffectiveValueImpl(CellType.UNKNOWN, "UNKNOWN");
        }
    }

    @Override
    public CellType getFunctionResultType() {
        return CellType.BOOLEAN;
    }
}

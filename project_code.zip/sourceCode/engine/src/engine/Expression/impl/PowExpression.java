package engine.Expression.impl;

import Logic.Cell.api.CellType;
import Logic.Cell.api.EffectiveValue;
import engine.Cell.impl.EffectiveValueImpl;
import Logic.Exceptions.CoordinateOutOfRangeException;
import Logic.Expression.api.Expression;
import Logic.sheet.api.ReadonlySheet;

public class PowExpression implements Expression {

    private Expression left;
    private Expression right;

    public PowExpression(Expression left, Expression right) {
        this.left = left;
        this.right = right;
    }

    @Override
    public EffectiveValue eval(ReadonlySheet sheet) throws CoordinateOutOfRangeException {
        EffectiveValue leftValue = left.eval(sheet);
        EffectiveValue rightValue = right.eval(sheet);
        // do some checking... error handling...
        //double result = (Double) leftValue.getValue() + (Double) rightValue.getValue();
        try{
            double result = Math.pow(leftValue.extractValueWithExpectation(Double.class), rightValue.extractValueWithExpectation(Double.class));
            return new EffectiveValueImpl(CellType.NUMERIC, result);
        }
        catch (ClassCastException e) {
            return new EffectiveValueImpl(CellType.UNKNOWN, "NaN");
        }
        catch (ArithmeticException e) {
            return new EffectiveValueImpl(CellType.UNKNOWN, "NaN");
        }
    }

    @Override
    public CellType getFunctionResultType() {
        return CellType.NUMERIC;
    }
}

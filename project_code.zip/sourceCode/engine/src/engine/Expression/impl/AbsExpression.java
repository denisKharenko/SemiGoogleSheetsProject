package engine.Expression.impl;

import Logic.Cell.api.CellType;
import Logic.Cell.api.EffectiveValue;
import engine.Cell.impl.EffectiveValueImpl;
import Logic.Exceptions.CoordinateOutOfRangeException;
import Logic.Expression.api.Expression;
import Logic.sheet.api.ReadonlySheet;

public class AbsExpression implements Expression {

    private Expression expression;

    public AbsExpression(Expression expression) {
        this.expression = expression;
    }

    @Override
    public EffectiveValue eval(ReadonlySheet sheet) throws CoordinateOutOfRangeException {
        EffectiveValue value = expression.eval(sheet);
        try {
            double result = Math.abs(value.extractValueWithExpectation(Double.class));
            return new EffectiveValueImpl(CellType.NUMERIC, result);
        }
        catch (ClassCastException e) {
            return new EffectiveValueImpl(CellType.UNKNOWN, "NaN");
        }
        catch (ArithmeticException e) {
            return new EffectiveValueImpl(CellType.UNKNOWN, "NaN");
        }
    }

    @Override
    public CellType getFunctionResultType() {
        return CellType.NUMERIC;
    }
}

package engine.Expression.impl;

import Logic.Cell.api.CellType;
import Logic.Cell.api.EffectiveValue;
import engine.Cell.impl.EffectiveValueImpl;
import Logic.Coordinate.Coordinate;
import Logic.Exceptions.CoordinateOutOfRangeException;
import Logic.Expression.api.Expression;
import Logic.sheet.api.ReadonlySheet;


public class RefExpression implements Expression {

    private final Coordinate coordinate;

    public RefExpression(Coordinate coordinate) {
        this.coordinate = coordinate;
    }

    @Override
    public EffectiveValue eval(ReadonlySheet sheet) throws CoordinateOutOfRangeException {
        if(sheet.getCell(coordinate.getRow(), coordinate.getColumn())!= null){
            return sheet.getCell(coordinate.getRow(), coordinate.getColumn()).getEffectiveValue();
        }
        else{
            return new EffectiveValueImpl(CellType.UNKNOWN, "");//empty cell
        }
    }

    @Override
    public CellType getFunctionResultType() {
        return CellType.UNKNOWN;
    }
}

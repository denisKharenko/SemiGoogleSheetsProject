package engine.Expression.impl;

import Logic.Cell.api.CellType;
import Logic.Cell.api.EffectiveValue;
import engine.Cell.impl.EffectiveValueImpl;
import Logic.Exceptions.CoordinateOutOfRangeException;
import Logic.Expression.api.Expression;
import Logic.sheet.api.ReadonlySheet;

public class UpperCaseExpression implements Expression {

    private final Expression e;

    public UpperCaseExpression(Expression value) {
        this.e = value;
    }

    @Override
    public EffectiveValue eval(ReadonlySheet sheet) throws CoordinateOutOfRangeException {
        EffectiveValue eval = e.eval(sheet);
        try {
            String upperCaseResult = eval.extractValueWithExpectation(String.class).toUpperCase();
            return new EffectiveValueImpl(CellType.STRING, upperCaseResult);
        }
        catch (ClassCastException e) {
            return new EffectiveValueImpl(CellType.UNKNOWN, "!UNDEFINED!");
        }
    }

    @Override
    public CellType getFunctionResultType() {
        return CellType.STRING;
    }
}

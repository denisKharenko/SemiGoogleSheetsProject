package engine.Expression.impl;

import Logic.Expression.api.Expression;
import Logic.Cell.api.CellType;
import Logic.Cell.api.EffectiveValue;
import engine.Cell.impl.EffectiveValueImpl;
import Logic.Exceptions.CoordinateOutOfRangeException;
import Logic.sheet.api.ReadonlySheet;


public class NotExpression implements Expression {
    private Expression expression;

    public NotExpression(Expression expression) {
        this.expression = expression;
    }

    @Override
    public EffectiveValue eval(ReadonlySheet sheet) throws CoordinateOutOfRangeException {
        EffectiveValue value = expression.eval(sheet);
        try {
            if (value.getCellType() == CellType.BOOLEAN) {
                return new EffectiveValueImpl(CellType.BOOLEAN, !value.extractValueWithExpectation(Boolean.class));
            } else {
                return new EffectiveValueImpl(CellType.UNKNOWN, "UNKNOWN");
            }
        }
        catch (ClassCastException e) {
            return new EffectiveValueImpl(CellType.UNKNOWN, "UNKNOWN");
        }
        catch (Exception e)
        {
            return new EffectiveValueImpl(CellType.UNKNOWN, "UNKNOWN");
        }
    }

    @Override
    public CellType getFunctionResultType() {
        return CellType.BOOLEAN;
    }
}

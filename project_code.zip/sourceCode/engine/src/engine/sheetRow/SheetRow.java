package engine.sheetRow;

import Logic.Cell.api.ReadonlyCell;

import java.util.List;

public class SheetRow {
    private List<String> uniqueValues;
    private int columnNumber;
    private List<ReadonlyCell> regularValues;
    public SheetRow(List<String> uniqueValues, int columnNumber, List<ReadonlyCell> regularValues) {
        this.uniqueValues = uniqueValues;
        this.columnNumber = columnNumber;
        this.regularValues = regularValues;
    }
    public SheetRow(List<ReadonlyCell> regularValues)
    {
        this.regularValues = regularValues;
        this.uniqueValues = null;
        this.columnNumber = -1;
    }
    public List<String> getUniqueValues()
    {
        return uniqueValues;
    }
    public int getColumnNumber()
    {
        return columnNumber;
    }
    public List<ReadonlyCell> getRegularValues()
    {
        return regularValues;
    }
}

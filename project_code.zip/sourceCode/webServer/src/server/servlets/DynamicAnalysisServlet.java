package server.servlets;

import Logic.Coordinate.Coordinate;
import Logic.Utilty.Utilty;
import Logic.api.Logic;
import Logic.sheet.api.Sheet;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import server.utils.SessionUtils;

import java.io.IOException;
import java.io.PrintWriter;

import static serializerForShticell.Util.Constants.GSON_INSTANCE;
import static server.utils.exceptionHandlerForServer.ExceptionHandler.exceptionHandlerMethod;

@WebServlet(name = "DynamicAnalysisServlet", urlPatterns = "/dynamicAnalysis")
public class DynamicAnalysisServlet extends HttpServlet {
/*
.add("selectedCell", selectedCell)
                .add("sliderValue", String.valueOf(sliderValue))
                .add("logic", GSON_INSTANCE.toJson(logic, Logic.class))
                .add("viewedSheet", GSON_INSTANCE.toJson(viewedSheet, ReadonlySheet.class))
 */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/plain");
        PrintWriter out = response.getWriter();
        String selectedCellInExcelFormat = request.getParameter("selectedCell");
        String value = request.getParameter("sliderValue");
        String logicStr = request.getParameter("logic");
        String viewedSheetStr = request.getParameter("viewedSheet");
        Sheet viewedSheet = GSON_INSTANCE.fromJson(viewedSheetStr, Sheet.class);
        Logic logic = GSON_INSTANCE.fromJson(logicStr, Logic.class);
        String updaterName = SessionUtils.getUsername(request);
        viewedSheet.setLogic(logic);
        Sheet updatedSheet;
        try {
            Coordinate selectedCellCoordinate = Utilty.fromExcelFormat(selectedCellInExcelFormat);
            updatedSheet = viewedSheet.updateCellValueAndCalculate(selectedCellCoordinate.getRow(), selectedCellCoordinate.getColumn(), value, updaterName);
        }
        catch (Exception e)
        {
            response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            String ErrorMessage = exceptionHandlerMethod(e);
            out.write("Error updating cell: " + ErrorMessage);
            return;
        }
        String updatedSheetStr = GSON_INSTANCE.toJson(updatedSheet, Sheet.class);
        out.write(updatedSheetStr);
    }
}

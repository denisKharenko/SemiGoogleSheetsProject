package server.servlets;

import Logic.Coordinate.Coordinate;
import Logic.Utilty.Utilty;
import Logic.api.Logic;
import Logic.sheet.api.ReadonlySheet;
import Logic.sheet.api.Sheet;
import com.google.gson.reflect.TypeToken;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.io.PrintWriter;
import java.lang.reflect.Type;
import java.util.List;

import static serializerForShticell.Util.Constants.GSON_INSTANCE;
import static server.utils.exceptionHandlerForServer.ExceptionHandler.exceptionHandlerMethod;

@WebServlet(name = "FilterServlet", urlPatterns = "/filter")
public class FilterServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/plain");
        PrintWriter out = response.getWriter();
        String logicStr = request.getParameter("logicToFilter");
        String topLeft = request.getParameter("topleft");
        String buttomRight = request.getParameter("buttomRight");
        String selectedUniqueValues = request.getParameter("selectedUniqueValues");
        String columnStr = request.getParameter("selectedColumn");
        Type listOfStringsType = new TypeToken<List<String>>() {}.getType();
        List<String> selectedUniqueValuesList = GSON_INSTANCE.fromJson(selectedUniqueValues, listOfStringsType);
        Logic logic = GSON_INSTANCE.fromJson(logicStr, Logic.class);
        Coordinate topLeftCoordinate;
        Coordinate buttomRightCoordinate;
        try {
            topLeftCoordinate = GSON_INSTANCE.fromJson(topLeft, Coordinate.class);
            buttomRightCoordinate = GSON_INSTANCE.fromJson(buttomRight, Coordinate.class);
        } catch (Exception e) {
            response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            String ErrorMessage = exceptionHandlerMethod(e);
            out.write(ErrorMessage);
            return;
        }
        int column = Utilty.columnLettersToNumber(columnStr);
        ReadonlySheet filteredSheet;
        try {
            String filterStr = request.getParameter("filterBySheet");
            ReadonlySheet filterBySheet;
            String filterBySheetStr;
            if(filterStr.equalsIgnoreCase("false")) {
                filteredSheet = logic.filterSheet(selectedUniqueValuesList, column, topLeftCoordinate, buttomRightCoordinate, logic.getCurrentSheet());
            }
            else {
                filterBySheetStr = request.getParameter("viewedSheet");
                filterBySheet = GSON_INSTANCE.fromJson(filterBySheetStr, ReadonlySheet.class);
                ((Sheet) (filterBySheet)).setLogic(logic);
                filteredSheet = logic.filterSheet(selectedUniqueValuesList, column, topLeftCoordinate, buttomRightCoordinate, filterBySheet);
            }
        } catch (Exception e) {
            response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            String ErrorMessage = exceptionHandlerMethod(e);
            out.write(ErrorMessage);
            return;
        }
        String sheetStr = GSON_INSTANCE.toJson(filteredSheet, ReadonlySheet.class);
        out.write(sheetStr);
    }
}

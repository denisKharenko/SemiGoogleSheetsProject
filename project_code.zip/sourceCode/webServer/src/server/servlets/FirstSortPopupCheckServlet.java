package server.servlets;

import Logic.Coordinate.Coordinate;
import Logic.Exceptions.CoordinateOutOfRangeException;
import Logic.Exceptions.FilterSortRangeStartIndexLowerThenEndException;
import Logic.api.Logic;
import com.google.gson.Gson;
import engine.users.LogicManager;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import server.utils.ServletUtils;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import static serializerForShticell.Util.Constants.GSON_INSTANCE;
import static server.utils.exceptionHandlerForServer.ExceptionHandler.exceptionHandlerMethod;

@WebServlet(name = "FirstSortPopupCheckServlet", urlPatterns = "/firstSortPopupCheck")
public class FirstSortPopupCheckServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/plain");
        PrintWriter out = response.getWriter();
        String logicStr = request.getParameter("logicToSort" );
        String topLeft = request.getParameter("topleft");
        String buttomRight = request.getParameter("buttomRight");
        Logic logic = GSON_INSTANCE.fromJson(logicStr, Logic.class);
        Coordinate topLeftCoordinate;
        Coordinate buttomRightCoordinate;
        try{
            topLeftCoordinate = logic.checkFormat(topLeft);
            buttomRightCoordinate= logic.checkFormat(buttomRight);
            checkRangeCorrectness(topLeftCoordinate, buttomRightCoordinate);
        }
        catch (Exception e){
            response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            String ErrorMessage = exceptionHandlerMethod(e);
            out.write(ErrorMessage);
            return;
        }
        List<Coordinate> coordinates = new ArrayList<>();
        coordinates.add(topLeftCoordinate);
        coordinates.add(buttomRightCoordinate);
        String listOfCoordinates = GSON_INSTANCE.toJson(coordinates);
        out.write(listOfCoordinates);
    }
    private void checkRangeCorrectness(Coordinate topLeft, Coordinate buttomRight) throws CoordinateOutOfRangeException, FilterSortRangeStartIndexLowerThenEndException {
        int rowStart = topLeft.getRow();
        int columnStart = topLeft.getColumn();
        int rowEnd = buttomRight.getRow();
        int columnEnd = buttomRight.getColumn();
        if (rowStart > rowEnd) {
            throw new FilterSortRangeStartIndexLowerThenEndException(rowStart, rowEnd, true);
        }
        if (columnStart > columnEnd) {
            throw new FilterSortRangeStartIndexLowerThenEndException(columnStart, columnEnd, false);
        }
    }
}

package server.servlets;

import Logic.api.Logic;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import engine.impl.LogicImpl;
import engine.users.LogicManager;
import engine.users.UserManager;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import server.utils.ServletUtils;

import java.io.IOException;
import java.io.PrintWriter;
import java.lang.reflect.Type;
import java.util.Map;
import java.util.Set;

import static serializerForShticell.Util.Constants.GSON_INSTANCE;

@WebServlet(name = "UserLogicMapServlet", urlPatterns = "/userLogicMap")
public class UserLogicMapServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        //returning JSON objects, not HTML
        response.setContentType("application/json");
        try (PrintWriter out = response.getWriter()) {
            Gson gson = GSON_INSTANCE;
            LogicManager logicManager = ServletUtils.getLogicManager(getServletContext());
            Map<String, Map<String,Logic>> usersListWithLogic = logicManager.getUsersLogicMap();
            Type type = new TypeToken<Map<String, Map<String,Logic>>>() {}.getType();
            String json = gson.toJson(usersListWithLogic, type);

            out.println(json);
            out.flush();
        }
        catch (Exception e)
        {
            System.out.println(e.getMessage());
        }
    }
}

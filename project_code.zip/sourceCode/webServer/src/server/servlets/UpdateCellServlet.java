package server.servlets;

import Logic.api.Logic;
import engine.users.LogicManager;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import server.utils.ServletUtils;
import server.utils.SessionUtils;

import java.io.IOException;
import java.io.PrintWriter;

import static server.utils.exceptionHandlerForServer.ExceptionHandler.exceptionHandlerMethod;

@WebServlet(name = "UpdateCellServlet", urlPatterns = "/updateCell")
public class UpdateCellServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/plain");
        PrintWriter out = response.getWriter();
        String owner = request.getParameter("sheetOwner");
        String sheetName = request.getParameter("sheetName");
        int usersSheetVersion = Integer.parseInt(request.getParameter("usersSheetVersion"));
        String rowAndColumn = request.getParameter("rowAndColumn");
        String value = request.getParameter("value");
        LogicManager logicManager = ServletUtils.getLogicManager(getServletContext());
        Logic logic = logicManager.getUsersLogicMap().get(owner).get(sheetName);
        if (logic == null) {
            out.write("Sheet not found");
            response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            return;
        }
        synchronized (logic.getSheets())
        {
            try {
                updateCell(logic, usersSheetVersion, rowAndColumn, value, request, response, out);
            }
            catch (Exception e)
            {
                response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
                String ErrorMessage = exceptionHandlerMethod(e);
                out.write("Error updating cell: " + ErrorMessage);
                return;
            }
        }
        out.write("Cell updated successfully changes will be visible soon");
    }
    private void updateCell(Logic logic, int usersSheetVersion, String rowAndColumn, String value, HttpServletRequest request, HttpServletResponse response, PrintWriter out) throws Exception {
            if(logic.getCurrentSheet().getVersion() > usersSheetVersion)
            {
                response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
                throw new Exception("Sheet has been updated by another user, your sheet version is outdated");
            }
            logic.updateCell(usersSheetVersion, rowAndColumn, value, SessionUtils.getUsername(request));
    }
}

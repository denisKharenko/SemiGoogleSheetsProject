package server.servlets;

import Logic.api.Logic;
import Logic.permission.ApprovalOption;
import Logic.permission.PermissionRequest;
import Logic.permission.PermissionRequestStatus;
import engine.PermissionImpl.PermissionRequestImpl;
import engine.users.LogicManager;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import server.utils.ServletUtils;
import server.utils.SessionUtils;

import java.io.IOException;
import java.io.PrintWriter;

@WebServlet(name = "AckOrDenyPermissionServlet", urlPatterns = "/ackDenyRequest")
public class AckOrDenyPermissionServlet extends HttpServlet {
    /*
    .add("approveOrDeny", option.toString())
                .add("requestNumber", String.valueOf(selectedRequestNumber))
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/plain");
        PrintWriter out = response.getWriter();
        String owner = request.getParameter("ownerName");
        String sheetName = request.getParameter("sheetName");
        int requestNumber = Integer.parseInt(request.getParameter("requestNumber"));
        String approveOrDeny = request.getParameter("approveOrDeny");
        String submitterName = request.getParameter("submitterName");
        ApprovalOption option;
        try {
            option = ApprovalOption.valueOf(approveOrDeny);
        } catch (Exception e) {
            out.write("not correct ApprovalOption");
            response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            return;
        }
        LogicManager logicManager = ServletUtils.getLogicManager(getServletContext());
        Logic logic = logicManager.getUsersLogicMap().get(owner).get(sheetName);
        if (logic == null) {
            out.write("Sheet not found");
            response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            return;
        }
        PermissionRequestImpl permissionRequest;
        synchronized (logic.getPermissionRequestsForSheets()) {
            if (logic.getPermissionRequestsForSheets().size() <= requestNumber) {
                out.write("request number not found");
                response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
                return;
            }
            permissionRequest = (PermissionRequestImpl) logic.getPermissionRequestsForSheets().get(requestNumber);
            updatePermissionRequest(permissionRequest, option, request, response);
        }
        out.write(" Permission Request has been " + permissionRequest.getStatus());
    }
    private void updatePermissionRequest(PermissionRequestImpl permissionRequest, ApprovalOption option, HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        if (option.equals(ApprovalOption.ACCEPT)) {
            permissionRequest.setStatus(PermissionRequestStatus.APPROVED);
            request.setAttribute("permissionType", permissionRequest.getPermission());
            getServletContext().getRequestDispatcher("/permissionsChange").include(request, response);
        } else if (option.equals(ApprovalOption.DENY)) {
            permissionRequest.setStatus(PermissionRequestStatus.REJECTED);
        }
    }
}

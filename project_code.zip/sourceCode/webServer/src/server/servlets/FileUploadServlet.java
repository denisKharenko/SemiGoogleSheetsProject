package server.servlets;

//taken from: http://www.servletworld.com/servlet-tutorials/servlet3/multipartconfig-file-upload-example.html
// and http://docs.oracle.com/javaee/6/tutorial/doc/glraq.html

import Logic.api.Logic;
import engine.impl.LogicImpl;

import engine.users.LogicManager;
import engine.users.SheetManager;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.Part;
import server.utils.SessionUtils;

import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.util.Collection;
import java.util.Scanner;

import static server.utils.ServletUtils.LOGIC_MANAGER_ATTRIBUTE_NAME;
import static server.utils.ServletUtils.SHEET_MANAGER_ATTRIBUTE_NAME;
import static server.utils.exceptionHandlerForServer.ExceptionHandler.exceptionHandlerMethod;


@WebServlet(name = "FileUploadServlet", urlPatterns = "/upload-file")
@MultipartConfig(
        fileSizeThreshold = 1024 * 1024,           // 1 MB buffer before writing to disk
        maxFileSize = 1024 * 1024 * 50,            // 50 MB max per file
        maxRequestSize = 1024 * 1024 * 100         // 100 MB max for entire request
)

public class FileUploadServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/plain");
        LogicImpl logic = new LogicImpl(-1, -1, "", -1, -1," ");
        PrintWriter out = response.getWriter();

        try {
            Collection<Part> parts = request.getParts();
            //out.write("Total parts : " + parts.size());

            for (Part part : parts) {
                try (InputStream inputStream = part.getInputStream()) {
                    //out.println("InputStream opened successfully");
                    Logic newLogic = logic.loadSheetFromXmlContent(inputStream,SessionUtils.getUsername(request));
                    SheetManager sheetManager = (SheetManager) getServletContext().getAttribute(SHEET_MANAGER_ATTRIBUTE_NAME);
                    sheetManager.addNameToSheetManager(newLogic.getSheetName());
                    LogicManager logicManager = (LogicManager) getServletContext().getAttribute(LOGIC_MANAGER_ATTRIBUTE_NAME);
                    logicManager.addLogicToUser(SessionUtils.getUsername(request),newLogic);
                    out.write("Sheet loaded successfully. changes will be visible soon");
                } catch (Exception e) {
                    response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
                    String ErrorMessage = exceptionHandlerMethod(e);
                    out.write("Error loading sheet: " + ErrorMessage);
                    System.out.println(e.getMessage());
                }
            }
        } catch (Exception e) {
            response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            String ErrorMessage = exceptionHandlerMethod(e);
            out.write("Error loading sheet: " + ErrorMessage);
            System.out.println(e.getMessage());
        }
        finally {
            // Ensure `PrintWriter` is flushed and closed
            out.flush();
            out.close();
        }
    }

}

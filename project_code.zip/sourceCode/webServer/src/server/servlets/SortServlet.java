package server.servlets;

import Logic.Coordinate.Coordinate;
import Logic.api.Logic;
import Logic.sheet.api.ReadonlySheet;
import Logic.sheet.api.Sheet;
import com.google.gson.reflect.TypeToken;
import jakarta.servlet.GenericServlet;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.io.PrintWriter;
import java.lang.reflect.Type;
import java.util.List;

import static serializerForShticell.Util.Constants.GSON_INSTANCE;
import static server.utils.exceptionHandlerForServer.ExceptionHandler.exceptionHandlerMethod;

@WebServlet(name = "SortServlet", urlPatterns = "/sort")
public class SortServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/plain");
        PrintWriter out = response.getWriter();
        String logicStr = request.getParameter("logicToSort");
        String topLeft = request.getParameter("topleft");
        String buttomRight = request.getParameter("buttomRight");
        String selectedColumns = request.getParameter("selectedColumns");
        Type listOfStringsType = new TypeToken<List<String>>() {}.getType();
        List<String> selectedColumnsList = GSON_INSTANCE.fromJson(selectedColumns, listOfStringsType);
        Logic logic = GSON_INSTANCE.fromJson(logicStr, Logic.class);
        Coordinate topLeftCoordinate;
        Coordinate buttomRightCoordinate;
        try {
            topLeftCoordinate = GSON_INSTANCE.fromJson(topLeft, Coordinate.class);
            buttomRightCoordinate = GSON_INSTANCE.fromJson(buttomRight, Coordinate.class);
        } catch (Exception e) {
            response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            String ErrorMessage = exceptionHandlerMethod(e);
            out.write(ErrorMessage);
            return;
        }
        ReadonlySheet sortedSheet;
        try {
            String sortStr = request.getParameter("sortBySheet");
            ReadonlySheet SortBySheet;
            String sortBySheetStr;
            if(sortStr.equalsIgnoreCase("false")) {
                sortedSheet = logic.sortSheet(selectedColumnsList, topLeftCoordinate, buttomRightCoordinate, logic.getCurrentSheet());
            }
            else {
                sortBySheetStr = request.getParameter("viewedSheet");
                SortBySheet = GSON_INSTANCE.fromJson(sortBySheetStr, ReadonlySheet.class);
                ((Sheet) (SortBySheet)).setLogic(logic);
                sortedSheet = logic.sortSheet(selectedColumnsList, topLeftCoordinate, buttomRightCoordinate, SortBySheet);
            }
        } catch (Exception e) {
            response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            String ErrorMessage = exceptionHandlerMethod(e);
            out.write(ErrorMessage);
            return;
        }
        String sheetStr = GSON_INSTANCE.toJson(sortedSheet, ReadonlySheet.class);
        out.write(sheetStr);
    }
}

package server.servlets;

import Logic.api.Logic;
import Logic.permission.Permission;
import Logic.permission.PermissionRequest;
import engine.PermissionImpl.PermissionRequestImpl;
import engine.users.LogicManager;
import engine.users.SheetManager;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import server.utils.ServletUtils;
import server.utils.SessionUtils;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

@WebServlet(name = "PermissionRequestServlet", urlPatterns = "/RequestPermission")
public class PermissionRequestServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/plain");
        PrintWriter out = response.getWriter();
        String owner = request.getParameter("ownerName");
        String sheetName = request.getParameter("sheetName");
        String permission = request.getParameter("permission");
        LogicManager logicManager = ServletUtils.getLogicManager(getServletContext());
        String submitterName = SessionUtils.getUsername(request);
        Permission permissionEnum;
        Logic logic = logicManager.getUsersLogicMap().get(owner).get(sheetName);
        if(logic == null)
        {
            out.write("Sheet not found");
            response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            return;
        }
        try {
            permissionEnum = Permission.valueOf(permission);
        }
        catch (Exception e)
        {
            out.write("wrong permission");
            response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            return;
        }
        if(owner.equals(submitterName))
        {
            out.write("You are the owner of the sheet");
            response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            return;
        }
        PermissionRequest permissionRequest = new PermissionRequestImpl(permissionEnum,submitterName,sheetName,owner);
        synchronized (logic.getPermissionRequestsForSheets())
        {
            addPermissionRequestToSheet(logic.getPermissionRequestsForSheets(), permissionRequest);
        }
        out.write("Permission request sent successfully");
    }
    private void addPermissionRequestToSheet(List<PermissionRequest> listOfRequests, PermissionRequest permissionRequest)
    {
        listOfRequests.add(permissionRequest);
    }
}

package server.servlets;

import Logic.api.Logic;
import Logic.permission.ApprovalOption;
import Logic.permission.Permission;
import engine.PermissionImpl.PermissionRequestImpl;
import engine.users.LogicManager;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import server.utils.ServletUtils;
import server.utils.SessionUtils;

import java.io.IOException;
import java.io.PrintWriter;

@WebServlet(name = "ChangePermissionServlet", urlPatterns = "/permissionsChange")
public class ChangePermissionServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/plain");
        PrintWriter out = response.getWriter();
        String owner = request.getParameter("ownerName");
        String sheetName = request.getParameter("sheetName");
        String submitterName = request.getParameter("submitterName");
        Permission permission;
        try {
            permission = (Permission) request.getAttribute("permissionType");
        } catch (Exception e) {
            out.write("not correct Permission");
            response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            return;
        }
        LogicManager logicManager = ServletUtils.getLogicManager(getServletContext());
        Logic logic = logicManager.getUsersLogicMap().get(owner).get(sheetName);
        if (logic == null) {
            out.write("Sheet not found");
            response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            return;
        }
        synchronized (logic.getPermissions()) {
            logic.getPermissions().put(submitterName, permission);
        }
        out.write("Permission For " + submitterName + " has been changed to " + permission +" in sheet " + sheetName);
    }
}

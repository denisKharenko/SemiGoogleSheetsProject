package server.utils.exceptionHandlerForServer;

import Logic.Exceptions.*;
public interface ExceptionHandler {
    public static String exceptionHandlerMethod(Throwable exception) {
        String errorMessage;
        if (exception instanceof CoordinateOutOfRangeException) {
            errorMessage = ExceptionHandler.handleCoordinateOutOfRange((CoordinateOutOfRangeException) exception);
        } else if (exception instanceof CoordinateParamOutOfRangeException) {
            errorMessage = ExceptionHandler.handleCoordinateParamOfRange((CoordinateParamOutOfRangeException) exception);
        } else if (exception instanceof FunctionDoesNotExistException) {
            errorMessage = ExceptionHandler.handleFunctionDoesNotExist((FunctionDoesNotExistException) exception);
        } else if (exception instanceof CircularDependencyException) {
            errorMessage = ExceptionHandler.handleCircularDependency((CircularDependencyException) exception);
        } else if (exception instanceof StartIndexLowerThenEndException) {
            errorMessage = ExceptionHandler.handleStartIndexLowerThanEndIndex((StartIndexLowerThenEndException) exception);
        }
        else if (exception instanceof RangeDoesNotExistException) {
            errorMessage = ExceptionHandler.handleRangeDoesNotExist((RangeDoesNotExistException) exception);
        }
        else if(exception instanceof RangeAlreadyExistsException)
        {
            errorMessage = ExceptionHandler.handleRangeAlreadyExists((RangeAlreadyExistsException) exception);
        }
        else if(exception instanceof RangeCoordinateOutOfRangeException)
        {
            errorMessage = ExceptionHandler.handleRangeCoordinateOutOfRange((RangeCoordinateOutOfRangeException) exception);
        }
        else if(exception instanceof RangeInUseException)
        {
            errorMessage = ExceptionHandler.handleRangeInUse((RangeInUseException) exception);
        }
        else if(exception instanceof RangeStartIndexLowerThenEndException)
        {
            errorMessage = ExceptionHandler.handleRangeStartIndexLowerThenEnd((RangeStartIndexLowerThenEndException) exception);
        }
        else if(exception instanceof RangeContainsNoAppropriateCellsException)
        {
            errorMessage = ExceptionHandler.handleRangeContainsNoAppropriateCells((RangeContainsNoAppropriateCellsException) exception);
        }
        else if(exception instanceof InvalidExcelFormatException)
        {
            errorMessage = ExceptionHandler.handleInvalidExcelFormat((InvalidExcelFormatException) exception);
        }
        else if(exception instanceof FilterSortRangeStartIndexLowerThenEndException)
        {
            errorMessage = ExceptionHandler.handleFilterSortStartIndexLowerThenEndException((FilterSortRangeStartIndexLowerThenEndException) exception);
        }
        else {
            errorMessage = exception.getMessage();
        }
        return errorMessage;
    }
    public static String handleCoordinateOutOfRange(CoordinateOutOfRangeException e)
    {
        String message;
        if (e.isRow()) {
            message =("Row number " + e.getIndex() + " is out of range. It should be between 1 and " + e.getMaximumRange());
        } else {
            message =("Column number " + e.getIndex() + " is out of range. It should be between 1 and " + e.getMaximumRange());
        }
        return message;
    }
    public static String handleCoordinateParamOfRange(CoordinateParamOutOfRangeException e)
    {
        String message;
        if (e.isRow()) {
            message =("Row numbers " + e.getParam() + " is out of range. It should be between 1 and " + e.getMaximumRange());
        } else {
            message =("Column numbers " + e.getParam() + "is out of range. It should be between 1 and " + e.getMaximumRange());
        }
        return message;
    }
    public static String handleFileTypeNoSupported(FileTypeIsntSupportedException e)
    {
        String message;
        message =("File type is not supported");
       return message;
    }

    public static String handleFunctionDoesNotExist(FunctionDoesNotExistException e)
    {
        String message;
        message =("Function " + e.getFunctionName() + " does not exist");
        return message;
    }
    public static String handleInvalidExcelFormat(InvalidExcelFormatException e)
    {
        String message;
        message =("Invalid Excel format: " + e.getInput());
        return message;
    }
    public static String handleCircularDependency(CircularDependencyException e)
    {
        String message;
        message =("Circular dependency detected at cell:  (row: " + e.getRow() + " column: " + e.getColumn()+ ")");
        message +=(" The circular dependency that was detected is: " + e.getDependencyPathCoordinates());
        return message;
    }
    public static String handleStartIndexLowerThanEndIndex(StartIndexLowerThenEndException e)
    {
        String message;
        message= ("In the function " + e.getFunctionName() + " the start index: " + e.getStartIndex() +" is bigger than the end index: " + e.getEndIndex());
        return message;
    }
    public static String handleRangeDoesNotExist(RangeDoesNotExistException e)
    {
        String message;
        message =("Range " + e.getRangeName() + " does not exist");
        return message;
    }
    public static String handleRangeAlreadyExists(RangeAlreadyExistsException e)
    {
        String message;
        message =("Range " + e.getRangeName() + " already exists cannot create Range with the same name");
        return message;
    }
    public static String handleRangeCoordinateOutOfRange(RangeCoordinateOutOfRangeException e)
    {
        String message;
        if (e.isRow()) {
            message =("Row number " + e.getIndex() + "in the range named " + e.getRangeName() + " is out of range. It should be between 1 and " + e.getMaximumRange());
        } else {
            message =("Column number " + e.getIndex() + "in the range named " + e.getRangeName() + " is out of range. It should be between 1 and " + e.getMaximumRange());
        }
        return message;
    }
    public static String handleRangeStartIndexLowerThenEnd(RangeStartIndexLowerThenEndException e)
    {
        String message;
        if(e.isRow()) {
            message = ("In the range named " + e.getRangeName() + " the row's start index: " + e.getStartIndex() + " is bigger than the end index: " + e.getEndIndex());
        }
        else
        {
            message = ("In the range named " + e.getRangeName() + " the column's start index: " + e.getStartIndex() + " is bigger than the end index: " + e.getEndIndex());
        }
        return message;
    }
    public static String handleFilterSortStartIndexLowerThenEndException(FilterSortRangeStartIndexLowerThenEndException e)
    {
        String message;
        if(e.isRow()) {
            message = (" the row's start index: " + e.getStartIndex() + " is bigger than the end index: " + e.getEndIndex());
        }
        else
        {
            message = (" the column's start index: " + e.getStartIndex() + " is bigger than the end index: " + e.getEndIndex());
        }
        return message;
    }
    public static String handleRangeInUse(RangeInUseException e)
    {
        String message;
        message =("Range " + e.getRangeName() + " is in use at cell (row: " + e.getRow() + " column: " + e.getColumn() + ")");
        return message;
    }
    public static String handleRangeContainsNoAppropriateCells(RangeContainsNoAppropriateCellsException e)
    {
        String message;
        message =("Range " + e.getRangeName() + " contains no cells of type" + e.getMissingType());
        return message;
    }
}

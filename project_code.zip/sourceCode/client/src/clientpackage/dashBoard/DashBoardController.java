package clientpackage.dashBoard;

import Logic.api.Logic;
import Logic.permission.ApprovalOption;
import Logic.permission.Permission;
import Logic.permission.PermissionRequest;
import clientpackage.gui.mainController.MainController;
import clientpackage.pulling.UserLogicMapPullTask;
import clientpackage.util.http.HttpClientUtil;
import clientpackage.util.http.UtilityClass;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import okhttp3.*;
import org.jetbrains.annotations.NotNull;

import java.io.Closeable;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.*;

import static clientpackage.util.ClientConstants.*;
import static clientpackage.util.http.HttpClientUtil.shutdown;

public class DashBoardController implements Closeable {
    private Stage primaryStage;
    private Timer timer;
    private Map<String, Map<String,Logic>> usersListWithLogic;
    private ObservableList<SheetInfo> sheetDataList;
    private ObservableList<PermissionRequestInfo> permissionRequestDataList;
    private MainController mainController;
    private Scene scene;
    @FXML
    private Button RequestSubmitButton;

    @FXML
    private ComboBox<ApprovalOption> ackDenyComboBox;

    @FXML
    private TableView<SheetInfo> availableSheetsTableView;

    @FXML
    private Button confirmAckDenyButton;

    @FXML
    private TableColumn<SheetInfo, String> currentPermissionTableColumn;

    @FXML
    private Button loadFileButton;

    @FXML
    private ComboBox<Permission> permissionTypeComboBox;

    @FXML
    private TableView<PermissionRequestInfo> permissionsTableView;

    @FXML
    private TableColumn<SheetInfo, String> sheetNameTableColumn;

    @FXML
    private TableColumn<SheetInfo, String> sheetSizeTableColumn;

    @FXML
    private Label userNameLabel;

    @FXML
    private TableColumn<SheetInfo, String> uploaderTableColumn;

    @FXML
    private Button viewSheetButton;
    @FXML
    private TableColumn<PermissionRequestInfo, String> permissionRequestedTableColumn;
    @FXML
    private TableColumn<PermissionRequestInfo, String> approvalTableColumn;
    @FXML
    private TableColumn<PermissionRequestInfo, String> submitterTableColumn;

    public void setPrimaryStage(Stage primaryStage) {
        this.primaryStage = primaryStage;
    }
    private void populatePermissionTypeComboBox() {
        List<Permission> permissions = Arrays.stream(Permission.values())
                .filter(permission -> permission != Permission.OWNER && permission != Permission.NONE)
                .toList();
        permissionTypeComboBox.setItems(FXCollections.observableArrayList(permissions));
    }
    private void populateAckDenyComboBox() {
        List<ApprovalOption> approvalOptions = Arrays.asList(ApprovalOption.values());
        ackDenyComboBox.setItems(FXCollections.observableArrayList(approvalOptions));
    }

    public void setMainController(MainController mainController) {
        this.mainController = mainController;
    }

    @FXML
    public void initialize() {
        timer = new Timer();
        timer.scheduleAtFixedRate(new UserLogicMapPullTask(this), REFRESH_RATE, REFRESH_RATE);
        uploaderTableColumn.setCellValueFactory(cellData -> cellData.getValue().uploaderNameProperty());
        sheetNameTableColumn.setCellValueFactory(cellData -> cellData.getValue().sheetNameProperty());
        sheetSizeTableColumn.setCellValueFactory(cellData -> cellData.getValue().sheetSizeProperty());
        currentPermissionTableColumn.setCellValueFactory(cellData -> cellData.getValue().permissionTypeProperty());
        sheetDataList = FXCollections.observableArrayList();
        availableSheetsTableView.setItems(sheetDataList);
        submitterTableColumn.setCellValueFactory(cellData -> cellData.getValue().submitterNameProperty());
        permissionRequestedTableColumn.setCellValueFactory(cellData -> cellData.getValue().permissionProperty());
        approvalTableColumn.setCellValueFactory(cellData -> cellData.getValue().statusProperty());
        permissionRequestDataList = FXCollections.observableArrayList();
        permissionsTableView.setItems(permissionRequestDataList);
        availableSheetsTableView.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> {
            if (newValue != null) {
                SheetInfo selectedSheet = availableSheetsTableView.getSelectionModel().getSelectedItem();
                Logic selectedLogic = usersListWithLogic.get(selectedSheet.uploaderNameProperty().get()).get(selectedSheet.sheetNameProperty().get());
                refreshPermissionRequestDataList(selectedLogic,selectedSheet.uploaderNameProperty().get());
                RequestSubmitButton.setDisable(false);
                newValue.permissionTypeProperty().addListener((observable1, oldValue1, newValue1) -> {
                    changeViewSheetButtonAccordingToPermission(newValue1);
                });
                if(!selectedSheet.permissionTypeProperty().get().equals("NONE"))
                {
                    viewSheetButton.setDisable(false);
                }
                else
                {
                    viewSheetButton.setDisable(true);
                }
            }
            else
            {
                RequestSubmitButton.setDisable(true);
                permissionRequestDataList.clear();
                viewSheetButton.setDisable(true);
            }
            if(oldValue!=null)
            {
                oldValue.permissionTypeProperty().removeListener((observable1, oldValue1, newValue1) -> {
                    changeViewSheetButtonAccordingToPermission(newValue1);
                });
            }
        });
        permissionsTableView.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> {
            if (newValue != null) {
                PermissionRequestInfo selectedPermissionRequest = permissionsTableView.getSelectionModel().getSelectedItem();
                SheetInfo selectedSheet = availableSheetsTableView.getSelectionModel().getSelectedItem();
                if(selectedSheet != null) {
                    if (selectedPermissionRequest.statusProperty().get().equalsIgnoreCase("PENDING") && selectedSheet.uploaderNameProperty().get().equalsIgnoreCase(userNameLabel.getText())) {
                        confirmAckDenyButton.setDisable(false);
                    } else {
                        confirmAckDenyButton.setDisable(true);
                    }
                }
            }
            else
            {
                confirmAckDenyButton.setDisable(true);
            }
        });
        usersListWithLogic = new HashMap<>();
        populatePermissionTypeComboBox();
        permissionTypeComboBox.getSelectionModel().selectFirst();
        populateAckDenyComboBox();
        ackDenyComboBox.getSelectionModel().selectFirst();
    }
    private void changeViewSheetButtonAccordingToPermission(String permission) {
        if(permission.equalsIgnoreCase("NONE"))
        {
            viewSheetButton.setDisable(true);
        }
        else
        {
            viewSheetButton.setDisable(false);
        }
    }
    public void refreshPermissionRequestDataList(Logic selectedLogic, String uploadersName) {
        permissionRequestDataList.clear();
        for(PermissionRequest permissionRequest : selectedLogic.getPermissionRequestsForSheets()) {
            PermissionRequestInfo requestInfo = new PermissionRequestInfo(permissionRequest.getSubmitterName(),selectedLogic.getSheetName(),permissionRequest.getStatus().toString(),permissionRequest.getPermission().toString(),uploadersName);
            permissionRequestDataList.add(requestInfo);
        }
    }
    private void sendRequestForPermissionAckOrDeny(int selectedRequestNumber, ApprovalOption option, String sheetName, String uploadersName, String submittersName) {

        RequestBody body = new FormBody.Builder()
                .add("ownerName", uploadersName)
                .add("sheetName", sheetName)
                .add("approveOrDeny", option.toString())
                .add("requestNumber", String.valueOf(selectedRequestNumber))
                .add("submitterName", submittersName)
                .build();

        Request request = new Request.Builder()
                .url(ACK_DENY_REQUEST_URL)
                .post(body)
                .build();

        HttpClientUtil.runAsync(request, new Callback() {

            @Override
            public void onFailure(@NotNull Call call, @NotNull IOException e) {
                Platform.runLater(() -> UtilityClass.showAlert("Error", e.getMessage(), Alert.AlertType.ERROR));
            }

            @Override
            public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
                String responseBody = response.body().string();
                if (response.code() != 200) {
                    Platform.runLater(() -> UtilityClass.showAlert("Error", responseBody, Alert.AlertType.ERROR));
                } else {
                    Platform.runLater(() -> { ///add here to update the table view with the new file(the sheet it contains) and to say that the file was uploaded successfully
                        UtilityClass.showAlert("Success", responseBody , Alert.AlertType.INFORMATION);
                    });
                }
            }
        });
    }
    @FXML
    void ackDenyButtonActionListener(ActionEvent event) {
        int selectedRequestNumber = permissionsTableView.getSelectionModel().getSelectedIndex();
        PermissionRequestInfo selectedPermissionRequest = permissionsTableView.getSelectionModel().getSelectedItem();
        ApprovalOption option = ackDenyComboBox.getSelectionModel().getSelectedItem();
        SheetInfo selectedSheet = availableSheetsTableView.getSelectionModel().getSelectedItem();
        String uploadersName = selectedSheet.uploaderNameProperty().get();
        String submittersName = selectedPermissionRequest.submitterNameProperty().get();
        String sheetName = selectedSheet.sheetNameProperty().get();
        sendRequestForPermissionAckOrDeny(selectedRequestNumber,option,sheetName,uploadersName,submittersName);
    }

    @FXML
    void loadSheetButtonActionListener(ActionEvent event) {
        FileChooser fileChooser = new FileChooser();
        fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("XML Files", "*.xml"));
        File selectedFile = fileChooser.showOpenDialog(new Stage());

        if (selectedFile != null) {
            sendRequestForFileUpload(selectedFile);
        }
    }
    @FXML
    void viewSheetActionListener(ActionEvent event) {
        SheetInfo selectedSheet = availableSheetsTableView.getSelectionModel().getSelectedItem();
        Logic selectedLogic = usersListWithLogic.get(selectedSheet.uploaderNameProperty().get()).get(selectedSheet.sheetNameProperty().get());
        Platform.runLater(() -> {
            switchToSheetDisplay(selectedLogic);
        });
    }
    @FXML
    void submitRequestActionListener(ActionEvent event) {
        SheetInfo selectedSheet = availableSheetsTableView.getSelectionModel().getSelectedItem();
        Logic selectedLogic = usersListWithLogic.get(selectedSheet.uploaderNameProperty().get()).get(selectedSheet.sheetNameProperty().get());
        Permission selectedPermission = permissionTypeComboBox.getSelectionModel().getSelectedItem();
        sendRequestForPermissionChange(selectedSheet.uploaderNameProperty().get(),selectedSheet.sheetNameProperty().get(),selectedPermission);
    }
    private void switchToSheetDisplay(Logic selectedLogic) {
        //primaryStage.setMinHeight(600);
        //primaryStage.setMinWidth(700);
        primaryStage.setTitle("Shticell Sheet Display");

        URL mainControllerPage = getClass().getResource(MAIN_CONTROLLER_FXML_RESOURCE_LOCATION);
        try {
            FXMLLoader fxmlLoader = new FXMLLoader();
            fxmlLoader.setLocation(mainControllerPage);
            Parent root = fxmlLoader.load();
            mainController = fxmlLoader.getController();
            mainController.setLogic(selectedLogic);
            mainController.setUserNameLabel(userNameLabel.getText());
            mainController.setAutoUpdates();
            mainController.setFirstDisplay(true);
            mainController.setDashBoardController(this);
            mainController.setPrimaryStage(primaryStage);

            Scene scene = new Scene(root, 700, 600);
            primaryStage.setScene(scene);
            primaryStage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public void setScene(Scene scene) {
        this.scene = scene;
    }
    public Scene getScene() {
        return scene;
    }
    private void sendRequestForPermissionChange(String OwnerName, String sheetName, Permission permission) {
        RequestBody body = new FormBody.Builder()
                .add("ownerName", OwnerName)
                .add("sheetName", sheetName)
                .add("permission", permission.toString())
                .build();

        Request request = new Request.Builder()
                .url(PERMISSION_REQUEST_URL)
                .post(body)
                .build();

        HttpClientUtil.runAsync(request, new Callback() {

            @Override
            public void onFailure(@NotNull Call call, @NotNull IOException e) {
                Platform.runLater(() -> UtilityClass.showAlert("Error", e.getMessage(), Alert.AlertType.ERROR));
            }

            @Override
            public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
                String responseBody = response.body().string();
                if (response.code() != 200) {
                    Platform.runLater(() -> UtilityClass.showAlert("Error", responseBody, Alert.AlertType.ERROR));
                } else {
                    Platform.runLater(() -> { ///add here to update the table view with the new file(the sheet it contains) and to say that the file was uploaded successfully
                        UtilityClass.showAlert("Success", responseBody , Alert.AlertType.INFORMATION);
                    });
                }
            }
        });
    }

    private void sendRequestForFileUpload(File selectedFile) {

        RequestBody body =
                new MultipartBody.Builder()
                        .addFormDataPart("file1", selectedFile.getName(), RequestBody.create(selectedFile, MediaType.parse("application/xml")))
                        //.addFormDataPart("key1", "value1") // you can add multiple, different parts as needed
                        .build();

        Request request = new Request.Builder()
                .url(FILE_UPLOAD)
                .post(body)
                .build();

        HttpClientUtil.runAsync(request, new Callback() {

            @Override
            public void onFailure(@NotNull Call call, @NotNull IOException e) {
                Platform.runLater(() -> UtilityClass.showAlert("Error", "Something went wrong: " + e.getMessage(), Alert.AlertType.ERROR));
            }

            @Override
            public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
                String responseBody = response.body().string();
                if (response.code() != 200) {
                    Platform.runLater(() -> UtilityClass.showAlert("Error", responseBody, Alert.AlertType.ERROR));
                } else {
                    Platform.runLater(() -> { ///add here to update the table view with the new file(the sheet it contains) and to say that the file was uploaded successfully
                        UtilityClass.showAlert("Success", responseBody , Alert.AlertType.INFORMATION);
                    });
                }
            }
        });
    }

    public void setUserNameLabel(String userName) {
        userNameLabel.setText(userName);
    }

    public void stopTimer() {
        timer.cancel();
    }
    public void updateUserLogicMapData(Map<String, Map<String,Logic>> newUsersListWithLogic) {
        if(newUsersListWithLogic != null) {
            for (Map.Entry<String, Map<String, Logic>> entry : newUsersListWithLogic.entrySet()) {
                String username = entry.getKey();
                Map<String, Logic> sheets = entry.getValue();
                for (Map.Entry<String, Logic> newLogicMap : sheets.entrySet()) {
                    String sheetName = newLogicMap.getKey();
                    Logic newLogic = newLogicMap.getValue();
                    if (usersListWithLogic.containsKey(username)) {  //check if the userName exists for this client
                        Map<String, Logic> oldLogicMap = usersListWithLogic.get(username);
                        if (oldLogicMap.containsKey(sheetName)) {    //if the sheet of the user exists for this client
                            Logic oldLogic = oldLogicMap.get(sheetName);
                            insertNewSheets(oldLogic, newLogic);
                            Map<String, Permission> newPermissionsForSheets = newLogic.getPermissions();
                            Map<String, Permission> oldPermissionsForSheets = oldLogic.getPermissions();
                            updateSheetPermissionForCurrentUser(newPermissionsForSheets, oldPermissionsForSheets, newLogic, username);
                            updatePermissionRequests(oldLogic, newLogic, sheetName, username);
                        } else {
                            oldLogicMap.put(sheetName, newLogic);
                            updateSheetDataList(newLogic,username);
                        }
                    } else {
                        usersListWithLogic.put(username, new HashMap<>());
                        usersListWithLogic.get(username).put(sheetName, newLogic);
                        updateSheetDataList(newLogic,username);
                    }
                }
            }
        }
    }
    public void updateSheetDataList(Logic newLogic,String uploadersName) {
        boolean sheetExists = false;
        for(SheetInfo sheetInfo : sheetDataList) {
            if(sheetInfo.sheetNameProperty().get().equalsIgnoreCase(newLogic.getSheetName())) {
                if(!sheetInfo.permissionTypeProperty().get().equalsIgnoreCase(newLogic.getUserPermission(userNameLabel.getText()))) {
                    sheetInfo.setPermissionType(newLogic.getUserPermission(userNameLabel.getText()));
                }
                sheetExists = true;
                break;
            }
        }
        if(!sheetExists) {
            sheetDataList.add(new SheetInfo(uploadersName, newLogic.getSheetName(), newLogic.getRows() + "x" + newLogic.getColumns(), newLogic.getUserPermission(userNameLabel.getText())));
        }
    }

    private void insertNewSheets(Logic oldLogic, Logic newLogic) {
        boolean needToUpdateRanges = false;
        int newVersion = newLogic.getCurrentSheet().getVersion();
        int oldVersion = oldLogic.getCurrentSheet().getVersion();
        int differenceInVersion = newVersion - oldVersion;
        for (int i = 1; i <= differenceInVersion; i++) {    //update the new sheets of this user for this client
            oldLogic.getSheets().add(newLogic.getEditableSheetByVersion(oldVersion + i));
        }
        if(mainController != null)
        {
            try {
                oldLogic.getCurrentSheet().getExisitingRanges().clear();
                oldLogic.getCurrentSheet().getExisitingRanges().putAll(newLogic.getCurrentSheet().getExisitingRanges());
                mainController.updateDisplayedSheet();
            }
            catch (Exception e)//shouldnt get here but if does i want to know
            {
                e.printStackTrace();
            }
        }
    }

    private void updateSheetPermissionForCurrentUser(Map<String, Permission> newPermissionsForSheets, Map<String, Permission> oldPermissionsForSheets, Logic newLogic, String username) {
        for (Map.Entry<String, Permission> newPermission : newPermissionsForSheets.entrySet()) {//update the permissions for the sheets of this user for this client
            String userNameForPermission = newPermission.getKey();
            Permission newPermissionValue = newPermission.getValue();
            if (oldPermissionsForSheets.containsKey(userNameForPermission)) {    //if the permission for the user exists for this client
                Permission oldPermissionValue = oldPermissionsForSheets.get(userNameForPermission);
                if (!oldPermissionValue.equals(newPermissionValue)) {   //if the permission value is different
                    oldPermissionsForSheets.put(userNameForPermission, newPermissionValue);
                    updateSheetDataList(newLogic,username);
                }
            } else {
                oldPermissionsForSheets.put(userNameForPermission, newPermissionValue);
                updateSheetDataList(newLogic,username);
            }
        }
    }
    private void updatePermissionRequests(Logic oldLogic, Logic newLogic, String sheetName, String username)
    {
        int currentIndex;
        PermissionRequest oldPermissionRequest;
        PermissionRequest newPermissionRequest;
        PermissionRequestInfo permissionRequestInfo;
        SheetInfo selectedSheet = availableSheetsTableView.getSelectionModel().getSelectedItem();
        if (selectedSheet != null && !selectedSheet.sheetNameProperty().get().equalsIgnoreCase(sheetName)) {//if the requests are from a non selected sheet just switch the data without worrying about whether its changed or not
            oldLogic.getPermissionRequestsForSheets().clear();
            oldLogic.getPermissionRequestsForSheets().addAll(newLogic.getPermissionRequestsForSheets());
        }
        else {  //the data of requests of the currently selected sheet should change(flicker) only when necessary
            int oldAmountOfRequests = oldLogic.getPermissionRequestsForSheets().size();
            int differenceInRequestsAmount = newLogic.getPermissionRequestsForSheets().size() - oldAmountOfRequests;
            for(int i = 0; i < oldAmountOfRequests; i++) {
                newPermissionRequest = newLogic.getPermissionRequestsForSheets().get(i);
                oldPermissionRequest = oldLogic.getPermissionRequestsForSheets().get(i);
                if(!oldPermissionRequest.equals(newPermissionRequest)) {
                    oldLogic.getPermissionRequestsForSheets().set(i, newPermissionRequest);
                    if (selectedSheet != null) {
                        permissionRequestInfo = new PermissionRequestInfo(newPermissionRequest.getSubmitterName(), newPermissionRequest.getSheetName(), newPermissionRequest.getStatus().toString(), newPermissionRequest.getPermission().toString(), username);
                        if (permissionRequestDataList.get(i) != null) {
                            permissionRequestDataList.set(i, permissionRequestInfo);
                        } else {
                            permissionRequestDataList.add(i, permissionRequestInfo);
                        }
                    }
                }
            }
            for(int i = 0; i < differenceInRequestsAmount; i++) {
                currentIndex = oldAmountOfRequests + i;
                newPermissionRequest = newLogic.getPermissionRequestsForSheets().get(currentIndex);
                oldLogic.getPermissionRequestsForSheets().add(newPermissionRequest);
                if(selectedSheet != null) {
                    permissionRequestInfo = new PermissionRequestInfo(newPermissionRequest.getSubmitterName(), newPermissionRequest.getSheetName(), newPermissionRequest.getStatus().toString(), newPermissionRequest.getPermission().toString(), username);
                    permissionRequestDataList.add(currentIndex, permissionRequestInfo);
                }
            }
        }
    }

    @Override
    public void close() {
        timer.cancel();
        shutdown();
    }

}



package clientpackage.dashBoard;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class SheetInfo {
    private final StringProperty username;
    private final StringProperty sheetName;
    private final StringProperty sheetSize;
    private final StringProperty permissionType;

    public SheetInfo(String username, String sheetName, String sheetSize, String permissionType) {
        this.username = new SimpleStringProperty(username);
        this.sheetName = new SimpleStringProperty(sheetName);
        this.sheetSize = new SimpleStringProperty(sheetSize);
        this.permissionType = new SimpleStringProperty(permissionType);
    }

    // Getters that return properties
    public StringProperty uploaderNameProperty() {
        return username;
    }

    public StringProperty sheetNameProperty() {
        return sheetName;
    }

    public StringProperty sheetSizeProperty() {
        return sheetSize;
    }

    public StringProperty permissionTypeProperty() {
        return permissionType;
    }

    // Optional: add setters for the property values if needed
    public void setUsername(String username) {
        this.username.set(username);
    }

    public void setSheetName(String sheetName) {
        this.sheetName.set(sheetName);
    }

    public void setSheetSize(String sheetSize) {
        this.sheetSize.set(sheetSize);
    }

    public void setPermissionType(String permissionType) {
        this.permissionType.set(permissionType);
    }
}



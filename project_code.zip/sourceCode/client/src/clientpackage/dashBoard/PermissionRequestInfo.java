package clientpackage.dashBoard;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class PermissionRequestInfo {
    private final StringProperty submitterName;
    private final StringProperty sheetName;
    private final StringProperty status;
    private final StringProperty permission;
    private final StringProperty sheetOwnerName;

    public PermissionRequestInfo(String submitterName, String sheetName, String status, String permission, String sheetOwnerName) {
        this.submitterName = new SimpleStringProperty(submitterName);
        this.sheetName = new SimpleStringProperty(sheetName);
        this.status = new SimpleStringProperty(status);
        this.permission = new SimpleStringProperty(permission);
        this.sheetOwnerName = new SimpleStringProperty(sheetOwnerName);
    }

    public StringProperty submitterNameProperty() {
        return submitterName;
    }
    public StringProperty sheetNameProperty() {
        return sheetName;
    }
    public StringProperty statusProperty() {
        return status;
    }
    public StringProperty permissionProperty() {
        return permission;
    }
    public StringProperty sheetOwnerNameProperty() {
        return sheetOwnerName;
    }
    public void setPermissionStatus(String status) {
        this.status.set(status);
    }
}

package clientpackage.pulling;

import Logic.api.Logic;
import clientpackage.dashBoard.DashBoardController;
import clientpackage.util.http.HttpClientUtil;
import clientpackage.util.http.UtilityClass;
import com.google.gson.reflect.TypeToken;
import javafx.application.Platform;
import javafx.scene.control.Alert;
import javafx.scene.control.TableView;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.Request;
import okhttp3.Response;
import org.jetbrains.annotations.NotNull;

import java.io.IOException;
import java.lang.reflect.Type;
import java.util.Map;
import java.util.Set;
import java.util.TimerTask;

import static serializerForShticell.Util.Constants.GSON_INSTANCE;
import static clientpackage.util.ClientConstants.USER_LOGIC_MAP_URL;

public class UserLogicMapPullTask extends TimerTask {
    private Map<String, Map<String,Logic>> usersListWithLogic;
    private TableView<?> availableSheetsTableView;
    private DashBoardController dashboardController;
    public UserLogicMapPullTask(DashBoardController dashboardController) {
        this.dashboardController = dashboardController;
    }

    @Override
    public void run() {
        Request request = new Request.Builder()
                .url(USER_LOGIC_MAP_URL)
                .get()
                .build();

        HttpClientUtil.runAsync(request, new Callback() {
            @Override
            public void onFailure(@NotNull Call call, @NotNull IOException e) {
                Platform.runLater(() -> UtilityClass.showAlert("Error", "Failed to fetch user logic map: " + e.getMessage(), Alert.AlertType.ERROR));
            }

            @Override
            public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
                if (response.code() != 200) {
                    String responseBody = response.body().string();
                    Platform.runLater(() -> UtilityClass.showAlert("Error", "Failed to fetch user logic map: " + responseBody, Alert.AlertType.ERROR));
                } else {
                    String responseBody = response.body().string();
                    Type type = new TypeToken<Map<String, Map<String,Logic>>>() {}.getType();
                    Map<String, Map<String,Logic>> newUsersListWithLogic = GSON_INSTANCE.fromJson(responseBody, type);
                    Platform.runLater(() -> {
                    dashboardController.updateUserLogicMapData(newUsersListWithLogic);
                    });
                }
            }
        });
    }
    public Map<String, Map<String,Logic>> getUsersListWithLogic() {
        return usersListWithLogic;
    }
}
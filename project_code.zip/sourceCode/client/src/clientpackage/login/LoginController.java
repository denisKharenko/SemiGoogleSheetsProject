package clientpackage.login;

//import chat.client.component.main.ChatAppMainController;
import clientpackage.dashBoard.DashBoardController;
import clientpackage.util.ClientConstants;
import clientpackage.util.http.*;
import javafx.application.Platform;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyEvent;
import javafx.stage.Stage;
import okhttp3.*;
import org.jetbrains.annotations.NotNull;

import java.io.Closeable;
import java.io.IOException;
import java.net.URL;

import static clientpackage.util.ClientConstants.DASH_BOARD_FXML_RESOURCE_LOCATION;

public class LoginController implements Closeable {
    private Stage primaryStage;
    private DashBoardController dashBoardController;
    @FXML
    public TextField userNameTextField;

    @FXML
    public Label errorMessageLabel;

    //private ChatAppMainController chatAppMainController;

    private final StringProperty errorMessageProperty = new SimpleStringProperty();

    @Override
    public void close() {
        dashBoardController.close();
    }
    @FXML
    public void initialize() {
        errorMessageLabel.textProperty().bind(errorMessageProperty);
        //HttpClientUtil.setCookieManagerLoggingFacility(line ->
               // Platform.runLater(() ->
                        //updateHttpStatusLine(line)));
    }

    @FXML
    private void loginButtonClicked(ActionEvent event) {

        String userName = userNameTextField.getText();
        if (userName.isEmpty()) {
            errorMessageProperty.set("User name is empty. You can't login with empty user name");
            return;
        }

        //noinspection ConstantConditions
        String finalUrl = HttpUrl
                        .parse(ClientConstants.LOGIN_PAGE)
                        .newBuilder()
                        .addQueryParameter("username", userName)
                        .build()
                        .toString();

        //updateHttpStatusLine("New request is launched for: " + finalUrl);

        HttpClientUtil.runAsync(finalUrl, new Callback() {

            @Override
            public void onFailure(@NotNull Call call, @NotNull IOException e) {
                Platform.runLater(() ->
                        errorMessageProperty.set("Something went wrong: " + e.getMessage())
                );
            }

            @Override
            public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
                if (response.code() != 200) {
                    String responseBody = response.body().string();
                    Platform.runLater(() ->
                            errorMessageProperty.set("Something went wrong: " + responseBody)
                    );
                } else {
                    String responseBody = response.body().string();
                    Platform.runLater(() -> {
                        switchToDashBoard(responseBody);
                    });
                }
            }
        });
    }

    @FXML
    private void userNameKeyTyped(KeyEvent event) {
        errorMessageProperty.set("");
    }

    @FXML
    private void quitButtonClicked(ActionEvent e) {
        Platform.exit();
    }
/*
    private void updateHttpStatusLine(String data) {
        chatAppMainController.updateHttpLine(data);
    }

    public void setChatAppMainController(ChatAppMainController chatAppMainController) {
        this.chatAppMainController = chatAppMainController;
    }

 */
    public void setPrimaryStage(Stage primaryStage) {
        this.primaryStage = primaryStage;
    }
    private void switchToDashBoard(String UserName)
    {
        primaryStage.setMinHeight(600);
        primaryStage.setMinWidth(600);
        primaryStage.setTitle("Shticell Dash Board");

        URL dashBoardPage = getClass().getResource(DASH_BOARD_FXML_RESOURCE_LOCATION);
        try {
            FXMLLoader fxmlLoader = new FXMLLoader();
            fxmlLoader.setLocation(dashBoardPage);
            Parent root = fxmlLoader.load();
            dashBoardController = fxmlLoader.getController();
            dashBoardController.setPrimaryStage(primaryStage);
            dashBoardController.setUserNameLabel(UserName);


            Scene scene = new Scene(root, 700, 600);
            primaryStage.setScene(scene);
            dashBoardController.setScene(scene);
            primaryStage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

}

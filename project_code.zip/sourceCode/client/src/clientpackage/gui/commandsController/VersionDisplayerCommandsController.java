package clientpackage.gui.commandsController;

import Logic.Coordinate.Coordinate;
import Logic.Utilty.Utilty;
import clientpackage.gui.mainController.VersionDisplayMainController;
import javafx.collections.ListChangeListener;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;

import java.util.ArrayList;
import java.util.List;

public class VersionDisplayerCommandsController {
    @FXML
    private Label normalbackgroundColorAndTextLabel;

    @FXML
    private Button CellApplyChangesButton;

    @FXML
    private ColorPicker cellBackGroundColorPicker;

    @FXML
    private HBox cellColorCommandsHbox;

    @FXML
    private VBox cellCommandLabellsVbox;

    @FXML
    private ColorPicker cellTextColorPicker;

    @FXML
    private VBox columnAndRowCommandsVbox;

    @FXML
    private Button columnApplyChangesButton;

    @FXML
    private ComboBox<String> columnCellAlignmentsComboBox;

    @FXML
    private HBox columnWidthAndHeightHbox;

    @FXML
    private ComboBox<String> columnWidthComboBox;

    @FXML
    private VBox commandsVbox;

    @FXML
    private Button rowApplyChangesButton;

    @FXML
    private ComboBox<String> rowHeightComboBox;

    @FXML
    private HBox rowWidthAndHeightHbox;

    @FXML
    private Button resetCell;

    @FXML
    private Label currentAlignmentLabel;

    @FXML
    private Label currentColumnWidthLabel;

    @FXML
    private Label currentRowHeightLabel;

    @FXML
    private Rectangle backgroundColorRectangle;

    @FXML
    private Rectangle textColorRectangle;
    @FXML
    private Button startFilterButton;
    @FXML
    private Button startSortButton;

    private VersionDisplayMainController mainController;
    private Label selectedCellLabel;
    private int selectedRow;
    private int selectedColumn;

    public void setMainController(VersionDisplayMainController mainController) {
        this.mainController = mainController;
    }

    @FXML
    private void initialize() {
        // Populate ComboBoxes with numbers from 1 to 100
        for (int i = 1; i <= 100; i++) {
            columnWidthComboBox.getItems().add(String.valueOf(i));
            rowHeightComboBox.getItems().add(String.valueOf(i));
        }
        // Populate alignment ComboBox with options
        columnCellAlignmentsComboBox.getItems().addAll("Left", "Right", "Center");

        CellApplyChangesButton.setDisable(true);
        cellBackGroundColorPicker.setDisable(true);
        cellTextColorPicker.setDisable(true);
        columnApplyChangesButton.setDisable(true);
        columnCellAlignmentsComboBox.setDisable(true);
        columnWidthComboBox.setDisable(true);
        rowApplyChangesButton.setDisable(true);
        rowHeightComboBox.setDisable(true);
        commandsVbox.setDisable(true);

        CellApplyChangesButton.setOnAction(event -> applyCellChanges());
        columnApplyChangesButton.setOnAction(event -> applyColumnChanges());
        rowApplyChangesButton.setOnAction(event -> applyRowChanges());
        startFilterButton.setOnAction(event -> showFirstFilterPopup());
        startSortButton.setOnAction(event -> showFirstSortPopup());
    }
    private void showFirstSortPopup() {
        Stage popupStage = new Stage();
        VBox vbox = new VBox(10);
        TextArea topleft = new TextArea();
        TextArea buttomRight = new TextArea();
        Button okButton = new Button("OK");
        okButton.setOnAction(event -> {
            mainController.sendRequestToCheckFirstSortPopupCorrectness(topleft.getText(), buttomRight.getText(), popupStage);
        });
        vbox.getChildren().addAll(new Label("Enter Top Left Cell:"), topleft, new Label("Enter Buttom right Cell:"), buttomRight, okButton);
        Scene scene = new Scene(vbox, 300, 200);
        popupStage.setScene(scene);
        popupStage.show();
    }

    public void showSecondSortPopup(Coordinate topLeft, Coordinate bottomRight) {
        Stage popupStage = new Stage();
        VBox vbox = new VBox(10);

        // ListView for selecting columns
        ListView<String> availableColumnsListView = new ListView<>();
        List<String> columnToChooseFrom = Utilty.getAllColumnLettersInRange(topLeft.getColumn(), bottomRight.getColumn());
        availableColumnsListView.getItems().addAll(columnToChooseFrom); // Add relevant column letters
        availableColumnsListView.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE); // Allow multiple selection

        // ListView for displaying selected columns in order
        ListView<String> selectedColumnsListView = new ListView<>();

        // Handle selections in availableColumnsListView
        availableColumnsListView.getSelectionModel().getSelectedItems().addListener((ListChangeListener<String>) change -> {
            while (change.next()) {
                if (change.wasAdded()) {
                    // Add newly selected columns to the selectedColumnsListView in order
                    for (String column : change.getAddedSubList()) {
                        if (!selectedColumnsListView.getItems().contains(column)) {
                            selectedColumnsListView.getItems().add(column);
                        }
                    }
                }
                if (change.wasRemoved()) {
                    // Remove deselected columns from selectedColumnsListView
                    for (String column : change.getRemoved()) {
                        selectedColumnsListView.getItems().remove(column);
                    }
                }
            }
        });

        // Filter button to confirm the selection
        Button filterButton = new Button("Sort");
        filterButton.setOnAction(event -> {
            // Get the selected columns from the selectedColumnsListView
            List<String> selectedColumns = new ArrayList<>(selectedColumnsListView.getItems());
            if (!selectedColumns.isEmpty()) {
                mainController.sendRequestToSortSheetByColumns(selectedColumns, topLeft, bottomRight);
                popupStage.close(); // Close the popup after sorting
            }
        });

        // Add components to the VBox layout
        vbox.getChildren().addAll(
                new Label("Select columns for sorting:"),
                availableColumnsListView,
                new Label("Selected columns in order:"),
                selectedColumnsListView,
                filterButton
        );

        // Setup and show the popup stage
        Scene scene = new Scene(vbox, 300, 400);
        popupStage.setScene(scene);
        popupStage.show();
    }

    public void showFirstFilterPopup() {
        Stage popupStage = new Stage();
        VBox vbox = new VBox(10);
        TextArea topleft = new TextArea();
        TextArea buttomRight = new TextArea();
        Button okButton = new Button("OK");
        okButton.setOnAction(event -> {
            mainController.sendRequestToCheckFirstFilterPopupCorrectness(topleft.getText(), buttomRight.getText(), popupStage);
        });
        vbox.getChildren().addAll(new Label("Enter Top Left Cell:"), topleft, new Label("Enter Buttom right Cell:"), buttomRight, okButton);
        Scene scene = new Scene(vbox, 300, 200);
        popupStage.setScene(scene);
        popupStage.show();
    }
    // Function to show an alert
    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(null);  // No header for the alert
        alert.setContentText(message);
        alert.showAndWait();  // Wait for user to close the alert
    }
    public void showSecondFilterPopup(Coordinate topLeft, Coordinate bottomRight) {
        Stage popupStage = new Stage();
        VBox vbox = new VBox(10);

        // ComboBox for selecting a column
        ComboBox<String> comboBox = new ComboBox<>();
        List<String> columnToChooseFrom = Utilty.getAllColumnLettersInRange(topLeft.getColumn(), bottomRight.getColumn());
        comboBox.getItems().addAll(columnToChooseFrom); // Add relevant column letters

        // ListView for selecting multiple unique values
        ListView<String> uniqueValuesListView = new ListView<>();
        uniqueValuesListView.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE); // Multiple selection mode

        // filter Button to confirm the selection
        Button filterButton = new Button("Filter");
        filterButton.setOnAction(event -> {
            // Get the selected items from the ListView (unique values)
            List<String> selectedValues = uniqueValuesListView.getSelectionModel().getSelectedItems();
            mainController.sendRequestToFilterSheet(selectedValues,comboBox.getValue(), topLeft, bottomRight);
            popupStage.close(); // Close the popup after selection
        });

        // Handle ComboBox selection and populate the ListView with unique values
        comboBox.setOnAction(event -> {
            String selectedColumn = comboBox.getValue();
            if (selectedColumn != null) {
                // Update the ListView based on the selected column
                uniqueValuesListView.getItems().clear();
                uniqueValuesListView.getItems().addAll(mainController.updateListViewForColumn(selectedColumn, topLeft, bottomRight));
            }
        });

        vbox.getChildren().addAll(new Label("Select a column:"), comboBox, new Label("Select unique values:"), uniqueValuesListView, filterButton);
        Scene scene = new Scene(vbox, 300, 400);
        popupStage.setScene(scene);
        popupStage.show();
    }


    public void internalhandleCellClick(Label cellLabel, int row, int col)
    {
        if (selectedCellLabel != null) {
            selectedCellLabel.setId(null);
        }
        selectedCellLabel = cellLabel;
        selectedCellLabel.setId("selected-cell");
        selectedRow = row;
        selectedColumn = col;
        currentAlignmentLabel.setText(cellLabel.getTextAlignment().toString());
        currentColumnWidthLabel.setText(String.valueOf(cellLabel.getMinWidth()));
        currentRowHeightLabel.setText(String.valueOf(cellLabel.getMinHeight()));

        // Get background color
        Background background = cellLabel.getBackground();
        if (background != null && !background.getFills().isEmpty()) {
            BackgroundFill fill = background.getFills().get(0);
            Color bgColor = (Color) fill.getFill();
            backgroundColorRectangle.setFill(bgColor);
        } else {
            backgroundColorRectangle.setFill(normalbackgroundColorAndTextLabel.getBackground().getFills().get(0).getFill());
        }

        // Get text color
        Color textColor = (Color) cellLabel.getTextFill();
        textColorRectangle.setFill(textColor);
        commandsVbox.setDisable(false);
        CellApplyChangesButton.setDisable(false);
        cellBackGroundColorPicker.setDisable(false);
        cellTextColorPicker.setDisable(false);
        columnApplyChangesButton.setDisable(false);
        columnCellAlignmentsComboBox.setDisable(false);
        columnWidthComboBox.setDisable(false);
        rowApplyChangesButton.setDisable(false);
        rowHeightComboBox.setDisable(false);
    }
    public void applyCellChanges() {
        if (selectedCellLabel != null) {
            Color bgColor;
            Color textColor;
            if(cellBackGroundColorPicker.getValue() != null) {
                bgColor = cellBackGroundColorPicker.getValue();
            }
            else {
                bgColor = (Color) backgroundColorRectangle.getFill();
            }
            if(cellTextColorPicker.getValue() != null) {
                textColor = cellTextColorPicker.getValue();
            }
            else {
                textColor = (Color) textColorRectangle.getFill();
            }
            selectedCellLabel.setStyle("-fx-background-color: " + toHexString(bgColor) + "; -fx-text-fill: " + toHexString(textColor) + ";");
            backgroundColorRectangle.setFill(bgColor);
            textColorRectangle.setFill(textColor);
        }
    }

    @FXML
    void resetCellVisual(ActionEvent event) {
        if (selectedCellLabel != null) {
            selectedCellLabel.setStyle("");
            backgroundColorRectangle.setFill(normalbackgroundColorAndTextLabel.getBackground().getFills().get(0).getFill());
            textColorRectangle.setFill(normalbackgroundColorAndTextLabel.getTextFill());
        }
    }

    public void applyColumnChanges() {
        if (selectedColumn >= 0) {
            String alignment;
            double width;
            double height;
            if(columnCellAlignmentsComboBox.getValue() != null) {
                alignment = columnCellAlignmentsComboBox.getValue().toUpperCase();
            }
            else {
                alignment = currentAlignmentLabel.getText().toUpperCase();
            }
            if(columnWidthComboBox.getValue() != null) {
                width = Double.parseDouble(columnWidthComboBox.getValue());
            }
            else {
                width = Double.parseDouble(currentColumnWidthLabel.getText());
            }
            mainController.applyColumnChanges(selectedColumn, alignment, width);
            currentAlignmentLabel.setText(alignment);
            currentColumnWidthLabel.setText(String.valueOf(width));
        }
    }

    public void applyRowChanges() {
        if (selectedRow >= 0) {
            double height;
            if(rowHeightComboBox.getValue() != null) {
                height = Double.parseDouble(rowHeightComboBox.getValue());
            }
            else {
                height = Double.parseDouble(currentRowHeightLabel.getText());
            }
            mainController.applyRowChanges(selectedRow, height);
            currentRowHeightLabel.setText(String.valueOf(height));
        }
    }

    private String toHexString(Color color) {
        return String.format("#%02X%02X%02X",
                (int) (color.getRed() * 255),
                (int) (color.getGreen() * 255),
                (int) (color.getBlue() * 255));
    }
}
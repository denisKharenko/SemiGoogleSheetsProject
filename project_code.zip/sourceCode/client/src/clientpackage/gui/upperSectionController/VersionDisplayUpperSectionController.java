package clientpackage.gui.upperSectionController;

import clientpackage.gui.mainController.VersionDisplayMainController;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ProgressBar;

public class VersionDisplayUpperSectionController {

    private VersionDisplayMainController mainController;

    @FXML
    private Label ShticellHeadingLabel;

    @FXML
    private Button UpdateCellButton;

    @FXML
    private Label cellVersionLabel;

    @FXML
    private Label originalCellValueLabel;

    @FXML
    private Label selectedCellIdLabel;

    @FXML
    private Label updatersNameLabel;

    @FXML
    private Label userNameLabel;

    @FXML
    private Button darkModeButton;

    @FXML
    private Button defaultSkinButton;

    @FXML
    private Button modernBlueButton;

    @FXML
    private Button DynamicAnalysisButton;

    @FXML
    private void applyDarkModeSkin(ActionEvent event) {
        Scene scene = ((Node) event.getSource()).getScene();
        scene.getStylesheets().clear();
        scene.getStylesheets().add(getClass().getResource("/clientpackage/gui/mainController/dark-mode.css").toExternalForm());
    }

    @FXML
    private void applyModernBlueSkin(ActionEvent event) {
        Scene scene = ((Node) event.getSource()).getScene();
        scene.getStylesheets().clear();
        scene.getStylesheets().add(getClass().getResource("/clientpackage/gui/mainController/modern-blue.css").toExternalForm());
    }

    @FXML
    private void applyDefaultSkin(ActionEvent event) {
        Scene scene = ((Node) event.getSource()).getScene();
        scene.getStylesheets().clear();
        scene.getStylesheets().add(getClass().getResource("/clientpackage/gui/mainController/default.css").toExternalForm());
    }

    public void setMainController(VersionDisplayMainController mainController) {
        this.mainController = mainController;
    }

    public void UpdateSectionData(String originalValue, String effectiveValue, int cellVersion, String cellIdInExcelFormat, String lastUpdater) {
        originalCellValueLabel.setText(originalValue);
        cellVersionLabel.setText(String.valueOf(cellVersion));
        selectedCellIdLabel.setText(cellIdInExcelFormat);
        updatersNameLabel.setText(lastUpdater);
    }
    public void setUserNameLabel(String userName) {
        userNameLabel.setText(userName);
    }
    @FXML
    void dynamicAnalysisActionListener(ActionEvent event) {
        mainController.openDynamicAnalysis();
    }

}
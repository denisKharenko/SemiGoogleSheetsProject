package clientpackage.gui.upperSectionController;

//import gui.exceptionHandlerForGui.ExceptionHandler;
import clientpackage.gui.mainController.MainController;
import javafx.application.Platform;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.*;

public class UpperSectionController {
    private MainController mainController;
    @FXML
    private Label cellVersionLabel;

    @FXML
    private Button LoadFileButton;

    @FXML
    private Label LoadedFilePathLabel;

    @FXML
    private TextField newCellValueTextField;

    @FXML
    private Label originalCellValueLabel;

    @FXML
    private Label selectedCellIdLabel;

    @FXML
    private ComboBox<Integer> sheetVersionComboBox;

    @FXML
    private Label ShticellHeadingLabel;

    @FXML
    private Button UpdateCellButton;

    @FXML
    private Label warningLabel;

    @FXML
    private Label displayedSheetVersionLabel;
    @FXML
    private Button darkModeButton;

    @FXML
    private Button defaultSkinButton;

    @FXML
    private Button modernBlueButton;

    @FXML
    private Label userNameLabel;

    @FXML
    private Label updatersNameLabel;

    @FXML
    private Label permissionsLabel;

    @FXML
    private Button DynamicAnalysisButton;

    public void updatePermissionsLabel(String permissions) {
        permissionsLabel.setText(permissions);
    }
    @FXML
    private void applyDarkModeSkin(ActionEvent event) {
        Scene scene = ((Node) event.getSource()).getScene();
        scene.getStylesheets().clear();
        scene.getStylesheets().add(getClass().getResource("/clientpackage/gui/mainController/dark-mode.css").toExternalForm());
    }

    @FXML
    private void applyModernBlueSkin(ActionEvent event) {
        Scene scene = ((Node) event.getSource()).getScene();
        scene.getStylesheets().clear();
        scene.getStylesheets().add(getClass().getResource("/clientpackage/gui/mainController/modern-blue.css").toExternalForm());
    }

    @FXML
    private void applyDefaultSkin(ActionEvent event) {
        Scene scene = ((Node) event.getSource()).getScene();
        scene.getStylesheets().clear();
        scene.getStylesheets().add(getClass().getResource("/clientpackage/gui/mainController/default.css").toExternalForm());
    }
    @FXML
    void dynamicAnalysisActionListener(ActionEvent event) {
        mainController.openDynamicAnalysis();

    }

    public void setUserNameLabel(String userName) {
        userNameLabel.setText(userName);
    }

    public void setMainController(MainController mainController) {
        this.mainController = mainController;
    }
    @FXML
    public void handleSheetVersionChange(ActionEvent event) {
        Integer selectedVersion = sheetVersionComboBox.getValue();
        if (selectedVersion != null) {
            openSheetDisplayWindow(selectedVersion);
            Platform.runLater(() -> {
                if (!sheetVersionComboBox.getItems().isEmpty() && sheetVersionComboBox.getSelectionModel().getSelectedIndex() != -1) {
                    sheetVersionComboBox.getSelectionModel().clearSelection();
                }
            });
        }
    }

    private void openSheetDisplayWindow(int version) {
        try {
            mainController.openVersionDisplayer(version);
            displayedSheetVersionLabel.setText(String.valueOf(version));
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
    }

    public void UpdateSectionCellData(String originalValue, String effectiveValue, int cellVersion, String cellIdInExcelFormat,String lastUpdater) {
        originalCellValueLabel.setText(originalValue);
        cellVersionLabel.setText(String.valueOf(cellVersion));
        selectedCellIdLabel.setText(cellIdInExcelFormat);
        updatersNameLabel.setText(lastUpdater);
    }

    public void setDisplayedVersionLabelToCurrentOne(ObservableList<Integer> versionsList) {
        Platform.runLater(() -> {
            displayedSheetVersionLabel.setText(String.valueOf(versionsList.getLast()));
        });
    }
    public void updateVersionsComboBox(ObservableList<Integer> versionsList) {
        Platform.runLater(() -> {
            sheetVersionComboBox.setItems(versionsList);
        });
    }
    public void updateVersionsComboBoxAndLabel(boolean currentVersion)
    {
        if(currentVersion)
        {
            warningLabel.setVisible(false);
            sheetVersionComboBox.setStyle("");
        }
        else
        {
            warningLabel.setText("Newer Version Exist");
            warningLabel.setVisible(true);
            sheetVersionComboBox.setStyle("-fx-background-color: red;");
        }
    }

    @FXML
    void updateValueActionListener(ActionEvent event) {
        mainController.sendRequestToUpdateCellValue(selectedCellIdLabel.getText(), newCellValueTextField.getText());
    }
    public void disableSection(boolean disable){
        UpdateCellButton.setDisable(disable);
        newCellValueTextField.setDisable(disable);
    }
}
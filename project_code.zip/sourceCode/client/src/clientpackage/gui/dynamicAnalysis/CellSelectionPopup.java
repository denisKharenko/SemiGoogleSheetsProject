package clientpackage.gui.dynamicAnalysis;

import Logic.api.Logic;
import Logic.sheet.api.ReadonlySheet;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.util.List;


public class CellSelectionPopup {

    private ComboBox<String> cellComboBox; // Dropdown for cell selection
    private Spinner<Integer> minInput, maxInput, stepInput; // Range and step size inputs
    private Logic logic;
    private ReadonlySheet sheet;
    private List<String> numericCells;
    private int minValue, maxValue, stepSize;
    String selectedCell;

    public CellSelectionPopup(Logic logic, ReadonlySheet sheet) {
        this.logic = logic;
        this.sheet = sheet;
        numericCells = sheet.getNumericCells();
    }
    public void openCellSelectionPopup() {
        Stage selectionStage = new Stage();
        //selectionStage.initModality(Modality.APPLICATION_MODAL);
        selectionStage.setTitle("Select Cell and Set Slider Parameters");

        // ComboBox for choosing a cell
        cellComboBox = new ComboBox<>();
        cellComboBox.getItems().addAll(numericCells);
        cellComboBox.getSelectionModel().selectFirst(); // Default selection

        // Input fields for range and step size
        minInput = new Spinner<>(0, 100, 0); // Min value default to 0
        maxInput = new Spinner<>(0, 100, 10); // Max value default to 10
        stepInput = new Spinner<>(1, 10, 1); // Step size default to 1
        minInput.setEditable(true);
        maxInput.setEditable(true);
        stepInput.setEditable(true);

        // Button to confirm cell and slider parameters
        Button applyButton = new Button("Apply Settings");
        applyButton.setOnAction(event -> {
            selectedCell = cellComboBox.getValue();

            if(areSpinnersCorrect()) {
                minValue = minInput.getValue();
                maxValue = maxInput.getValue();
                stepSize = stepInput.getValue();
                selectionStage.close();
            }
        });

        // Layout for cell selection and slider settings
        VBox layout = new VBox(10, new Label("Select Numeric Cell:"), cellComboBox,
                new Label("Set Range and Step Size:"),
                new HBox(10, new Label("Min:"), minInput),
                new HBox(10, new Label("Max:"), maxInput),
                new HBox(10, new Label("Step:"), stepInput),
                applyButton);
        layout.setPadding(new Insets(10));

        Scene scene = new Scene(layout, 300, 250);
        selectionStage.setScene(scene);
        selectionStage.showAndWait();
    }
   public int getMinValue() {
        return minValue;
    }
    public int getMaxValue() {
        return maxValue;
    }
    public int getStepSize() {
        return stepSize;
    }
    public String getSelectedCell() {
        return selectedCell;
    }
    private boolean areSpinnersCorrect() {
        try {
            Integer.parseInt(minInput.getEditor().getText());
            Integer.parseInt(maxInput.getEditor().getText());
            Integer.parseInt(stepInput.getEditor().getText());
            if (minInput.getValue() > maxInput.getValue()) {
                return false; // Min value is greater than max value
            }
            return true; // All inputs are valid numbers
        } catch (NumberFormatException e) {
            return false; // At least one input is non-numeric
        }
    }
}


package clientpackage.gui.rangesController;

import clientpackage.gui.mainController.MainController;
import javafx.application.Platform;
import javafx.beans.value.ObservableValue;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;

import java.util.ArrayList;
import java.util.List;

public class RangesController {

    private MainController mainController;

    public void setMainController(MainController mainController) {
        this.mainController = mainController;
    }
    @FXML
    private TextField ButtomRightCellTextField;

    @FXML
    private CheckBox addNewRangeCheckbox;

    @FXML
    private HBox buttomRightCellHbox;

    @FXML
    private Button createNewRangeButton;

    @FXML
    private HBox rangeNameHbox;

    @FXML
    private TextField rangeNameTextField;

    @FXML
    private ComboBox<String> rangesComboBox;

    @FXML
    private Button removeRangeButton;

    @FXML
    private HBox topLeftCellHbox;

    @FXML
    private TextField topLeftCellTextField;

    @FXML
    private VBox rangesSectionVbox;

    @FXML
    private Label lastViewedRangeLabel;
    @FXML
    public void initialize() {
        rangesComboBox.getSelectionModel().selectedItemProperty().addListener(this::onComboBoxSelectionChanged);
    }

    @FXML
    public void checkAddNewRangeActionListener(ActionEvent event) {
        if (addNewRangeCheckbox.isSelected()) {
            buttomRightCellHbox.setDisable(false);
            topLeftCellHbox.setDisable(false);
            rangeNameHbox.setDisable(false);
            createNewRangeButton.setDisable(false);
        }
        else {
            buttomRightCellHbox.setDisable(true);
            topLeftCellHbox.setDisable(true);
            rangeNameHbox.setDisable(true);
            createNewRangeButton.setDisable(true);
        }
    }

    @FXML
    public void createRangeActionListener(ActionEvent event) {
        mainController.sendRequestToCreateRange(rangeNameTextField.getText(), topLeftCellTextField.getText(), ButtomRightCellTextField.getText());
    }

    @FXML
    public void removeRangeActionListener(ActionEvent event) {
        if(rangesComboBox.getSelectionModel().getSelectedItem() != null && rangesComboBox.getSelectionModel().getSelectedItem() != ""){
            mainController.sendRequestToRemoveRange(rangesComboBox.getSelectionModel().getSelectedItem());
        }

    }

    private void onComboBoxSelectionChanged(ObservableValue<? extends String> observable, String oldValue, String newValue) {
        if(newValue != null) {
            if (!newValue.equals(oldValue)) {
                mainController.rangeSelectionChanged(newValue);
            }
        }
    }

    public void updateRanges(ObservableList<String> ranges) {
        Platform.runLater(() -> {
            ObservableList<String> oldRanges = rangesComboBox.getItems();

            // Collect items to add to avoid modifying the list while iterating
            List<String> rangesToAdd = new ArrayList<>();
            for (String range : ranges) {
                if (!oldRanges.contains(range)) {
                    rangesToAdd.add(range);
                }
            }
            oldRanges.addAll(rangesToAdd);  // Add new items after the loop

            // Collect items to remove in a separate list
            List<String> rangesToRemove = new ArrayList<>();
            for (String range : oldRanges) {
                if (!ranges.contains(range)) {
                    rangesToRemove.add(range);
                }
            }
            oldRanges.removeAll(rangesToRemove); // Remove items after the loop

            // Ensure an empty range name is present
            if (!oldRanges.contains("")) {
                oldRanges.add(""); // Add an empty range name
            }
        });
    }

    /*
    public void updateRanges(ObservableList<String> ranges) {
        Platform.runLater(() -> {
            ObservableList<String> oldRanges = rangesComboBox.getItems();
            for(String range : ranges) {
               if(!oldRanges.contains(range))
               {
                   rangesComboBox.getItems().add(range);
               }
            }
            for(String range : oldRanges) {
                if(!ranges.contains(range))
                {
                    rangesComboBox.getItems().remove(range);
                }
            }
            if(!oldRanges.contains(""))
            {
                rangesComboBox.getItems().add(""); // Add an empty range name
            }
        });
    }

     */
    public void disableSection(boolean disable) {
        addNewRangeCheckbox.setDisable(disable);
        removeRangeButton.setDisable(disable);
        if(!disable && addNewRangeCheckbox.isSelected()) {
            createNewRangeButton.setDisable(disable);
        }
        else if(disable)
        {
            createNewRangeButton.setDisable(disable);
        }
    }
}



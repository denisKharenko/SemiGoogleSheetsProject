package clientpackage.gui.rangesController;

import clientpackage.gui.mainController.VersionDisplayMainController;
import javafx.application.Platform;
import javafx.beans.value.ObservableValue;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;

public class VersionDisplayerRangesController {
    private VersionDisplayMainController mainController;
    @FXML
    private TextField ButtomRightCellTextField;

    @FXML
    private CheckBox addNewRangeCheckbox;

    @FXML
    private Button createNewRangeButton;

    @FXML
    private TextField rangeNameTextField;

    @FXML
    private ComboBox<String> rangesComboBox;

    @FXML
    private Button removeRangeButton;

    @FXML
    private TextField topLeftCellTextField;

    public void setMainController(VersionDisplayMainController mainController) {
        this.mainController = mainController;
    }
    @FXML
    public void initialize() {
        rangesComboBox.getSelectionModel().selectedItemProperty().addListener(this::onComboBoxSelectionChanged);
    }
    private void onComboBoxSelectionChanged(ObservableValue<? extends String> observable, String oldValue, String newValue) {
        if(newValue != null) {
            if (!newValue.equals(oldValue)) {
                mainController.rangeSelectionChanged(newValue);
            }
        }
    }
    public void updateRanges(ObservableList<String> ranges) {
        Platform.runLater(() -> {
            ranges.add(""); // Add an empty range name
            rangesComboBox.setItems(ranges);
        });
    }
}

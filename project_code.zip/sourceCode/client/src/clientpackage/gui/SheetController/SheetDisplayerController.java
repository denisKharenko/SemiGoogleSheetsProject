package clientpackage.gui.SheetController;

import Logic.Cell.api.EffectiveValue;
import Logic.Cell.api.ReadonlyCell;
import Logic.Coordinate.Coordinate;
import Logic.Exceptions.CoordinateOutOfRangeException;
import Logic.sheet.api.ReadonlySheet;
import clientpackage.gui.mainController.MainController;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Region;
import javafx.scene.layout.RowConstraints;
import javafx.scene.text.TextAlignment;

import java.text.DecimalFormat;
import java.util.Set;

public class SheetDisplayerController {

    private MainController mainController;
    @FXML
    private GridPane gridPane;
    @FXML
    private ScrollPane scrollPane;

    public void setSheetData(ReadonlySheet displayedSheet, int rows, int columns, int columnWidth, int height, boolean keepStyle) throws CoordinateOutOfRangeException {
        Platform.runLater(() -> {
            try {
                populateGrid(displayedSheet, rows, columns, columnWidth, height, keepStyle);
                clearRangeMark();
            } catch (CoordinateOutOfRangeException e) {
                throw new RuntimeException(e);
            }
        });
    }

    public void setMainController(MainController mainController) {
        this.mainController = mainController;
    }

    private void populateGrid(ReadonlySheet displayedSheet, int rows, int columns, int columnWidth, int height, boolean keepStyle) throws CoordinateOutOfRangeException {
        // Clear existing content
        if(!keepStyle) {
            gridPane.getChildren().clear();
            gridPane.getColumnConstraints().clear();
            gridPane.getRowConstraints().clear();
        }
        // Make grid lines visible
        gridPane.setGridLinesVisible(false);
        gridPane.setGridLinesVisible(true);

        // Ensure GridPane can grow dynamically
        gridPane.setMaxWidth(Double.MAX_VALUE);
        gridPane.setMaxHeight(Double.MAX_VALUE);

        // Add column headers
        for (int col = 0; col < columns; col++) {
            Label colLabel;
            if(keepStyle && col < gridPane.getChildren().size()) {
                colLabel = (Label) gridPane.getChildren().get(col);
            } else {
                colLabel = new Label(String.valueOf((char) ('A' + col)));
                colLabel.getStyleClass().add("regular-cell");
                colLabel.setMinWidth(columnWidth);
                colLabel.setMaxWidth(columnWidth);
                colLabel.setMinHeight(height);
                colLabel.setMaxHeight(height);
                //colLabel.setMaxSize(Double.MAX_VALUE, Double.MAX_VALUE);
                colLabel.setWrapText(false); // Enable wrap by default
                colLabel.setTextAlignment(TextAlignment.CENTER);
                colLabel.setAlignment(Pos.CENTER);
                colLabel.setOnMouseEntered(event -> colLabel.getStyleClass().add("column-row-header-hover"));
                colLabel.setOnMouseExited(event -> colLabel.getStyleClass().remove("column-row-header-hover"));
                //GridPane.setHgrow(colLabel, Priority.ALWAYS);
                //GridPane.setVgrow(colLabel, Priority.ALWAYS);
                gridPane.add(colLabel, col + 1, 0);
                ColumnConstraints colConst = new ColumnConstraints();
                colConst.setPrefWidth(columnWidth);
                colConst.setMaxWidth(columnWidth);
                colConst.setMinWidth(columnWidth);

                gridPane.getColumnConstraints().add(colConst);
            }
        }

        // Add row headers and cell values
        for (int row = 0; row < rows; row++) {
            Label rowLabel;
            if(keepStyle && row < gridPane.getChildren().size()) {
                rowLabel = (Label) gridPane.getChildren().get(row);
            } else {
                rowLabel = new Label(String.valueOf(row + 1));

                rowLabel.getStyleClass().add("regular-cell");
                rowLabel.setMinWidth(columnWidth);
                rowLabel.setMaxWidth(columnWidth);
                rowLabel.setMinHeight(height);
                rowLabel.setMaxHeight(height);
                //rowLabel.setMaxSize(Double.MAX_VALUE, Double.MAX_VALUE);
                rowLabel.setWrapText(false); // Enable wrap by default
                rowLabel.setTextAlignment(TextAlignment.CENTER);
                rowLabel.setAlignment(Pos.CENTER);
                rowLabel.setOnMouseEntered(event -> rowLabel.getStyleClass().add("column-row-header-hover"));
                rowLabel.setOnMouseExited(event -> rowLabel.getStyleClass().remove("column-row-header-hover"));
                //GridPane.setHgrow(rowLabel, Priority.ALWAYS);
                //GridPane.setVgrow(rowLabel, Priority.ALWAYS);
                gridPane.add(rowLabel, 0, row + 1);
                RowConstraints rowConst = new RowConstraints();
                rowConst.setPrefHeight(height);
                rowConst.setMinHeight(height);
                rowConst.setMaxHeight(height);
                gridPane.getRowConstraints().add(rowConst);
            }

            for (int col = 0; col < columns; col++) {
                ReadonlyCell cell = displayedSheet.getCell(row + 1, col + 1);
                String formattedValue= "";
                DecimalFormat intFormat = new DecimalFormat("#,###");
                DecimalFormat doubleFormat = new DecimalFormat("#,###.00");
                if (cell != null && cell.getEffectiveValue() != null) {
                    EffectiveValue value = cell.getEffectiveValue();
                    if (value.getValue() instanceof Double) {
                        double doubleValue = (Double) value.getValue();
                        if (doubleValue == (int) doubleValue) {
                            formattedValue = intFormat.format((int) doubleValue);
                        } else {
                            formattedValue = doubleFormat.format(doubleValue);
                        }
                    } else {
                        formattedValue = value.getValue().toString();
                    }
                    //formattedValue = value.getValue().toString();
                    if (value.getValue() instanceof Boolean) {
                        formattedValue = ((Boolean) value.getValue()) ? "TRUE" : "FALSE";
                    }
                }
                Label cellLabel = new Label(formattedValue);
                cellLabel.getStyleClass().add("regular-cell");
                cellLabel.setMinWidth(columnWidth);
                cellLabel.setMaxWidth(columnWidth);
                cellLabel.setMinHeight(height);
                cellLabel.setMaxHeight(height);
                cellLabel.setWrapText(false); // Enable wrap by default
                cellLabel.setTextAlignment(TextAlignment.CENTER);
                cellLabel.setAlignment(Pos.CENTER);
                //cellLabel.setMaxSize(Double.MAX_VALUE, Double.MAX_VALUE);
                //GridPane.setHgrow(cellLabel, Priority.ALWAYS);
                //GridPane.setVgrow(cellLabel, Priority.ALWAYS);
                int finalRow = row;
                int finalCol = col;
                // Check if there's an existing label at the specified row and column
                if(keepStyle) {
                    // Check if there's an existing label at the specified row and column
                    for (Node node : gridPane.getChildren()) {
                        if (GridPane.getColumnIndex(node) == (finalCol + 1) && GridPane.getRowIndex(node) == (finalRow + 1) && node instanceof Label) {
                            Label existingLabel = (Label) node;

                            // Copy the style from the existing label
                            String existingStyle = existingLabel.getStyle();
                            if (existingStyle != null && !existingStyle.isEmpty()) {
                                cellLabel.setStyle(existingStyle);
                            }
                            // Copy properties from the existing label
                            cellLabel.setMinWidth(existingLabel.getMinWidth());
                            cellLabel.setMaxWidth(existingLabel.getMaxWidth());
                            cellLabel.setMinHeight(existingLabel.getMinHeight());
                            cellLabel.setMaxHeight(existingLabel.getMaxHeight());
                            cellLabel.setWrapText(existingLabel.isWrapText());
                            cellLabel.setTextAlignment(existingLabel.getTextAlignment());
                            cellLabel.setAlignment(existingLabel.getAlignment());

                            // Remove the existing label from the gridPane
                            gridPane.getChildren().remove(node);

                            break;
                        }
                    }
                }
                cellLabel.setOnMouseClicked(event -> handleCellClick(cellLabel, finalRow, finalCol));
                // Add hover effect
                cellLabel.setOnMouseEntered(event -> cellLabel.getStyleClass().add("cell-hover"));
                cellLabel.setOnMouseExited(event -> cellLabel.getStyleClass().remove("cell-hover"));
                gridPane.add(cellLabel, col + 1, row + 1);
            }
        }
        gridPane.setPrefWidth(Region.USE_COMPUTED_SIZE);
        gridPane.setPrefHeight(Region.USE_COMPUTED_SIZE);
        gridPane.setMinWidth(Region.USE_COMPUTED_SIZE);
        gridPane.setMinHeight(Region.USE_COMPUTED_SIZE);
    }

    private void handleCellClick(Label cellLabel, int row, int col) {
        mainController.handleCellClick(cellLabel, row, col);
        //clearRangeMark(); removed so range will be seen even when interacting with the board
    }
    public void internalApplyColumnChanges(int column, String alignment, double width) {
        // Iterate through each child of the GridPane
        for (Node node : gridPane.getChildren()) {
            // Check if the node is a Label and if it belongs to the specified column
            if (node instanceof Label && GridPane.getColumnIndex(node) == (column+ 1)) {
                Label cellLabel = (Label) node;

                cellLabel.setTextAlignment(TextAlignment.valueOf(alignment));
                if (alignment.equalsIgnoreCase("Left")) {
                    cellLabel.setAlignment(Pos.CENTER_LEFT);
                } else if (alignment.equalsIgnoreCase("Right")) {
                    cellLabel.setAlignment(Pos.CENTER_RIGHT);
                } else {
                    cellLabel.setAlignment(Pos.valueOf(alignment));
                }
                cellLabel.setMinWidth(width);
                cellLabel.setMaxWidth(width);
                //cellLabel.setPrefHeight(height);
                //cellLabel.setMaxSize(Double.MAX_VALUE, Double.MAX_VALUE);
                //GridPane.setHgrow(cellLabel, Priority.ALWAYS);
                //GridPane.setVgrow(cellLabel, Priority.ALWAYS);
            }
        }
        ColumnConstraints colConst = gridPane.getColumnConstraints().get(column + 1);
        colConst.setPrefWidth(width);
        colConst.setMinWidth(width);
        colConst.setMaxWidth(width);
        gridPane.setGridLinesVisible(false);
        gridPane.setGridLinesVisible(true); // Refresh grid lines
    }

    public void internalApplyRowChanges(int row, double height) {
        for (Node node : gridPane.getChildren()) {
            // Check if the node is a Label and if it belongs to the specified row
            if (node instanceof Label && GridPane.getRowIndex(node) == (row + 1) ) {
                Label cellLabel = (Label) node;
                cellLabel.setMinHeight(height);
                cellLabel.setMaxHeight(height);
                cellLabel.setPrefHeight(height);
                //cellLabel.setMaxSize(Double.MAX_VALUE, Double.MAX_VALUE);
                //GridPane.setVgrow(cellLabel, Priority.ALWAYS);
                //GridPane.setHgrow(cellLabel, Priority.ALWAYS);
            }
        }
            RowConstraints rowConst = gridPane.getRowConstraints().get(row + 1);
            rowConst.setPrefHeight(height);
            rowConst.setMinHeight(height);
            rowConst.setMaxHeight(height);
            gridPane.setGridLinesVisible(false);
            gridPane.setGridLinesVisible(true); // Refresh grid lines
    }
    public void markDependsAndInfluencingOnCells(Set<ReadonlyCell> dependsOn, Set<ReadonlyCell> influencingOn)
    {
        Label cellLabel;
        int row;
        int col;
        clearDependsAndInfluencingOnCells();
        for(ReadonlyCell cell : dependsOn) {
            row = cell.getCoordinate().getRow();
            col = cell.getCoordinate().getColumn();
            for (Node node : gridPane.getChildren()) {
                // Check if the node is a Label and if it belongs to the specified row
                if (node instanceof Label && GridPane.getRowIndex(node) == (row) && GridPane.getColumnIndex(node) == (col)) {
                    cellLabel = (Label) node;
                    cellLabel.getStyleClass().add("depends-on-cell");
                    break;
                }
            }
        }
        for (ReadonlyCell cell : influencingOn) {
            row = cell.getCoordinate().getRow();
            col = cell.getCoordinate().getColumn();
            for (Node node : gridPane.getChildren()) {
                // Check if the node is a Label and if it belongs to the specified row
                if (node instanceof Label && GridPane.getRowIndex(node) == (row) && GridPane.getColumnIndex(node) == (col)) {
                    cellLabel = (Label) node;
                    cellLabel.getStyleClass().add("influence-on-cell");
                    break;
                }
            }
        }
    }
    public void clearDependsAndInfluencingOnCells()
    {
        Label cellLabel;
        for (Node node : gridPane.getChildren()) {
            if (node instanceof Label) {
                cellLabel = (Label) node;
                cellLabel.getStyleClass().remove("depends-on-cell");
                cellLabel.getStyleClass().remove("influence-on-cell");
            }
        }
    }
    public void markRange(Set<Coordinate> rangeCoordinates)
    {
        Label cellLabel;
        int row;
        int col;
       clearRangeMark();
       for(Coordinate coordinate : rangeCoordinates) {
            row = coordinate.getRow();
            col = coordinate.getColumn();
            for (Node node : gridPane.getChildren()) {
                // Check if the node is a Label and if it belongs to the specified row
                if (node instanceof Label && GridPane.getRowIndex(node) == (row) && GridPane.getColumnIndex(node) == (col)) {
                    cellLabel = (Label) node;
                    cellLabel.getStyleClass().add("range-cell");
                    break;
                }
            }
       }

    }
    public void clearRangeMark()
    {
        Label cellLabel;
        for (Node node : gridPane.getChildren()) {
            if (node instanceof Label) {
                cellLabel = (Label) node;
                cellLabel.getStyleClass().remove("range-cell");
            }
        }
    }
}
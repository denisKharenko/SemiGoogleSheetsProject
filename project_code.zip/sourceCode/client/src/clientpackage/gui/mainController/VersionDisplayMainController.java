package clientpackage.gui.mainController;

import Logic.Cell.api.ReadonlyCell;
import Logic.Coordinate.Coordinate;
import Logic.Coordinate.CoordinateFactory;
import Logic.Exceptions.CoordinateOutOfRangeException;
import Logic.Exceptions.FilterSortRangeStartIndexLowerThenEndException;
import Logic.Utilty.Utilty;
import Logic.api.Logic;
import Logic.sheet.api.ReadonlySheet;
import Logic.sheet.api.Sheet;
import clientpackage.gui.SheetController.VersionDisplaySheetDisplayerController;
import clientpackage.gui.commandsController.VersionDisplayerCommandsController;
import clientpackage.gui.dynamicAnalysis.CellSelectionPopup;
import clientpackage.gui.rangesController.VersionDisplayerRangesController;
import clientpackage.gui.upperSectionController.VersionDisplayUpperSectionController;
import clientpackage.util.http.HttpClientUtil;
import clientpackage.util.http.UtilityClass;
import com.google.gson.reflect.TypeToken;
import javafx.application.Platform;
import javafx.beans.value.ChangeListener;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.Slider;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import okhttp3.*;
import org.jetbrains.annotations.NotNull;

import java.io.IOException;
import java.lang.reflect.Type;
import java.util.List;
import java.util.Set;

import static clientpackage.util.ClientConstants.*;
import static serializerForShticell.Util.Constants.GSON_INSTANCE;

public class VersionDisplayMainController {
    private VersionDisplaySheetDisplayerController sheetDisplayerController;
    private Logic logic;
    private VersionDisplayUpperSectionController upperSectionController;
    private VersionDisplayerCommandsController commandsController;
    private VersionDisplayerRangesController rangesController;
    private ReadonlySheet viewedSheet;
    private String selectedCellForDynamicAnalysis;
    private int currentStepSize = 1;



    @FXML
    private Slider analysisSlider;
    @FXML
    private BorderPane borderPane;

    @FXML
    private VBox leftSectionVbox;

    // Define the listener as a class member
    private final ChangeListener<Number> sliderListener = (obs, oldVal, newVal) -> {
        int sliderValue = (int) Math.round(newVal.doubleValue() / currentStepSize) * currentStepSize;

        // Only update the slider and send the request if the snapped value is different from the previous value
        if (sliderValue != oldVal.intValue()) {
            analysisSlider.setValue(sliderValue); // Snap the slider to the nearest step
            sendRequestToUpdateDynamicAnalysisCellValue(selectedCellForDynamicAnalysis, sliderValue); // Update with new value
        }
    };

    public void setLogic(Logic logic) {
        this.logic = logic;
    }

    @FXML
    public void initialize() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource(VERSION_DISPLAY_SHEET_DISPLAYER_FXML_RESOURCE_LOCATION));
            ScrollPane sheetDisplayer = loader.load();
            sheetDisplayerController = loader.getController();
            sheetDisplayerController.setMainController(this);
            loader = new FXMLLoader(getClass().getResource(VERSION_DISPLAY_UPPER_SECTION_FXML_RESOURCE_LOCATION));
            GridPane upperSection = loader.load();
            upperSectionController = loader.getController();
            borderPane.setCenter(sheetDisplayer);
            upperSectionController.setMainController(this);
            borderPane.setTop(upperSection);
            loader = new FXMLLoader(getClass().getResource(VERSION_DISPLAY_COMMANDS_CONTROLLER_FXML_RESOURCE_LOCATION));
            ScrollPane commands = loader.load();
            commandsController = loader.getController();
            commandsController.setMainController(this);
            leftSectionVbox.getChildren().add(commands);
            loader = new FXMLLoader(getClass().getResource(VERSION_DISPLAY_RANGES_CONTROLLER_FXML_RESOURCE_LOCATION));
            ScrollPane ranges = loader.load();
            rangesController = loader.getController();
            rangesController.setMainController(this);
            leftSectionVbox.getChildren().add(ranges);
            borderPane.setLeft(leftSectionVbox);
            // Update cell value based on slider value changes
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void setUserNameLabel(String userName) {
        upperSectionController.setUserNameLabel(userName);
    }

    public void sendRequestToCheckFirstSortPopupCorrectness(String topLeft, String buttomRight, Stage stage) {
        RequestBody body = new FormBody.Builder()
                .add("topleft", topLeft)
                .add("buttomRight", buttomRight)
                .add("logicToSort", GSON_INSTANCE.toJson(logic, Logic.class))
                .build();
        Request request = new Request.Builder()
                .url(FIRST_SORT_POPUP_CHECK_URL)
                .post(body)
                .build();

        HttpClientUtil.runAsync(request, new Callback() {

            @Override
            public void onFailure(@NotNull Call call, @NotNull IOException e) {
                Platform.runLater(() -> UtilityClass.showAlert("Error", e.getMessage(), Alert.AlertType.ERROR));
            }

            @Override
            public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
                String responseBody = response.body().string();
                if (response.code() != 200) {
                    Platform.runLater(() -> UtilityClass.showAlert("Error", responseBody, Alert.AlertType.ERROR));
                } else {
                    Type listOfSheetsType = new TypeToken<List<Coordinate>>() {
                    }.getType();
                    List<Coordinate> cells = GSON_INSTANCE.fromJson(responseBody, listOfSheetsType);
                    Coordinate topLeftCoordinate = cells.get(0);
                    Coordinate bottomRightCoordinate = cells.get(1);
                    Platform.runLater(() -> {
                        commandsController.showSecondSortPopup(topLeftCoordinate, bottomRightCoordinate);
                        stage.close();
                    });
                }
            }
        });
    }

    public void handleCellClick(Label cellLabel, int row, int col, ReadonlySheet sheet) {
        commandsController.internalhandleCellClick(cellLabel, row, col);
        ReadonlySheet currentSheet = sheet;
        String lastUpdater = logic.getOwnerName();
        try {
            ReadonlyCell currentCell = currentSheet.getCell(row + 1, col + 1);
            String original_Value = "";
            int cellVersion = 1;
            if (currentCell != null) {
                original_Value = currentCell.getOriginalValue();
                cellVersion = currentCell.getVersion();
                lastUpdater = currentCell.getLastUpdater();
            }
            String effective_Value = cellLabel.getText();
            String cellIdInExcelFormat = Utilty.toExcelFormat(CoordinateFactory.createCoordinate(row + 1, col + 1));
            upperSectionController.UpdateSectionData(original_Value, effective_Value, cellVersion, cellIdInExcelFormat, lastUpdater);
            if (currentCell != null) {
                sheetDisplayerController.markDependsAndInfluencingOnCells(currentCell.getDependsOn(), currentCell.getInfluencingOn());
            } else {
                sheetDisplayerController.clearDependsAndInfluencingOnCells();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public ObservableList<Integer> getAllSheetsVersions() {
        List<ReadonlySheet> readonlySheets = logic.getDifferentSheetVersionsForDisplay();
        ObservableList<Integer> versions = FXCollections.observableArrayList();
        for (ReadonlySheet sheet : readonlySheets) {
            versions.add(sheet.getVersion());
        }
        return versions;

    }

    public void applyColumnChanges(int column, String alignment, double width) {
        sheetDisplayerController.internalApplyColumnChanges(column, alignment, width);
    }

    public void applyRowChanges(int row, double height) {
        sheetDisplayerController.internalApplyRowChanges(row, height);
    }

    public void displaySheet(int version) throws Exception {
        ReadonlySheet displayedSheet = logic.getSheetByVersion(version);
        int rows = logic.getRows();
        int columns = logic.getColumns();
        int columnWidth = logic.getWidth();
        int height = logic.getHeight();
        sheetDisplayerController.setSheetData(displayedSheet, rows, columns, columnWidth, height, false, null);
        ObservableList<String> ranges = FXCollections.observableArrayList();
        ranges.addAll(displayedSheet.getExisitingRanges().keySet());
        rangesController.updateRanges(ranges);
        this.viewedSheet = displayedSheet;
    }

    public void rangeSelectionChanged(String selectedRange) {
        if (!selectedRange.isEmpty()) {
            Set<Coordinate> rangeCoordinates = logic.getCurrentSheet().getExisitingRanges().get(selectedRange);
            sheetDisplayerController.markRange(rangeCoordinates);
        } else {  //empty range selected
            sheetDisplayerController.clearRangeMark();
        }
    }

    public void displayFilteredSortedOrDynamicAnalysisSheet(ReadonlySheet filteredOrSortedOrDynamicSheet, boolean keepStyle, String dynamicAnalysisCellInExcelFormat) throws Exception {
        sheetDisplayerController.setSheetData(filteredOrSortedOrDynamicSheet, logic.getRows(), logic.getColumns(), logic.getWidth(), logic.getHeight(), keepStyle, dynamicAnalysisCellInExcelFormat);
        ObservableList<String> ranges = FXCollections.observableArrayList();
        ranges.addAll(filteredOrSortedOrDynamicSheet.getExisitingRanges().keySet());
        rangesController.updateRanges(ranges);
        this.viewedSheet = filteredOrSortedOrDynamicSheet;
    }

    public void sendRequestToCheckFirstFilterPopupCorrectness(String topLeft, String buttomRight, Stage stage) {
        RequestBody body = new FormBody.Builder()
                .add("topleft", topLeft)
                .add("buttomRight", buttomRight)
                .add("logicToFilter", GSON_INSTANCE.toJson(logic, Logic.class))
                .build();
        Request request = new Request.Builder()
                .url(FIRST_FILTER_POPUP_CHECK_URL)
                .post(body)
                .build();

        HttpClientUtil.runAsync(request, new Callback() {

            @Override
            public void onFailure(@NotNull Call call, @NotNull IOException e) {
                Platform.runLater(() -> UtilityClass.showAlert("Error", e.getMessage(), Alert.AlertType.ERROR));
            }

            @Override
            public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
                String responseBody = response.body().string();
                if (response.code() != 200) {
                    Platform.runLater(() -> UtilityClass.showAlert("Error", responseBody, Alert.AlertType.ERROR));
                } else {
                    Type listOfSheetsType = new TypeToken<List<Coordinate>>() {
                    }.getType();
                    List<Coordinate> cells = GSON_INSTANCE.fromJson(responseBody, listOfSheetsType);
                    Coordinate topLeftCoordinate = cells.get(0);
                    Coordinate bottomRightCoordinate = cells.get(1);
                    Platform.runLater(() -> {
                        commandsController.showSecondFilterPopup(topLeftCoordinate, bottomRightCoordinate);
                        stage.close();
                    });
                }
            }
        });
    }

    public void sendRequestToFilterSheet(List<String> selectedUniqueValues, String SelectedColumn, Coordinate topLeft, Coordinate bottomRight) {
        Type listOfStringsType = new TypeToken<List<String>>() {
        }.getType();
        HttpUrl url;
        RequestBody body;
        Logic logicToSort;
        if (viewedSheet == null) {
            body = new FormBody.Builder()
                    .add("topleft", GSON_INSTANCE.toJson(topLeft, Coordinate.class))
                    .add("buttomRight", GSON_INSTANCE.toJson(bottomRight, Coordinate.class))
                    .add("logicToFilter", GSON_INSTANCE.toJson(logic, Logic.class))
                    .add("selectedUniqueValues", GSON_INSTANCE.toJson(selectedUniqueValues, listOfStringsType))
                    .add("selectedColumn", SelectedColumn)
                    .build();
            url = HttpUrl.parse(FILTER_POPUP_URL).newBuilder()
                    .addQueryParameter("filterBySheet", "false")
                    .build();
        } else {
            body = new FormBody.Builder()
                    .add("topleft", GSON_INSTANCE.toJson(topLeft, Coordinate.class))
                    .add("buttomRight", GSON_INSTANCE.toJson(bottomRight, Coordinate.class))
                    .add("logicToFilter", GSON_INSTANCE.toJson(logic, Logic.class))
                    .add("selectedUniqueValues", GSON_INSTANCE.toJson(selectedUniqueValues, listOfStringsType))
                    .add("selectedColumn", SelectedColumn)
                    .add("viewedSheet", GSON_INSTANCE.toJson(viewedSheet, ReadonlySheet.class))
                    .build();
            url = HttpUrl.parse(FILTER_POPUP_URL).newBuilder()
                    .addQueryParameter("filterBySheet", "true")
                    .build();
        }

        Request request = new Request.Builder()
                .url(url)
                .post(body)
                .build();

        HttpClientUtil.runAsync(request, new Callback() {

            @Override
            public void onFailure(@NotNull Call call, @NotNull IOException e) {
                Platform.runLater(() -> UtilityClass.showAlert("Error", e.getMessage(), Alert.AlertType.ERROR));
            }

            @Override
            public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
                String responseBody = response.body().string();
                if (response.code() != 200) {
                    Platform.runLater(() -> UtilityClass.showAlert("Error", responseBody, Alert.AlertType.ERROR));
                } else {
                    ReadonlySheet filteredSheet = GSON_INSTANCE.fromJson(responseBody, ReadonlySheet.class);
                    int rows = logic.getRows();
                    int columns = logic.getColumns();
                    int columnWidth = logic.getWidth();
                    int height = logic.getHeight();
                    ((Sheet) (filteredSheet)).setLogic(logic);
                    Platform.runLater(() -> {
                        try {
                            //updateAnalysisSliderListener();
                            displayFilteredSortedOrDynamicAnalysisSheet(filteredSheet, false,null);
                        } catch (Exception e) {
                            throw new RuntimeException(e);
                        }
                    });
                }
            }
        });
    }

    public List<String> updateListViewForColumn(String selectedColumn, Coordinate topLeft, Coordinate bottomRight) {
        int column = Utilty.columnLettersToNumber(selectedColumn);
        List<String> uniqueValues = null;
        try {
            if (viewedSheet == null) {
                uniqueValues = logic.getUniqueValuesInColumnArea(column, topLeft, bottomRight, logic.getCurrentSheet());
            } else {
                uniqueValues = logic.getUniqueValuesInColumnArea(column, topLeft, bottomRight, viewedSheet);
            }
        } catch (CoordinateOutOfRangeException e) {
            e.printStackTrace();
        }
        return uniqueValues;
    }

    public void sendRequestToSortSheetByColumns(List<String> selectedColumns, Coordinate topLeft, Coordinate bottomRight) {
        Type listOfStringsType = new TypeToken<List<String>>() {
        }.getType();
        HttpUrl url;
        RequestBody body;
        Logic logicToSort;
        if (viewedSheet == null) {
            body = new FormBody.Builder()
                    .add("topleft", GSON_INSTANCE.toJson(topLeft, Coordinate.class))
                    .add("buttomRight", GSON_INSTANCE.toJson(bottomRight, Coordinate.class))
                    .add("logicToSort", GSON_INSTANCE.toJson(logic, Logic.class))
                    .add("selectedColumns", GSON_INSTANCE.toJson(selectedColumns, listOfStringsType))
                    .build();
            url = HttpUrl.parse(SORT_POPUP_URL).newBuilder()
                    .addQueryParameter("sortBySheet", "false")
                    .build();
        } else {
            body = new FormBody.Builder()
                    .add("topleft", GSON_INSTANCE.toJson(topLeft, Coordinate.class))
                    .add("buttomRight", GSON_INSTANCE.toJson(bottomRight, Coordinate.class))
                    .add("logicToSort", GSON_INSTANCE.toJson(logic, Logic.class))
                    .add("selectedColumns", GSON_INSTANCE.toJson(selectedColumns, listOfStringsType))
                    .add("viewedSheet", GSON_INSTANCE.toJson(viewedSheet, ReadonlySheet.class))
                    .build();
            url = HttpUrl.parse(SORT_POPUP_URL).newBuilder()
                    .addQueryParameter("sortBySheet", "true")
                    .build();
        }

        Request request = new Request.Builder()
                .url(url)
                .post(body)
                .build();

        HttpClientUtil.runAsync(request, new Callback() {

            @Override
            public void onFailure(@NotNull Call call, @NotNull IOException e) {
                Platform.runLater(() -> UtilityClass.showAlert("Error", e.getMessage(), Alert.AlertType.ERROR));
            }

            @Override
            public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
                String responseBody = response.body().string();
                if (response.code() != 200) {
                    Platform.runLater(() -> UtilityClass.showAlert("Error", responseBody, Alert.AlertType.ERROR));
                } else {
                    ReadonlySheet sortedSheet = GSON_INSTANCE.fromJson(responseBody, ReadonlySheet.class);
                    int rows = logic.getRows();
                    int columns = logic.getColumns();
                    int columnWidth = logic.getWidth();
                    int height = logic.getHeight();
                    ((Sheet) (sortedSheet)).setLogic(logic);
                    Platform.runLater(() -> {
                        try {
                            //updateAnalysisSliderListener();
                            displayFilteredSortedOrDynamicAnalysisSheet(sortedSheet, false,null);
                        } catch (Exception e) {
                            throw new RuntimeException(e);
                        }
                    });
                }
            }
        });
    }

    public void setAnaLysisSlider(int minValue, int maxValue, int stepSize) {
        analysisSlider.valueProperty().removeListener(sliderListener);
        analysisSlider.setMin(minValue);
        analysisSlider.setMax(maxValue);
        analysisSlider.setBlockIncrement(stepSize);
        analysisSlider.setMajorTickUnit(stepSize);
        analysisSlider.setMinorTickCount(0);
        currentStepSize = stepSize;
        analysisSlider.valueProperty().addListener(sliderListener);
    }

    public void setSelectedCell(String selectedCell) {
        if(selectedCell== null)
        {
            selectedCellForDynamicAnalysis = null;
        }
        else {
            Coordinate selectedCellCoordinate = null;
            if (selectedCellForDynamicAnalysis != null) {
                try {
                    selectedCellCoordinate = Utilty.fromExcelFormat(selectedCellForDynamicAnalysis);
                    sheetDisplayerController.updateDynamicAnalysisCellMark(selectedCellCoordinate, false);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            try {
                selectedCellForDynamicAnalysis = selectedCell;
                selectedCellCoordinate = Utilty.fromExcelFormat(selectedCellForDynamicAnalysis);
                sheetDisplayerController.updateDynamicAnalysisCellMark(selectedCellCoordinate, true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        if (selectedCellForDynamicAnalysis != null) {
            analysisSlider.setDisable(false);
        } else {
            analysisSlider.setDisable(true);
        }
    }

    private void sendRequestToUpdateDynamicAnalysisCellValue(String selectedCell, int sliderValue) {
        if(viewedSheet == null)
        {
            return;
        }
        RequestBody body = new FormBody.Builder()
                .add("selectedCell", selectedCell)
                .add("sliderValue", String.valueOf(sliderValue))
                .add("viewedSheet", GSON_INSTANCE.toJson(viewedSheet, ReadonlySheet.class))
                .add("logic", GSON_INSTANCE.toJson(logic, Logic.class))
                .build();
        Request request = new Request.Builder()
                .url(DYNAMIC_ANALYSIS_URL)
                .post(body)
                .build();

        HttpClientUtil.runAsync(request, new Callback() {

            @Override
            public void onFailure(@NotNull Call call, @NotNull IOException e) {
                Platform.runLater(() -> UtilityClass.showAlert("Error", e.getMessage(), Alert.AlertType.ERROR));
            }

            @Override
            public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
                String responseBody = response.body().string();
                if (response.code() != 200) {
                    Platform.runLater(() -> UtilityClass.showAlert("Error", responseBody, Alert.AlertType.ERROR));
                } else {
                    ReadonlySheet updatedSheet = GSON_INSTANCE.fromJson(responseBody, ReadonlySheet.class);
                    ((Sheet) (updatedSheet)).setLogic(logic);
                    Platform.runLater(() -> {
                        try {
                            displayFilteredSortedOrDynamicAnalysisSheet(updatedSheet, true, selectedCellForDynamicAnalysis);
                        } catch (Exception e) {
                            throw new RuntimeException(e);
                        }
                    });
                }
            }
        });
    }

    public void openDynamicAnalysis() {
        CellSelectionPopup cellSelectionPopup = new CellSelectionPopup(logic, viewedSheet);
        cellSelectionPopup.openCellSelectionPopup();
        String selectedCellInExcelFormat = cellSelectionPopup.getSelectedCell();
        if (selectedCellInExcelFormat != null) {
            updateDynamicAnalysisWindow(selectedCellInExcelFormat, cellSelectionPopup.getMinValue(), cellSelectionPopup.getMaxValue(), cellSelectionPopup.getStepSize());
        }
    }

    private void updateDynamicAnalysisWindow(String selectedCellInExcelFormat, int min, int max, int stepSize) {
        try {
            setLogic(logic);
            setAnaLysisSlider(min, max, stepSize);
            displayFilteredSortedOrDynamicAnalysisSheet(viewedSheet, true, selectedCellInExcelFormat);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
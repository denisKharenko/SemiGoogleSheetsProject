package clientpackage.gui.mainController;

import Logic.Cell.api.ReadonlyCell;
import Logic.Coordinate.Coordinate;
import Logic.Coordinate.CoordinateFactory;
import Logic.Exceptions.CoordinateOutOfRangeException;
import Logic.Utilty.Utilty;
import Logic.api.Logic;

import Logic.permission.Permission;
import Logic.sheet.api.ReadonlySheet;
import Logic.sheet.api.Sheet;
import clientpackage.dashBoard.DashBoardController;
import clientpackage.gui.SheetController.SheetDisplayerController;
import clientpackage.gui.commandsController.CommandsController;
import clientpackage.gui.dynamicAnalysis.CellSelectionPopup;
import clientpackage.gui.rangesController.RangesController;
import clientpackage.gui.upperSectionController.UpperSectionController;
import clientpackage.util.http.HttpClientUtil;
import clientpackage.util.http.UtilityClass;
import com.google.gson.reflect.TypeToken;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import okhttp3.*;
import org.jetbrains.annotations.NotNull;

import java.io.IOException;
import java.lang.reflect.Type;
import java.net.URL;
import java.util.*;

import static clientpackage.util.ClientConstants.*;
import static serializerForShticell.Util.Constants.GSON_INSTANCE;

public class MainController {
    private SheetDisplayerController sheetDisplayerController;
    private Logic logic;
    private UpperSectionController upperSectionController;
    private RangesController rangesController;
    private CommandsController commandsController;
    private Stage primaryStage;
    private int currentSheetVersion = -1;
    private int displayedSheetVersion = -1;
    private boolean displayingCurrentSheet;
    private String userName;
    private int currentRangesSize = -1;
    private DashBoardController dashBoardController;
    private boolean autoSheetUpdates;
    private boolean firstDisplay = true;
    private ReadonlySheet viewedSheet;

    @FXML
    private BorderPane borderPane;
    @FXML
    private VBox leftSectionVbox;
    @FXML
    private Button backToDashBoardButton;


    @FXML
    public void initialize() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource(SHEET_DISPLAYER_FXML_RESOURCE_LOCATION));
            ScrollPane sheetDisplayer = loader.load();
            sheetDisplayerController = loader.getController();
            sheetDisplayerController.setMainController(this);
            loader = new FXMLLoader(getClass().getResource(UPPER_SECTION_FXML_RESOURCE_LOCATION));
            GridPane upperSection = loader.load();
            upperSectionController = loader.getController();
            borderPane.setCenter(sheetDisplayer);
            upperSectionController.setMainController(this);
            borderPane.setTop(upperSection);
            loader = new FXMLLoader(getClass().getResource(COMMANDS_CONTROLLER_FXML_RESOURCE_LOCATION));
            ScrollPane commands = loader.load();
            commandsController = loader.getController();
            commandsController.setMainController(this);
            leftSectionVbox.getChildren().add(commands);
            loader = new FXMLLoader(getClass().getResource(RANGES_CONTROLLER_FXML_RESOURCE_LOCATION));
            ScrollPane ranges = loader.load();
            rangesController = loader.getController();
            rangesController.setMainController(this);
            leftSectionVbox.getChildren().add(ranges);
            borderPane.setLeft(leftSectionVbox);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void setFirstDisplay(boolean firstDisplay) {
        this.firstDisplay = firstDisplay;
    }
    public void setLogic(Logic currentLogic)
    {
        this.logic = currentLogic;

    }
    public void setPrimaryStage(Stage primaryStage) {
        this.primaryStage = primaryStage;
    }
    public void setUserNameLabel(String userName) {
        upperSectionController.setUserNameLabel(userName);
        this.userName = userName;
    }
    @FXML
    void backToDashBoardActionListener(ActionEvent event) {
        switchToDashboardView();
    }
    public void setDashBoardController(DashBoardController dashBoardController)
    {
        this.dashBoardController = dashBoardController;
    }
    private void switchToDashboardView() {
        if (dashBoardController == null) {
            //primaryStage.setMinHeight(600);
            //primaryStage.setMinWidth(600);
            primaryStage.setTitle("Shticell Dash Board");

            URL dashboardPage = getClass().getResource(DASH_BOARD_FXML_RESOURCE_LOCATION);
            try {
                FXMLLoader fxmlLoader = new FXMLLoader();
                fxmlLoader.setLocation(dashboardPage);
                Parent root = fxmlLoader.load();
                dashBoardController = fxmlLoader.getController();
                dashBoardController.setPrimaryStage(primaryStage);
                dashBoardController.setUserNameLabel(userName);

                Scene scene = new Scene(root, 700, 600);
                dashBoardController.setScene(scene); // Store the scene in the controller
                primaryStage.setScene(scene);
                primaryStage.show();
            } catch (IOException e) {
                e.printStackTrace();
            }
        } else {
            primaryStage.setScene(dashBoardController.getScene());
            primaryStage.show();
        }
        dashBoardController.setMainController(null);
    }

    public void handleCellClick(Label cellLabel, int row, int col) {
        commandsController.internalhandleCellClick(cellLabel, row, col);
        ReadonlySheet currentSheet;
        if(viewedSheet != null) {
            currentSheet = viewedSheet;
        }
        else {
            if(displayedSheetVersion != -1) {
                currentSheet = logic.getSheetByVersion(displayedSheetVersion);
            }
            else
            {
                currentSheet = logic.getCurrentSheet();
            }
        }
        try {
            ReadonlyCell currentCell = currentSheet.getCell(row + 1, col + 1);
            String original_Value = "";
            Set<ReadonlyCell> influencedCellsThatUseRanges = new HashSet<>();
            int cellVersion = 1;
            String lastUpdater = logic.getOwnerName();
            if (currentCell != null) {
                original_Value = currentCell.getOriginalValue();
                cellVersion = currentCell.getVersion();
                Set<String> rangesThatTheCellInfluences = currentCell.getInfluencingOnRanges();
                for (String range : rangesThatTheCellInfluences) {
                    influencedCellsThatUseRanges.addAll(currentSheet.getCellsThatAreUsingThisRange(range));
                }
                lastUpdater = currentCell.getLastUpdater();
            }
            String effective_Value = cellLabel.getText();
            ObservableList<Integer> versionsList = getAllSheetsVersions();
            String cellIdInExcelFormat = Utilty.toExcelFormat(CoordinateFactory.createCoordinate(row + 1, col + 1));
            upperSectionController.UpdateSectionCellData(original_Value, effective_Value, cellVersion, cellIdInExcelFormat, lastUpdater);
            if (currentCell != null) {
                sheetDisplayerController.markDependsAndInfluencingOnCells(currentCell.getDependsOn(), currentCell.getInfluencingOn());
            } else {
                sheetDisplayerController.clearDependsAndInfluencingOnCells();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public ObservableList<Integer> getAllSheetsVersions() {
        List<ReadonlySheet> readonlySheets = logic.getDifferentSheetVersionsForDisplay();
        ObservableList<Integer> versions = FXCollections.observableArrayList();
        for (ReadonlySheet sheet : readonlySheets) {
            versions.add(sheet.getVersion());
        }
        return versions;

    }

    public void applyColumnChanges(int column, String alignment, double width) {
        sheetDisplayerController.internalApplyColumnChanges(column, alignment, width);
    }

    public void applyRowChanges(int row, double height) {
        sheetDisplayerController.internalApplyRowChanges(row, height);
    }

    public void sendRequestToCheckFirstSortPopupCorrectness(String topLeft, String buttomRight, Stage stage) {
        RequestBody body = new FormBody.Builder()
                .add("topleft", topLeft)
                .add("buttomRight", buttomRight)
                .add("logicToSort", GSON_INSTANCE.toJson(logic, Logic.class))
                .build();
        Request request = new Request.Builder()
                .url(FIRST_SORT_POPUP_CHECK_URL)
                .post(body)
                .build();

        HttpClientUtil.runAsync(request, new Callback() {

            @Override
            public void onFailure(@NotNull Call call, @NotNull IOException e) {
                Platform.runLater(() -> UtilityClass.showAlert("Error", e.getMessage(), Alert.AlertType.ERROR));
            }

            @Override
            public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
                String responseBody = response.body().string();
                if (response.code() != 200) {
                    Platform.runLater(() -> UtilityClass.showAlert("Error", responseBody, Alert.AlertType.ERROR));
                } else {
                    Type listOfSheetsType = new TypeToken<List<Coordinate>>() { }.getType();
                    List<Coordinate> cells = GSON_INSTANCE.fromJson(responseBody, listOfSheetsType);
                    Coordinate topLeftCoordinate = cells.get(0);
                    Coordinate bottomRightCoordinate = cells.get(1);
                    Platform.runLater(() -> {
                        commandsController.showSecondSortPopup(topLeftCoordinate, bottomRightCoordinate);
                        stage.close();
                    });
                }
            }
        });
    }
    public void sendRequestToCheckFirstFilterPopupCorrectness(String topLeft, String buttomRight, Stage stage) {
        RequestBody body = new FormBody.Builder()
                .add("topleft", topLeft)
                .add("buttomRight", buttomRight)
                .add("logicToFilter", GSON_INSTANCE.toJson(logic, Logic.class))
                .build();
        Request request = new Request.Builder()
                .url(FIRST_FILTER_POPUP_CHECK_URL)
                .post(body)
                .build();

        HttpClientUtil.runAsync(request, new Callback() {

            @Override
            public void onFailure(@NotNull Call call, @NotNull IOException e) {
                Platform.runLater(() -> UtilityClass.showAlert("Error", e.getMessage(), Alert.AlertType.ERROR));
            }

            @Override
            public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
                String responseBody = response.body().string();
                if (response.code() != 200) {
                    Platform.runLater(() -> UtilityClass.showAlert("Error", responseBody, Alert.AlertType.ERROR));
                } else {
                    Type listOfSheetsType = new TypeToken<List<Coordinate>>() { }.getType();
                    List<Coordinate> cells = GSON_INSTANCE.fromJson(responseBody, listOfSheetsType);
                    Coordinate topLeftCoordinate = cells.get(0);
                    Coordinate bottomRightCoordinate = cells.get(1);
                    Platform.runLater(() -> {
                        commandsController.showSecondFilterPopup(topLeftCoordinate, bottomRightCoordinate);
                        stage.close();
                    });
                }
            }
        });
    }
    public void sendRequestToUpdateCellValue(String rowAndColumn, String value) {
        Coordinate coordinate = Utilty.fromExcelFormat(rowAndColumn);
        ReadonlySheet currentSheet = logic.getCurrentSheet();
        int currentSheetVersion = currentSheet.getVersion();
        String usersSheetVersion;
        if(viewedSheet != null) {
            usersSheetVersion = String.valueOf(viewedSheet.getVersion());
        }
        else {
            usersSheetVersion = String.valueOf(currentSheetVersion);
        }
        RequestBody body = new FormBody.Builder()
                .add("usersSheetVersion", usersSheetVersion)
                .add("rowAndColumn", rowAndColumn)
                .add("value", value)
                .add("sheetName", logic.getSheetName())
                .add("sheetOwner", logic.getOwnerName())
                .build();

        Request request = new Request.Builder()
                .url(UPDATE_CELL_URL)
                .post(body)
                .build();

        HttpClientUtil.runAsync(request, new Callback() {

            @Override
            public void onFailure(@NotNull Call call, @NotNull IOException e) {
                Platform.runLater(() -> UtilityClass.showAlert("Error", e.getMessage(), Alert.AlertType.ERROR));
            }

            @Override
            public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
                String responseBody = response.body().string();
                if (response.code() != 200) {
                    Platform.runLater(() -> UtilityClass.showAlert("Error", responseBody, Alert.AlertType.ERROR));
                } else {
                    autoSheetUpdates = true;
                    viewedSheet = null;
                    Platform.runLater(() -> {
                        UtilityClass.showAlert("Success", responseBody , Alert.AlertType.INFORMATION);
                    });
                }
            }
        });
    }
    public void setAutoUpdates()
    {
        if(viewedSheet == null && userName.equalsIgnoreCase(logic.getCurrentSheet().getUpdater()))
        {
            autoSheetUpdates = true;
        }
        else
        {
            autoSheetUpdates = false;
        }
    }
    public void updateDisplayedSheet() throws Exception {
        if (firstDisplay && userName != null && logic != null) {
            updateRanges();
            ReadonlySheet displayedSheet = logic.getCurrentSheet();
            int rows = logic.getRows();
            int columns = logic.getColumns();
            int columnWidth = logic.getWidth();
            int height = logic.getHeight();
            sheetDisplayerController.setSheetData(displayedSheet, rows, columns, columnWidth, height, false);
            upperSectionController.setDisplayedVersionLabelToCurrentOne(getAllSheetsVersions());
            viewedSheet = null;
            displayedSheetVersion = logic.getCurrentSheet().getVersion();
            firstDisplay = false;
            currentRangesSize = logic.getCurrentSheet().getExisitingRanges().size();
            upperSectionController.updateVersionsComboBox(getAllSheetsVersions());
        }
        else if (userName != null && logic != null) {
            updateRanges();
            setAutoUpdates();
            if ((currentSheetVersion != logic.getCurrentSheet().getVersion() && userName.equalsIgnoreCase(logic.getCurrentSheet().getUpdater()))|| logic.getCurrentSheet().getExisitingRanges().size() != currentRangesSize) {
                //if the sheet was updated by this user but the change isn't displayed yet
                ReadonlySheet displayedSheet = logic.getCurrentSheet();
                int rows = logic.getRows();
                int columns = logic.getColumns();
                int columnWidth = logic.getWidth();
                int height = logic.getHeight();
                if (autoSheetUpdates) {
                    viewedSheet = null;
                    if (logic.getCurrentSheet().getVersion() == 1) {//at first there is no style to keep so reload with default style
                        sheetDisplayerController.setSheetData(displayedSheet, rows, columns, columnWidth, height, false);
                    } else {
                        sheetDisplayerController.setSheetData(displayedSheet, rows, columns, columnWidth, height, true);
                    }
                    displayedSheetVersion = logic.getCurrentSheet().getVersion();
                    upperSectionController.setDisplayedVersionLabelToCurrentOne(getAllSheetsVersions());
                }
                currentRangesSize = logic.getCurrentSheet().getExisitingRanges().size();
            }
            upperSectionController.updateVersionsComboBox(getAllSheetsVersions());
        }
            currentSheetVersion = logic.getCurrentSheet().getVersion();
        if (displayedSheetVersion != currentSheetVersion) {
            if(userName != null && logic != null) {
                if(!(userName.equalsIgnoreCase(logic.getCurrentSheet().getUpdater()))) {
                    upperSectionController.updateVersionsComboBoxAndLabel(false);
                }
            }
            displayingCurrentSheet = false;
        } else {
            upperSectionController.updateVersionsComboBoxAndLabel(true);
            displayingCurrentSheet = true;
        }
        displaySheetAccordingToPermissionsAndVersion();
    }
    private void displaySheetAccordingToPermissionsAndVersion()
    {
        if(displayingCurrentSheet && (logic.getUserPermission(userName).equalsIgnoreCase(Permission.OWNER.toString())|| logic.getUserPermission(userName).equalsIgnoreCase(Permission.WRITER.toString())))
        {
            upperSectionController.disableSection(false);
            rangesController.disableSection(false);
        }
        else//reader permission (or none)
        {
            upperSectionController.disableSection(true);
            rangesController.disableSection(true);
        }
        upperSectionController.updatePermissionsLabel(logic.getUserPermission(userName).toString());
    }

    public void openVersionDisplayer(int version) throws Exception {
            autoSheetUpdates = false;
            ReadonlySheet displayedSheet = logic.getSheetByVersion(version);
            int rows = logic.getRows();
            int columns = logic.getColumns();
            int columnWidth = logic.getWidth();
            int height = logic.getHeight();
            sheetDisplayerController.setSheetData(displayedSheet, rows, columns, columnWidth, height, true);
            viewedSheet = displayedSheet;
            displayedSheetVersion = version;
    }


    public void sendRequestToCreateRange(String rangeName, String topLeftCell, String buttomRight) {
        Coordinate topLeft = Utilty.fromExcelFormat(topLeftCell);
        Coordinate buttomRightCoordinate = Utilty.fromExcelFormat(buttomRight);
        String usersSheetVersion;
        if(viewedSheet != null) {
            usersSheetVersion = String.valueOf(viewedSheet.getVersion());
        }
        else {
            usersSheetVersion = String.valueOf(logic.getCurrentSheet().getVersion());
        }
        RequestBody body = new FormBody.Builder()
                .add("rangeName", rangeName)
                .add("topLeft", String.valueOf(topLeft.getRow()))
                .add("topLeftColumn", String.valueOf(topLeft.getColumn()))
                .add("buttomRightRow", String.valueOf(buttomRightCoordinate.getRow()))
                .add("buttomRightColumn", String.valueOf(buttomRightCoordinate.getColumn()))
                .add("sheetName", logic.getSheetName())
                .add("ownerName", logic.getOwnerName())
                .add("usersSheetVersion", usersSheetVersion)
                .add("createRange", "true")
                .build();

        Request request = new Request.Builder()
                .url(UPDATE_RANGES_URL)
                .post(body)
                .build();

        HttpClientUtil.runAsync(request, new Callback() {

            @Override
            public void onFailure(@NotNull Call call, @NotNull IOException e) {
                Platform.runLater(() -> UtilityClass.showAlert("Error", e.getMessage(), Alert.AlertType.ERROR));
            }

            @Override
            public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
                String responseBody = response.body().string();
                if (response.code() != 200) {
                    Platform.runLater(() -> UtilityClass.showAlert("Error", responseBody, Alert.AlertType.ERROR));
                } else {
                    Platform.runLater(() -> {
                        autoSheetUpdates = true;
                        viewedSheet = null;
                        UtilityClass.showAlert("Success", responseBody , Alert.AlertType.INFORMATION);
                    });
                }
            }
        });
    }
    public void updateRanges() {
        // Compare the two maps
        Map<String, Set<Coordinate>> newRanges;
        if(viewedSheet != null) {
            newRanges = viewedSheet.getExisitingRanges();
        }
        else {
            newRanges = logic.getCurrentSheet().getExisitingRanges();
        }
        ObservableList<String> ranges = FXCollections.observableArrayList();
        ranges.addAll(newRanges.keySet());
        ranges.add("");//add an empty range so can be selected to remove range mark
        rangesController.updateRanges(ranges);
    }

    public void rangeSelectionChanged(String selectedRange) {
        ReadonlySheet sheetOfRange;
        if(viewedSheet != null) {
            sheetOfRange = viewedSheet;
        }
        else {
            sheetOfRange = logic.getCurrentSheet();
        }
        if (!selectedRange.isEmpty()) {
            Set<Coordinate> rangeCoordinates = sheetOfRange.getExisitingRanges().get(selectedRange);
            sheetDisplayerController.markRange(rangeCoordinates);
        } else {  //empty range selected
            sheetDisplayerController.clearRangeMark();
        }
    }

    public void sendRequestToRemoveRange(String selectedRange) {
        String usersSheetVersion;
        if(viewedSheet != null) {
            usersSheetVersion = String.valueOf(viewedSheet.getVersion());
        }
        else {
            usersSheetVersion = String.valueOf(logic.getCurrentSheet().getVersion());
        }
        RequestBody body = new FormBody.Builder()
                .add("rangeName", selectedRange)
                .add("sheetName", logic.getSheetName())
                .add("ownerName", logic.getOwnerName())
                .add("usersSheetVersion", usersSheetVersion)
                .add("createRange", "false")
                .build();

        Request request = new Request.Builder()
                .url(UPDATE_RANGES_URL)
                .post(body)
                .build();

        HttpClientUtil.runAsync(request, new Callback() {

            @Override
            public void onFailure(@NotNull Call call, @NotNull IOException e) {
                Platform.runLater(() -> UtilityClass.showAlert("Error", e.getMessage(), Alert.AlertType.ERROR));
            }

            @Override
            public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
                String responseBody = response.body().string();
                if (response.code() != 200) {
                    Platform.runLater(() -> UtilityClass.showAlert("Error", responseBody, Alert.AlertType.ERROR));
                } else {
                    Platform.runLater(() -> {
                        autoSheetUpdates = true;
                        viewedSheet = null;
                        UtilityClass.showAlert("Success", responseBody , Alert.AlertType.INFORMATION);
                    });
                }
            }
        });
    }

    public List<String> updateListViewForColumn(String selectedColumn, Coordinate topLeft, Coordinate bottomRight) {
        int column = Utilty.columnLettersToNumber(selectedColumn);
        List<String> uniqueValues = null;
        try {
            uniqueValues = logic.getUniqueValuesInColumnArea(column, topLeft, bottomRight, logic.getCurrentSheet());
        } catch (CoordinateOutOfRangeException e) {
            e.printStackTrace();
        }
        return uniqueValues;
    }

    public void sendRequestToFilterSheet(List<String> selectedUniqueValues, String SelectedColumn, Coordinate topLeft, Coordinate bottomRight) {
        Type listOfStringsType = new TypeToken<List<String>>() { }.getType();
        HttpUrl url;
        RequestBody body;
        Logic logicToSort;
        if(viewedSheet == null) {
            body = new FormBody.Builder()
                    .add("topleft", GSON_INSTANCE.toJson(topLeft, Coordinate.class))
                    .add("buttomRight", GSON_INSTANCE.toJson(bottomRight, Coordinate.class))
                    .add("logicToFilter", GSON_INSTANCE.toJson(logic, Logic.class))
                    .add("selectedUniqueValues", GSON_INSTANCE.toJson(selectedUniqueValues, listOfStringsType))
                    .add("selectedColumn", SelectedColumn)
                    .build();
            url = HttpUrl.parse(FILTER_POPUP_URL).newBuilder()
                    .addQueryParameter("filterBySheet", "false")
                    .build();
        }
        else {
            body = new FormBody.Builder()
                    .add("topleft", GSON_INSTANCE.toJson(topLeft, Coordinate.class))
                    .add("buttomRight", GSON_INSTANCE.toJson(bottomRight, Coordinate.class))
                    .add("logicToFilter", GSON_INSTANCE.toJson(logic, Logic.class))
                    .add("selectedUniqueValues", GSON_INSTANCE.toJson(selectedUniqueValues,listOfStringsType))
                    .add("selectedColumn", SelectedColumn)
                    .add("viewedSheet", GSON_INSTANCE.toJson(viewedSheet, ReadonlySheet.class))
                    .build();
            url = HttpUrl.parse(FILTER_POPUP_URL).newBuilder()
                    .addQueryParameter("filterBySheet", "true")
                    .build();
        }

        Request request = new Request.Builder()
                .url(url)
                .post(body)
                .build();

        HttpClientUtil.runAsync(request, new Callback() {

            @Override
            public void onFailure(@NotNull Call call, @NotNull IOException e) {
                Platform.runLater(() -> UtilityClass.showAlert("Error", e.getMessage(), Alert.AlertType.ERROR));
            }

            @Override
            public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
                String responseBody = response.body().string();
                if (response.code() != 200) {
                    Platform.runLater(() -> UtilityClass.showAlert("Error", responseBody, Alert.AlertType.ERROR));
                } else {
                    ReadonlySheet filteredSheet = GSON_INSTANCE.fromJson(responseBody, ReadonlySheet.class);
                    int rows = logic.getRows();
                    int columns = logic.getColumns();
                    int columnWidth = logic.getWidth();
                    int height = logic.getHeight();
                    ((Sheet) (filteredSheet)).setLogic(logic);
                    Platform.runLater(() -> {
                        displayFilteredOrSortedSheet(filteredSheet, true);
                    });
                }
            }
        });
    }

    public void displayFilteredOrSortedSheet(ReadonlySheet filteredSheet, boolean isFiltered) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("VersionDisplayMainController.fxml"));
            Parent root = loader.load();

            VersionDisplayMainController controller = loader.getController();
            controller.setLogic(logic);
            //controller.updateAnalysisSliderListener();
            controller.displayFilteredSortedOrDynamicAnalysisSheet(filteredSheet,false,null);
            controller.setUserNameLabel(userName);
            Platform.runLater(() -> {

                Stage stage = new Stage();
                if(isFiltered) {
                    stage.setTitle("Filtered Sheet Display");
                }
                else {
                    stage.setTitle("Sorted Sheet Display");
                }
                stage.setScene(new Scene(root));
                stage.show();
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public void sendRequestToSortSheetByColumns(List<String> selectedColumns, Coordinate topLeft, Coordinate bottomRight) {
        Type listOfStringsType = new TypeToken<List<String>>() { }.getType();
        HttpUrl url;
        RequestBody body;
        Logic logicToSort;
        if(viewedSheet == null) {
            body = new FormBody.Builder()
                    .add("topleft", GSON_INSTANCE.toJson(topLeft, Coordinate.class))
                    .add("buttomRight", GSON_INSTANCE.toJson(bottomRight, Coordinate.class))
                    .add("logicToSort", GSON_INSTANCE.toJson(logic, Logic.class))
                    .add("selectedColumns", GSON_INSTANCE.toJson(selectedColumns, listOfStringsType))
                    .build();
            url = HttpUrl.parse(SORT_POPUP_URL).newBuilder()
                    .addQueryParameter("sortBySheet", "false")
                    .build();
        }
        else {
            body = new FormBody.Builder()
                    .add("topleft", GSON_INSTANCE.toJson(topLeft, Coordinate.class))
                    .add("buttomRight", GSON_INSTANCE.toJson(bottomRight, Coordinate.class))
                    .add("logicToSort", GSON_INSTANCE.toJson(logic, Logic.class))
                    .add("selectedColumns", GSON_INSTANCE.toJson(selectedColumns, listOfStringsType))
                    .add("viewedSheet", GSON_INSTANCE.toJson(viewedSheet, ReadonlySheet.class))
                    .build();
            url = HttpUrl.parse(SORT_POPUP_URL).newBuilder()
                    .addQueryParameter("sortBySheet", "true")
                    .build();
        }

        Request request = new Request.Builder()
                .url(url)
                .post(body)
                .build();

        HttpClientUtil.runAsync(request, new Callback() {

            @Override
            public void onFailure(@NotNull Call call, @NotNull IOException e) {
                Platform.runLater(() -> UtilityClass.showAlert("Error", e.getMessage(), Alert.AlertType.ERROR));
            }

            @Override
            public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
                String responseBody = response.body().string();
                if (response.code() != 200) {
                    Platform.runLater(() -> UtilityClass.showAlert("Error", responseBody, Alert.AlertType.ERROR));
                } else {
                    ReadonlySheet sortedSheet = GSON_INSTANCE.fromJson(responseBody, ReadonlySheet.class);
                    int rows = logic.getRows();
                    int columns = logic.getColumns();
                    int columnWidth = logic.getWidth();
                    int height = logic.getHeight();
                    ((Sheet) (sortedSheet)).setLogic(logic);
                    Platform.runLater(() -> {
                        displayFilteredOrSortedSheet(sortedSheet, false);
                    });
                }
            }
        });
    }
    public void openDynamicAnalysis()
    {
        CellSelectionPopup cellSelectionPopup;
        if(viewedSheet != null)
        {
            cellSelectionPopup =  new CellSelectionPopup(logic,viewedSheet);
        }
        else
        {
            cellSelectionPopup = new CellSelectionPopup(logic,logic.getSheetByVersion(displayedSheetVersion));
        }
        cellSelectionPopup.openCellSelectionPopup();
        String selectedCellInExcelFormat = cellSelectionPopup.getSelectedCell();
        if(selectedCellInExcelFormat != null) {
            openDynamicAnalysisWindow(selectedCellInExcelFormat,cellSelectionPopup.getMinValue(),cellSelectionPopup.getMaxValue(),cellSelectionPopup.getStepSize());
        }
    }
    private void openDynamicAnalysisWindow(String selectedCellInExcelFormat, int min, int max, int stepSize)
    {
        ReadonlySheet sheetForDynamicAnalysis;
        if(viewedSheet != null)
        {
            sheetForDynamicAnalysis = viewedSheet;
        }
        else {
            if (displayedSheetVersion == -1) {
                sheetForDynamicAnalysis = logic.getCurrentSheet();
            } else {
                sheetForDynamicAnalysis = logic.getSheetByVersion(displayedSheetVersion);
            }
        }
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("VersionDisplayMainController.fxml"));
            Parent root = loader.load();

            VersionDisplayMainController controller = loader.getController();
            controller.setLogic(logic);
            controller.setUserNameLabel(userName);
            controller.setAnaLysisSlider(min,max,stepSize);
            controller.displayFilteredSortedOrDynamicAnalysisSheet(sheetForDynamicAnalysis,false, selectedCellInExcelFormat);
            Platform.runLater(() -> {

                Stage stage = new Stage();
                stage.setTitle("Dynamic Analysis Display");
                stage.setScene(new Scene(root));
                stage.show();
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
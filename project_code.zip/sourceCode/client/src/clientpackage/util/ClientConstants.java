package clientpackage.util;

import com.google.gson.Gson;

public class ClientConstants {
    // global constants
    public final static String LINE_SEPARATOR = System.getProperty("line.separator");
    public final static String JHON_DOE = "<Anonymous>";
    public final static int REFRESH_RATE = 2000;
    public final static String CHAT_LINE_FORMATTING = "%tH:%tM:%tS | %.10s: %s%n";

    // fxml locations
    public final static String DASH_BOARD_FXML_RESOURCE_LOCATION = "/clientpackage/dashBoard/dashBoardScreen.fxml";
    public final static String LOGIN_PAGE_FXML_RESOURCE_LOCATION = "/clientpackage/login/login.fxml";
    public final static String MAIN_CONTROLLER_FXML_RESOURCE_LOCATION = "/clientpackage/gui/mainController/mainController.fxml";
    public final static String UPPER_SECTION_FXML_RESOURCE_LOCATION = "/clientpackage/gui/upperSectionController/UpperSection.fxml";
    public final static String VERSION_DISPLAY_UPPER_SECTION_FXML_RESOURCE_LOCATION = "/clientpackage/gui/upperSectionController/VersionDisplayUpperSection.fxml";
    public final static String SHEET_DISPLAYER_FXML_RESOURCE_LOCATION = "/clientpackage/gui/SheetController/MidSection.fxml";
    public final static String VERSION_DISPLAY_SHEET_DISPLAYER_FXML_RESOURCE_LOCATION = "/clientpackage/gui/SheetController/VersionDisplayMidSection.fxml";
    public final static String RANGES_CONTROLLER_FXML_RESOURCE_LOCATION = "/clientpackage/gui/rangesController/leftButtomSection.fxml";
    public final static String VERSION_DISPLAY_RANGES_CONTROLLER_FXML_RESOURCE_LOCATION = "/clientpackage/gui/rangesController/VersionDisplayLeftButtomSection.fxml";
    public final static String COMMANDS_CONTROLLER_FXML_RESOURCE_LOCATION = "/clientpackage/gui/commandsController/leftUpperSection.fxml";
    public final static String VERSION_DISPLAY_COMMANDS_CONTROLLER_FXML_RESOURCE_LOCATION = "/clientpackage/gui/commandsController/VersionDisplayLeftUpperSection.fxml";


    // Server resources locations
    public final static String BASE_DOMAIN = "localhost";
    private final static String BASE_URL = "http://" + BASE_DOMAIN + ":8080";
    private final static String CONTEXT_PATH = "/ex3";
    private final static String FULL_SERVER_PATH = BASE_URL + CONTEXT_PATH;

    public final static String LOGIN_PAGE = FULL_SERVER_PATH + "/loginShortResponse";
    public final static String USERS_LIST = FULL_SERVER_PATH + "/userslist";
    public final static String LOGOUT = FULL_SERVER_PATH + "/chat/logout";
    public final static String SEND_CHAT_LINE = FULL_SERVER_PATH + "/pages/chatroom/sendChat";
    public final static String CHAT_LINES_LIST = FULL_SERVER_PATH + "/chat";
    public final static String FILE_UPLOAD = FULL_SERVER_PATH + "/upload-file";
    public static final String USER_LOGIC_MAP_URL = FULL_SERVER_PATH + "/userLogicMap";
    public final static String PERMISSION_REQUEST_URL = FULL_SERVER_PATH + "/RequestPermission";
    public final static String ACK_DENY_REQUEST_URL = FULL_SERVER_PATH + "/ackDenyRequest";
    public final static String UPDATE_CELL_URL = FULL_SERVER_PATH + "/updateCell";
    public final static String UPDATE_RANGES_URL = FULL_SERVER_PATH + "/updateRanges";
    public final static String FIRST_SORT_POPUP_CHECK_URL = FULL_SERVER_PATH + "/firstSortPopupCheck";
    public final static String SORT_POPUP_URL = FULL_SERVER_PATH + "/sort";
    public final static String FIRST_FILTER_POPUP_CHECK_URL = FULL_SERVER_PATH + "/firstFilterPopupCheck";
    public final static String FILTER_POPUP_URL = FULL_SERVER_PATH + "/filter";
    public final static String DYNAMIC_ANALYSIS_URL = FULL_SERVER_PATH + "/dynamicAnalysis";
}

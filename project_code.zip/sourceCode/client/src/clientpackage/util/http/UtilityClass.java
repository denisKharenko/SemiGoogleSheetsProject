package clientpackage.util.http;

import javafx.scene.control.Alert;
import javafx.stage.Stage;

public class UtilityClass {
    public static void showAlert(String title, String message, Alert.AlertType alertType) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        Stage stage = (Stage) alert.getDialogPane().getScene().getWindow();
        stage.setResizable(true);
        alert.showAndWait();
    }
}
